import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface CartItem {
  id: string;
  cardNumber: string;
  type: string;
  quantity: number;
  price: number;
  links: { platform: string; url: string }[];
  customImageUrl?: string;
  bio?: string;
  cardDesign?: string;
  email?: string;
}

interface DeliveryAddress {
  fullName: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  postalCode: string;
  country: string;
}

interface CheckoutRequest {
  cart?: CartItem[];
  customerEmail: string;
  deliveryAddress: DeliveryAddress;
  returnUrl: string;
}

function generateOrderReceipt(orderDetails: {
  cart?: CartItem[],
  customerEmail: string,
  deliveryAddress: DeliveryAddress,
  sessionId: string,
  date: string,
  totalAmount: number
}): string {
  const { cart, customerEmail, deliveryAddress, sessionId, date, totalAmount } = orderDetails;
  
  let itemsHtml = '';
  
  if (cart && cart.length > 0) {
    itemsHtml = cart.map(item => {
      const validLinks = item.links.filter(link => link.url && link.url.trim() !== '');
      return `
        <tr>
          <td style="padding: 12px; border-bottom: 1px solid #eee;">${item.type.replace('-', ' ').toUpperCase()} Card - ${item.cardNumber}</td>
          <td style="padding: 12px; border-bottom: 1px solid #eee;">${item.quantity}</td>
          <td style="padding: 12px; border-bottom: 1px solid #eee;">£${item.price.toFixed(2)}</td>
          <td style="padding: 12px; border-bottom: 1px solid #eee;">£${(item.price * item.quantity).toFixed(2)}</td>
        </tr>
      `;
    }).join('');
  }

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Order Receipt - White Cards</title>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 0 auto; padding: 20px; }
        h1, h2 { color: #000; }
        .receipt { border: 1px solid #ddd; padding: 20px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th { text-align: left; padding: 12px; border-bottom: 2px solid #ddd; }
        .address { margin-bottom: 20px; }
        .total { font-weight: bold; font-size: 1.2em; margin-top: 20px; }
        .footer { font-size: 0.9em; color: #666; margin-top: 30px; text-align: center; }
        @media print {
          body { font-size: 12px; }
          .no-print { display: none; }
        }
        .print-button { background: #000; color: white; border: none; padding: 10px 20px; cursor: pointer; margin-top: 20px; }
      </style>
    </head>
    <body>
      <div class="receipt">
        <h1>White Cards - Order Receipt</h1>
        <p>Order Date: ${date}</p>
        <p>Order ID: ${sessionId}</p>
        
        <div class="address">
          <h2>Delivery Address:</h2>
          <p>
            ${deliveryAddress.fullName}<br>
            ${deliveryAddress.addressLine1}<br>
            ${deliveryAddress.addressLine2 ? deliveryAddress.addressLine2 + '<br>' : ''}
            ${deliveryAddress.city}, ${deliveryAddress.postalCode}<br>
            ${deliveryAddress.country}
          </p>
          <p>Email: ${customerEmail}</p>
        </div>
        
        <h2>Order Items:</h2>
        <table>
          <thead>
            <tr>
              <th>Product</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHtml}
          </tbody>
        </table>
        
        <p><strong>Note:</strong> All orders include 1-3 working day tracked and signed delivery (£9.99 included in price)</p>
        
        <div class="total">
          <p>Total: £${totalAmount.toFixed(2)}</p>
        </div>
      </div>
      
      <button class="print-button no-print" onclick="window.print();">Print Receipt</button>
      
      <div class="footer">
        <p>Thank you for your order!</p>
        <p>White Cards | Email: nfinityimmersive@gmail.com</p>
      </div>
      
      <script>
        document.addEventListener('DOMContentLoaded', function() {
          setTimeout(function() {
            window.print();
          }, 1000);
        });
      </script>
    </body>
    </html>
  `;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("Received checkout request");
    
    const requestData = await req.json();
    const { cart, customerEmail, deliveryAddress, returnUrl } = requestData as CheckoutRequest;

    console.log("Processing checkout for:", { 
      customerEmail, 
      cartItems: cart?.length, 
      returnUrl,
      deliveryAddress: !!deliveryAddress
    });

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2023-10-16",
    });

    const resend = new Resend(Deno.env.get("RESEND_API_KEY") || "");

    if (!cart || cart.length === 0) {
      console.error("Empty cart received");
      return new Response(
        JSON.stringify({ error: "Cart is empty" }),
        { 
          status: 400, 
          headers: { ...corsHeaders, "Content-Type": "application/json" } 
        }
      );
    }

    for (const item of cart) {
      const validLinks = item.links.filter(link => link.url && link.url.trim() !== '');
      if (validLinks.length === 0) {
        return new Response(
          JSON.stringify({ error: `Card ${item.cardNumber} has no valid links` }),
          { 
            status: 400, 
            headers: { ...corsHeaders, "Content-Type": "application/json" } 
          }
        );
      }
    }

    const customers = await stripe.customers.list({ email: customerEmail, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
      console.log("Found existing customer:", customerId);
    } else {
      const customer = await stripe.customers.create({
        email: customerEmail,
        name: deliveryAddress.fullName,
        address: {
          line1: deliveryAddress.addressLine1,
          line2: deliveryAddress.addressLine2 || '',
          city: deliveryAddress.city,
          postal_code: deliveryAddress.postalCode,
          country: deliveryAddress.country,
        },
        metadata: {
          source: "White Cards Website"
        }
      });
      customerId = customer.id;
      console.log("Created new customer:", customerId);
    }

    const lineItems = cart.map(item => {
      const validLinks = item.links.filter(link => link.url && link.url.trim() !== '');
      return {
        price_data: {
          currency: "gbp",
          product_data: {
            name: `${item.type.replace('-', ' ').toUpperCase()} Card - ${item.cardNumber}`,
            description: `${validLinks.length} link${validLinks.length === 1 ? '' : 's'} (includes tracked & signed 1-3 day delivery)`,
            metadata: {
              cardNumber: item.cardNumber,
              cardType: item.type,
              links: JSON.stringify(validLinks.map(l => `${l.platform}: ${l.url}`).join(', '))
            }
          },
          unit_amount: item.price * 100, // Stripe uses cents
        },
        quantity: item.quantity,
      };
    });

    const successUrl = `${returnUrl}/payment-success?session_id={CHECKOUT_SESSION_ID}`;
    const cancelUrl = `${returnUrl}/payment-canceled`;
    
    console.log("Success URL:", successUrl);
    console.log("Cancel URL:", cancelUrl);

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ["card"],
      line_items: lineItems,
      mode: "payment",
      success_url: successUrl,
      cancel_url: cancelUrl,
      shipping_address_collection: {
        allowed_countries: ['GB'], // UK only
      },
      metadata: {
        customerEmail,
        orderData: JSON.stringify(cart),
        deliveryAddress: JSON.stringify(deliveryAddress)
      }
    });

    console.log("Created checkout session:", session.id);
    console.log("Checkout URL:", session.url);

    // Calculate total amount for later use in success page
    const totalAmount = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    
    // Note: We're not sending any emails here anymore
    // Emails will only be sent from the PaymentSuccess component after payment is confirmed
    // This ensures emails are only sent for successful payments

    return new Response(
      JSON.stringify({ url: session.url }),
      { 
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  } catch (error) {
    console.error("Error creating checkout session:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      }
    );
  }
});
