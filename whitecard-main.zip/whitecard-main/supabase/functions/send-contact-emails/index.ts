
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ContactFormData {
  name: string;
  email: string;
  message: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    const formData: ContactFormData = await req.json();
    const { name, email, message } = formData;

    console.log("Processing contact form submission:", { name, email });

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      console.error("Invalid email format:", email);
      throw new Error("Invalid email format");
    }

    // Initialize Resend with the secret key
    const apiKey = Deno.env.get("RESEND_API_KEY");
    if (!apiKey) {
      console.error("RESEND_API_KEY is not set");
      throw new Error("RESEND_API_KEY is not set");
    }
    
    const resend = new Resend(apiKey);
    
    // Domain verification status flag
    let isDomainVerified = true; // Domain is verified
    let adminEmailSent = false;
    let customerEmailSent = false;
    let customerEmailError = null;
    let adminEmailError = null;
    
    // 1. Send confirmation email to the user
    console.log("Sending confirmation email to user:", email);
    let customerEmailStatus = {
      success: false,
      id: null,
      error: null
    };

    const currentDate = new Date().toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });

    try {
      const customerEmailResponse = await resend.emails.send({
        from: "White Cards <no-reply@whitecards.co.uk>",
        to: [email],
        subject: "We've received your message - White Cards",
        reply_to: "nfinityimmersive@gmail.com",
        headers: {
          "X-Entity-Ref-ID": `contact-${Date.now()}`,
        },
        html: `
          <!DOCTYPE html>
          <html>
            <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>Thank you for contacting us!</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
              <div style="border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px;">
                <h1 style="color: #000;">White Cards</h1>
              </div>
              <h2 style="color: #333;">Thank you for contacting us!</h2>
              <p>Hello ${name},</p>
              <p>We have received your message and will get back to you as soon as possible.</p>
              <p>Here's a copy of your message sent on ${currentDate}:</p>
              <div style="background-color: #f9f9f9; padding: 15px; border-left: 4px solid #000; margin: 20px 0;">
                <p style="white-space: pre-line;">${message}</p>
              </div>
              <p>Best regards,<br>The White Cards Team</p>
              <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #666;">
                <p>© ${new Date().getFullYear()} White Cards. All rights reserved.</p>
                <p>This is an automated message. Please do not reply directly to this email.</p>
              </div>
            </body>
          </html>
        `
      });

      if (customerEmailResponse.error) {
        console.error("Error sending customer confirmation email:", customerEmailResponse.error);
        console.log("Customer email error details:", JSON.stringify(customerEmailResponse.error));
        customerEmailStatus.error = customerEmailResponse.error.message;
        customerEmailError = customerEmailResponse.error.message;
      } else {
        console.log("Customer confirmation email sent successfully to:", email);
        console.log("Email ID:", customerEmailResponse.data?.id);
        customerEmailStatus = {
          success: true,
          id: customerEmailResponse.data?.id,
          error: null
        };
        customerEmailSent = true;
      }
    } catch (emailError) {
      console.error("Exception during customer email send:", emailError);
      customerEmailStatus.error = emailError.message;
      customerEmailError = emailError.message;
    }

    // 2. Send notification email to the admin with improved deliverability
    console.log("Sending notification email to admin");
    let adminEmailStatus = {
      success: false,
      id: null,
      error: null
    };

    try {
      const adminEmailResponse = await resend.emails.send({
        from: "White Cards Contact <no-reply@whitecards.co.uk>",
        to: ["nfinityimmersive@gmail.com"], // Admin email
        subject: `New Contact Form: ${name} - ${email}`,
        reply_to: email,
        headers: {
          "X-Entity-Ref-ID": `admin-contact-${Date.now()}`,
          "List-Unsubscribe": "<mailto:nfinityimmersive@gmail.com?subject=unsubscribe>",
        },
        html: `
          <!DOCTYPE html>
          <html>
            <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>New Contact Form Submission</title>
            </head>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
              <div style="border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px;">
                <h1 style="color: #000;">White Cards - Contact Form</h1>
              </div>
              <h2 style="color: #333;">You have received a new message</h2>
              <p>A new contact form submission was received on ${currentDate}:</p>
              <div style="margin-bottom: 20px; padding: 15px; border: 1px solid #eee; background-color: #f9f9f9;">
                <p><strong>Name:</strong> ${name}</p>
                <p><strong>Email:</strong> <a href="mailto:${email}">${email}</a></p>
              </div>
              <div>
                <p><strong>Message:</strong></p>
                <div style="background-color: #f9f9f9; padding: 15px; border-left: 4px solid #000;">
                  <p style="white-space: pre-line;">${message}</p>
                </div>
              </div>
              <div style="margin-top: 30px; background-color: #f5f5f5; padding: 10px; border-radius: 4px;">
                <p>Click to reply: <a href="mailto:${email}?subject=Re: Your message to White Cards" style="color: #000; text-decoration: underline;">Reply to ${name}</a></p>
              </div>
              <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #666;">
                <p>© ${new Date().getFullYear()} White Cards. This is an automated notification from your website's contact form.</p>
              </div>
            </body>
          </html>
        `
      });

      if (adminEmailResponse.error) {
        console.error("Error sending admin notification email:", adminEmailResponse.error);
        console.log("Admin email error details:", JSON.stringify(adminEmailResponse.error));
        adminEmailStatus.error = adminEmailResponse.error.message;
        adminEmailError = adminEmailResponse.error.message;
      } else {
        console.log("Admin notification email sent successfully");
        console.log("Email ID:", adminEmailResponse.data?.id);
        adminEmailStatus = {
          success: true,
          id: adminEmailResponse.data?.id,
          error: null
        };
        adminEmailSent = true;
      }
    } catch (emailError) {
      console.error("Exception during admin email send:", emailError);
      adminEmailStatus.error = emailError.message;
      adminEmailError = emailError.message;
    }

    console.log("Email processing completed - customer:", customerEmailStatus.success, "admin:", adminEmailStatus.success);

    // Return detailed response for debugging - even if there are errors,
    // we'll return a success status if at least one email went through
    return new Response(
      JSON.stringify({ 
        success: customerEmailStatus.success || adminEmailStatus.success,
        message: "Contact form submission processing completed",
        domainVerificationRequired: !isDomainVerified && customerEmailError && customerEmailError.includes("verify a domain"),
        customerEmail: {
          success: customerEmailSent,
          id: customerEmailStatus.id,
          error: customerEmailError
        },
        adminEmail: {
          success: adminEmailSent,
          id: adminEmailStatus.id,
          error: adminEmailError
        }
      }),
      { 
        status: 200, 
        headers: { 
          "Content-Type": "application/json",
          ...corsHeaders
        } 
      }
    );
  } catch (error) {
    console.error("Error processing contact form:", error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        stack: error.stack
      }),
      { 
        status: 500, 
        headers: { 
          "Content-Type": "application/json",
          ...corsHeaders
        } 
      }
    );
  }
});
