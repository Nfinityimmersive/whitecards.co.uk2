
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { XCircle, ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const PaymentCanceled = () => {
  const { toast } = useToast();

  useEffect(() => {
    // Show notification for order canceled
    toast({
      title: "Order Canceled",
      description: "Your order process was canceled. No order has been placed.",
      variant: "destructive"
    });

    // Log for debugging
    console.log('Order was canceled by user');
    
    // We don't need to do anything special to preserve the cart
    // as it's already stored in localStorage by the CartContext
    // and will be automatically loaded when returning to the order page
  }, [toast]);

  return (
    <Layout>
      <div className="container max-w-4xl py-12 px-4">
        <Card className="border-orange-200 shadow-md">
          <CardHeader className="text-center border-b pb-6">
            <div className="mx-auto w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-4">
              <XCircle className="text-orange-600 h-6 w-6" />
            </div>
            <CardTitle className="text-2xl text-orange-700">Order Canceled</CardTitle>
            <CardDescription>Your order has not been placed.</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <p className="text-center">
                Your order process was canceled. No order has been placed and no payment is required.
              </p>
              
              <div className="bg-blue-50 p-4 rounded-md text-blue-800 text-sm">
                <p className="font-medium">Your cart is still saved</p>
                <p className="mt-1">
                  You can return to your cart and complete your purchase at any time.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button asChild className="flex-1">
                  <Link to="/order-card">
                    <ArrowLeft className="mr-2 h-4 w-4" /> Return to Cart
                  </Link>
                </Button>
                <Button asChild variant="outline" className="flex-1">
                  <Link to="/">
                    Return to Home
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default PaymentCanceled;
