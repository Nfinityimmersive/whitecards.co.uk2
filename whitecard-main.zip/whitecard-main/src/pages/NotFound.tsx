
import { Link } from "react-router-dom";
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <Layout>
      <div className="flex flex-col items-center justify-center min-h-[70vh] px-6 text-center">
        <h1 className="text-8xl font-bold mb-4">404</h1>
        <div className="w-16 h-1 bg-gray-200 mb-8"></div>
        <h2 className="text-2xl font-medium mb-4">Page not found</h2>
        <p className="text-gray-500 mb-8 max-w-md">
          We couldn't find the page you're looking for. It might have been moved or doesn't exist.
        </p>
        <Link to="/">
          <Button className="bg-black text-white hover:bg-black/90">
            <ArrowLeft size={16} className="mr-2" /> Back to home
          </Button>
        </Link>
      </div>
    </Layout>
  );
};

export default NotFound;
