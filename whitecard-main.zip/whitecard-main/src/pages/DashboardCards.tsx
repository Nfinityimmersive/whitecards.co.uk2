
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShoppingCart, QrCode, Share2 } from 'lucide-react';
import WhiteCard from '@/components/WhiteCard';
import { useToast } from '@/hooks/use-toast';

const DashboardCards = () => {
  const { toast } = useToast();

  const handleOrderCards = () => {
    toast({
      title: "Coming soon",
      description: "Card ordering will be available soon",
    });
  };

  const handleShareProfile = () => {
    toast({
      title: "Profile shared",
      description: "Your profile link has been copied to clipboard",
    });
  };

  return (
    <DashboardLayout>
      <div className="px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">My Cards</h1>
          <p className="mt-1 text-sm text-gray-500">Manage your White Cards and order new ones.</p>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Active Card</CardTitle>
              <CardDescription>Your currently active White Card</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center pt-4">
              <div className="relative w-64">
                <WhiteCard className="shadow-lg" />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={handleShareProfile}>
                <Share2 className="mr-2 h-4 w-4" /> Share
              </Button>
              <Button variant="outline">
                <QrCode className="mr-2 h-4 w-4" /> View QR Code
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Need More Cards?</CardTitle>
              <CardDescription>Order additional White Cards</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 border rounded-lg">
                <h3 className="font-medium mb-1">Single White Card</h3>
                <p className="text-sm text-muted-foreground mb-2">One physical NFC card</p>
                <p className="font-bold mb-3">£20</p>
                <Button className="w-full" onClick={handleOrderCards}>
                  <ShoppingCart className="mr-2 h-4 w-4" /> Order Now
                </Button>
              </div>
              
              <div className="p-4 border rounded-lg bg-muted/50">
                <div className="bg-black text-white text-xs px-2 py-0.5 rounded-full inline-block mb-2">Best Value</div>
                <h3 className="font-medium mb-1">Premium Pack</h3>
                <p className="text-sm text-muted-foreground mb-2">3 adhesive NFC cards + premium features</p>
                <p className="font-bold mb-3">£200/year</p>
                <Button className="w-full" onClick={handleOrderCards}>
                  <ShoppingCart className="mr-2 h-4 w-4" /> Subscribe
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Card Activity</CardTitle>
            <CardDescription>Recent scans of your White Card</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 border-b">
                <div>
                  <p className="font-medium">First scan</p>
                  <p className="text-sm text-muted-foreground">London, UK</p>
                </div>
                <p className="text-sm text-muted-foreground">June 1, 2023 at 14:35</p>
              </div>
              <div className="flex justify-between items-center p-3 border-b">
                <div>
                  <p className="font-medium">Card scan</p>
                  <p className="text-sm text-muted-foreground">Manchester, UK</p>
                </div>
                <p className="text-sm text-muted-foreground">May 28, 2023 at 10:12</p>
              </div>
              <div className="flex justify-between items-center p-3 border-b">
                <div>
                  <p className="font-medium">Card scan</p>
                  <p className="text-sm text-muted-foreground">Birmingham, UK</p>
                </div>
                <p className="text-sm text-muted-foreground">May 24, 2023 at 16:48</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default DashboardCards;
