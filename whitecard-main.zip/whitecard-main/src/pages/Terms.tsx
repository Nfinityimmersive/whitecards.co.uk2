
import Layout from '@/components/Layout';

const Terms = () => {
  return (
    <Layout>
      <section className="py-24">
        <div className="container px-4 md:px-6 mx-auto max-w-4xl">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Terms of Service</h1>
            <p className="text-gray-500">
              Last updated: April 6, 2025
            </p>
          </div>
          
          <div className="prose max-w-none">
            <h2>1. Acceptance of Terms</h2>
            <p>
              By accessing and using the White Cards service ("Service"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, do not use the Service.
            </p>
            
            <h2>2. Description of Service</h2>
            <p>
              White Cards provides smart card products and services that allow users to share digital content through a physical card product. The Service includes the physical cards, the website, and the digital profiles created by users.
            </p>
            
            <h2>3. Account Registration</h2>
            <p>
              To use certain features of the Service, you must register for an account. You agree to provide accurate and complete information when creating your account, and to update this information to keep it accurate and current.
            </p>
            
            <h2>4. Privacy</h2>
            <p>
              Your privacy is important to us. Our Privacy Policy explains how we collect, use, and protect your personal information. By using the Service, you agree to our collection and use of information as described in the Privacy Policy.
            </p>
            
            <h2>5. User Content</h2>
            <p>
              You are solely responsible for the content you choose to share through your White Card. This includes links, images, text, and any other content associated with your profile. You agree not to use the Service to share content that is illegal, harmful, threatening, abusive, or otherwise offensive.
            </p>
            
            <h2>6. Payment and Refunds</h2>
            <p>
              All purchases are final and non-refundable unless the product is defective. If you receive a defective product, please contact our support team within 14 days of receipt for a replacement.
            </p>
            
            <h2>7. Termination</h2>
            <p>
              We reserve the right to terminate or suspend your account and access to the Service at our sole discretion, without notice, for conduct that we believe violates these Terms or is harmful to other users, us, or third parties, or for any other reason.
            </p>
            
            <h2>8. Changes to Terms</h2>
            <p>
              We may modify these Terms at any time. We will provide notice of changes by posting the updated Terms on our website. Your continued use of the Service after any changes indicates your acceptance of the new Terms.
            </p>
            
            <h2>9. Contact Information</h2>
            <p>
              If you have any questions about these Terms, please contact us at nfinityimmersive@gmail.com.
            </p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Terms;
