
import { useState } from 'react';
import { Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import AnimatedSection from '@/components/AnimatedSection';
import { Button } from '@/components/ui/button';
import { ArrowRight, Smartphone, MessageCircle, Battery, Globe, RefreshCw } from 'lucide-react';
import FeatureCard from '@/components/FeatureCard';
import { useIsMobile } from '@/hooks/use-mobile';

const Index = () => {
  const isMobile = useIsMobile();
  const [showAllFeatures, setShowAllFeatures] = useState(false);

  const featureCards = [
    {
      icon: <Smartphone className="h-8 w-8" />,
      title: "Tap to Share Instantly",
      description: "Share all your digital profiles with just a single tap - no apps required."
    },
    {
      icon: <MessageCircle className="h-8 w-8" />,
      title: "Chat Support",
      description: "Get immediate assistance through our dedicated support channel."
    },
    {
      icon: <Battery className="h-8 w-8" />,
      title: "No Battery Required",
      description: "Unlike a mobile phone, your card never runs out of power - works forever."
    },
    {
      icon: <Globe className="h-8 w-8" />,
      title: "Works Worldwide",
      description: "Use your card anywhere in the world with enabled devices."
    },
    {
      icon: <RefreshCw className="h-8 w-8" />,
      title: "Remote Link Changes",
      description: "Update your links remotely at any time for the latest content."
    },
    {
      icon: <ArrowRight className="h-8 w-8" />,
      title: "Endless Taps",
      description: "No need for 10,000 business cards - one card for unlimited sharing."
    }
  ];

  // Determine how many feature cards to display
  const displayedFeatures = isMobile && !showAllFeatures 
    ? featureCards.slice(0, 3) 
    : featureCards;

  // How it works steps - updated as requested
  const howItWorksSteps = [
    {
      number: "1",
      title: "Order Your Card",
      description: "Choose between our One Link or Multi Link card options based on your needs."
    },
    {
      number: "2",
      title: "Receive Your Card",
      description: "Your physical White Card will be delivered within 1-3 working days."
    },
    {
      number: "3",
      title: "Share With a Tap",
      description: "Simply tap your card on any smartphone to instantly share your digital presence."
    }
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative py-12 md:py-24">
        <div className="absolute inset-0 bg-gradient-to-b from-gray-50 to-white z-[-1]"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
          <AnimatedSection className="text-center max-w-3xl mx-auto">
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight leading-tight mb-4">
              Share Your Digital World With A Tap
            </h1>
            <p className="text-base md:text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Premium White Cards for seamless digital connections. One tap to share all your social profiles, payment links, and websites.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-10 md:mb-16">
              <Link to="/order-card">
                <Button size="lg" className="px-6 sm:px-8 py-5 sm:py-6 text-base w-full sm:w-auto bg-black text-white hover:bg-black/90">
                  Get Your Card <ArrowRight size={16} className="ml-2" />
                </Button>
              </Link>
            </div>
          </AnimatedSection>
          
          <AnimatedSection className="relative flex justify-center mt-6" delay={300}>
            <div className="relative">
              <img 
                src="/lovable-uploads/65281feb-337f-4791-a75c-6e9f170962b2.png" 
                alt="White Card" 
                className="max-w-full w-48 sm:w-64 animate-hero-card-float shadow-xl" 
              />
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* How It Works Section - Moved up as requested */}
      <section className="py-12 md:py-20 bg-gray-50 animate-on-scroll">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
          <AnimatedSection className="text-center max-w-3xl mx-auto mb-10 md:mb-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight mb-4">
              How It Works
            </h2>
            <p className="text-base md:text-lg text-gray-600">
              Easy steps to get started with your White Card
            </p>
          </AnimatedSection>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-8">
            {howItWorksSteps.map((step, index) => (
              <div 
                key={index} 
                className="bg-white p-5 md:p-6 rounded-lg shadow-sm border flex flex-col items-center text-center"
              >
                <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-black text-white flex items-center justify-center text-xl font-bold mb-4">
                  {step.number}
                </div>
                <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-600 text-sm sm:text-base">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section 
        id="features" 
        className="py-12 md:py-20 relative overflow-hidden animate-on-scroll"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
          <AnimatedSection className="text-center max-w-3xl mx-auto mb-10 md:mb-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight mb-4">
              Why Choose Our White Cards?
            </h2>
            <p className="text-base md:text-lg text-gray-600">
              The smartest way to share your digital presence
            </p>
          </AnimatedSection>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
            {displayedFeatures.map((feature, index) => (
              <FeatureCard 
                key={index}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
              />
            ))}
          </div>
          
          {/* View More Button - Mobile Only */}
          {isMobile && !showAllFeatures && (
            <div className="mt-8 flex justify-center">
              <Button 
                variant="outline" 
                onClick={() => setShowAllFeatures(true)}
                className="w-full max-w-xs"
              >
                View More Features
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-20 animate-on-scroll bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
          <AnimatedSection className="text-center max-w-3xl mx-auto mb-10 md:mb-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight mb-4">
              Get Started
            </h2>
            <p className="text-base md:text-lg text-gray-600">
              Start sharing your digital world today.
            </p>
          </AnimatedSection>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/pricing">
              <Button size="lg" className="px-6 sm:px-8 py-5 sm:py-6 text-base w-full sm:w-auto bg-black text-white hover:bg-black/90">
                View Pricing <ArrowRight size={16} className="ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
