
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { BarChart, Link as LinkIcon, CreditCard, Users } from 'lucide-react';

const Dashboard = () => {
  return (
    <DashboardLayout>
      <div className="px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="mt-1 text-sm text-gray-500">Welcome back to your White Cards dashboard.</p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Links</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">5</div>
              <p className="text-xs text-muted-foreground mt-1">+2 from last month</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Clicks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">120</div>
              <p className="text-xs text-muted-foreground mt-1">+42 from last month</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Cards</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1</div>
              <p className="text-xs text-muted-foreground mt-1">Basic plan</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Subscription</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">Basic</div>
              <p className="text-xs text-muted-foreground mt-1">Renews on Dec 12, 2023</p>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 gap-4 mt-8 lg:grid-cols-3">
          <Card className="col-span-1 lg:col-span-2">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Manage your White Cards account</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <Link to="/dashboard/links">
                  <div className="flex items-center p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="rounded-full bg-primary/10 p-2 mr-3">
                      <LinkIcon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Manage Links</h3>
                      <p className="text-sm text-muted-foreground">Add or edit your profile links</p>
                    </div>
                  </div>
                </Link>
                
                <Link to="/dashboard/cards">
                  <div className="flex items-center p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="rounded-full bg-primary/10 p-2 mr-3">
                      <CreditCard className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Manage Cards</h3>
                      <p className="text-sm text-muted-foreground">View or order new cards</p>
                    </div>
                  </div>
                </Link>
                
                <Link to="/dashboard/resellers">
                  <div className="flex items-center p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="rounded-full bg-primary/10 p-2 mr-3">
                      <Users className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">Find Resellers</h3>
                      <p className="text-sm text-muted-foreground">Locate resellers near you</p>
                    </div>
                  </div>
                </Link>
                
                <Link to="/dashboard">
                  <div className="flex items-center p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="rounded-full bg-primary/10 p-2 mr-3">
                      <BarChart className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-medium">View Analytics</h3>
                      <p className="text-sm text-muted-foreground">Track link performance</p>
                    </div>
                  </div>
                </Link>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Upgrade Plan</CardTitle>
              <CardDescription>Get more from White Cards</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              <div className="bg-muted/50 p-4 rounded-lg">
                <h3 className="font-semibold mb-1">Premium Plan</h3>
                <p className="text-sm text-muted-foreground mb-3">Get 3 Adhesive NFC Cards + unlimited links + 10 free monthly changes</p>
                <p className="font-bold text-xl mb-4">£200<span className="text-sm font-normal text-muted-foreground">/year</span></p>
                <Button className="w-full">Upgrade Now</Button>
              </div>
              <p className="text-xs text-center text-muted-foreground">
                No long-term commitment. Cancel anytime.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;
