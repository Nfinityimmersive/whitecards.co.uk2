
import { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useCart } from '@/context/CartContext';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Available platform options
const platformOptions = [
  "Instagram",
  "TikTok",
  "YouTube",
  "Facebook",
  "Twitter",
  "LinkedIn",
  "Snapchat",
  "Pinterest",
  "Website",
  "Spotify",
  "Apple Music",
  "SoundCloud",
  "WhatsApp",
  "Telegram",
  "Email",
  "Phone",
  "Twitch",
  "Discord",
  "Reddit",
  "Other"
];

const UpdateLinks = () => {
  const [formValues, setFormValues] = useState({
    cardNumber: '',
    name: '',
    email: '',
    updateType: 'add-link',
    platform: 'Instagram',
    url: '',
    linkToRemove: '',
    customImageUrl: null as File | null,
    customImagePreview: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const { addToCart } = useCart();
  
  // Prefill the first two characters with "W" and "C" when component loads
  useEffect(() => {
    // Only set this initially
    if (formValues.cardNumber === '') {
      setFormValues(prev => ({ ...prev, cardNumber: 'WC' }));
    }
  }, []);

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Get the value from the input field
    let newValue = e.target.value;
    
    // Ensure the value is no longer than 6 characters
    if (newValue.length > 6) {
      newValue = newValue.slice(0, 6);
    }
    
    // Always enforce WC at the beginning
    if (newValue.length >= 1) {
      newValue = 'W' + newValue.substring(1);
    }
    if (newValue.length >= 2) {
      newValue = newValue.substring(0, 1) + 'C' + newValue.substring(2);
    }
    
    setFormValues(prev => ({ ...prev, cardNumber: newValue }));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (value: string) => {
    setFormValues(prev => ({ ...prev, platform: value }));
  };

  const handleRadioChange = (value: string) => {
    setFormValues((prev) => ({ ...prev, updateType: value }));
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setFormValues((prev) => ({ 
        ...prev, 
        customImageUrl: file,
        customImagePreview: URL.createObjectURL(file)
      }));
    }
  };

  const calculatePrice = () => {
    // Each update operation costs £1
    return 1;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formValues.email)) {
        throw new Error("Please enter a valid email address");
      }

      // Validate card number
      if (!formValues.cardNumber || formValues.cardNumber.length !== 6) {
        throw new Error("Please enter your complete 6-character card number");
      }
      
      // Validate card number format (WC + 4 digits = 6 characters)
      if (!formValues.cardNumber.startsWith('WC') || formValues.cardNumber.length !== 6) {
        throw new Error("Please enter a valid card number (WC + 4 digits)");
      }

      // Validate update details based on type
      if (formValues.updateType === 'add-link') {
        if (!formValues.platform || !formValues.url) {
          throw new Error("Please select a platform and enter a URL");
        }
      } else if (formValues.updateType === 'remove-link') {
        if (!formValues.linkToRemove) {
          throw new Error("Please enter the link you want to remove");
        }
      } else if (formValues.updateType === 'change-image') {
        if (!formValues.customImageUrl) {
          throw new Error("Please upload a new profile image");
        }
      }

      // Create the update request item
      const updateItem = {
        id: uuidv4(),
        cardNumber: formValues.cardNumber,
        type: 'update-request',
        quantity: 1,
        price: calculatePrice(),
        links: [{
          action: formValues.updateType,
          details: formValues.updateType === 'add-link' 
            ? `${formValues.platform}: ${formValues.url}` 
            : formValues.updateType === 'remove-link'
              ? formValues.linkToRemove
              : 'Change profile image',
          userEmail: formValues.email,
          userName: formValues.name
        }],
        name: formValues.name,
        customImageUrl: formValues.customImagePreview || undefined
      };

      // Add to cart
      addToCart(updateItem);

      // Show success message
      toast({
        title: "Update request added to cart",
        description: "Your update request has been added to your cart.",
      });
      
      // Reset form
      setFormValues({
        cardNumber: 'WC',
        name: '',
        email: '',
        updateType: 'add-link',
        platform: 'Instagram',
        url: '',
        linkToRemove: '',
        customImageUrl: null,
        customImagePreview: '',
      });
    } catch (error) {
      console.error('Error submitting form:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add update request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Layout>
      <section className="py-24">
        <div className="container px-4 md:px-6 mx-auto">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Update Your White Card</h1>
            <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed">
              Need to make changes to your White Card? Use this form to request updates.
            </p>
          </div>
          
          <div className="max-w-md mx-auto">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="cardNumber">Card Number</Label>
                <Input 
                  id="cardNumber" 
                  name="cardNumber"
                  value={formValues.cardNumber}
                  onChange={handleCardNumberChange}
                  className="text-center tracking-wider font-medium text-lg"
                  maxLength={6}
                  required
                />
                <p className="text-xs text-gray-500">Enter the unique 6-character number shown on your White Card (e.g. WC1234). You can find this on your dashboard.</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="name">Your Name</Label>
                <Input 
                  id="name" 
                  name="name" 
                  value={formValues.name} 
                  onChange={handleInputChange} 
                  required 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input 
                  id="email" 
                  name="email" 
                  type="email" 
                  value={formValues.email} 
                  onChange={handleInputChange} 
                  required 
                  placeholder="your@email.com"
                />
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <Label>Update Type</Label>
                <RadioGroup 
                  value={formValues.updateType} 
                  onValueChange={handleRadioChange}
                  className="flex flex-col space-y-2"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="add-link" id="add-link" />
                    <Label htmlFor="add-link" className="cursor-pointer">Add a link</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="remove-link" id="remove-link" />
                    <Label htmlFor="remove-link" className="cursor-pointer">Remove a link</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="change-image" id="change-image" />
                    <Label htmlFor="change-image" className="cursor-pointer">Change profile image</Label>
                  </div>
                </RadioGroup>
              </div>
              
              {formValues.updateType === 'add-link' && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="platform">Platform</Label>
                    <Select 
                      value={formValues.platform} 
                      onValueChange={handleSelectChange}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a platform" />
                      </SelectTrigger>
                      <SelectContent>
                        {platformOptions.map((platform) => (
                          <SelectItem key={platform} value={platform}>
                            {platform}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="url">URL</Label>
                    <Input
                      id="url"
                      name="url"
                      value={formValues.url}
                      onChange={handleInputChange}
                      placeholder="https://"
                      required
                    />
                  </div>
                </div>
              )}
              
              {formValues.updateType === 'remove-link' && (
                <div className="space-y-2">
                  <Label htmlFor="linkToRemove">Link to Remove</Label>
                  <Textarea 
                    id="linkToRemove" 
                    name="linkToRemove" 
                    value={formValues.linkToRemove} 
                    onChange={handleInputChange} 
                    required 
                    placeholder="Enter the exact link you want to remove"
                    rows={3}
                  />
                </div>
              )}
              
              {formValues.updateType === 'change-image' && (
                <div className="space-y-2">
                  <Label htmlFor="customImageUrl">New Profile Image</Label>
                  <Input 
                    id="customImageUrl" 
                    name="customImageUrl" 
                    type="file" 
                    accept="image/*"
                    onChange={handleImageChange} 
                    required
                  />
                  {formValues.customImagePreview && (
                    <div className="mt-2 flex justify-center">
                      <img 
                        src={formValues.customImagePreview} 
                        alt="Profile preview" 
                        className="h-24 w-24 object-cover rounded-full border" 
                      />
                    </div>
                  )}
                </div>
              )}
              
              <div className="pt-4">
                <Button 
                  type="submit" 
                  disabled={isSubmitting} 
                  className="w-full"
                >
                  {isSubmitting ? "Processing..." : "Add to Cart (£1)"}
                </Button>
                <p className="text-sm text-center mt-2 text-gray-500">
                  Each update costs £1 and will be added to your cart
                </p>
              </div>
            </form>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default UpdateLinks;
