import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Form, FormField, FormItem, FormLabel, FormControl } from '@/components/ui/form';
import { Textarea } from '@/components/ui/textarea';
import { useForm } from 'react-hook-form';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { ShoppingCart, Plus, Minus, Instagram, Facebook, Twitter, Globe, PhoneCall, Mail, Send, ArrowLeft } from 'lucide-react';
import { CheckoutButton } from '@/components/CheckoutButton';
import CartItem from '@/components/CartItem';
import { useCart } from '@/context/CartContext';
import useIsMobile from '@/hooks/use-mobile';

type CardType = 'one-link' | 'multi-link';
type CardDesign = 'design1' | 'design2';
type OrderStep = 'select-card' | 'card-setup';

interface ICartItem {
  id: string;
  cardNumber: string;
  type: CardType;
  quantity: number;
  price: number;
  links: SocialLink[];
  name?: string;
  bio?: string;
  cardDesign?: CardDesign;
  email?: string;
}

interface SocialLink {
  platform: string;
  url: string;
}

interface DeliveryAddress {
  fullName: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  postalCode: string;
  country: string;
}

const generateCardNumber = () => {
  const prefix = 'WC';
  const randomNum = Math.floor(1000 + Math.random() * 9000); // 4-digit number between 1000-9999
  return `${prefix}${randomNum}`;
};

const OrderCard = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { cart, addToCart } = useCart();
  const initialCardType = searchParams.get('type') as CardType || 'one-link';
  const [cardType, setCardType] = useState<CardType>(initialCardType);
  const [currentStep, setCurrentStep] = useState<OrderStep>('select-card');
  const [links, setLinks] = useState<SocialLink[]>([]);
  const [newLink, setNewLink] = useState<SocialLink>({ platform: 'instagram', url: '' });
  const [customPlatform, setCustomPlatform] = useState('');
  const [isCustomPlatform, setIsCustomPlatform] = useState(false);
  const [customerEmail, setCustomerEmail] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [name, setName] = useState('');
  const isMobile = useIsMobile();
  
  // Keep this empty delivery address for backward compatibility
  const [deliveryAddress, setDeliveryAddress] = useState<DeliveryAddress>({
    fullName: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    postalCode: '',
    country: 'GB'
  });

  const form = useForm({
    defaultValues: {
      name: '',
      bio: '',
      instagram: '',
      tiktok: '',
      twitter: '',
      whatsapp: '',
      phone: '',
      email: '',
      website: '',
      facebook: ''
    },
  });

  const getPlatformInputDetails = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'instagram':
        return { 
          label: 'Instagram URL',
          placeholder: 'https://instagram.com/yourpage'
        };
      case 'facebook':
        return { 
          label: 'Facebook Profile/Page URL',
          placeholder: 'https://facebook.com/yourpage'
        };
      case 'twitter':
        return { 
          label: 'Twitter/X URL',
          placeholder: 'https://twitter.com/yourpage'
        };
      case 'tiktok':
        return { 
          label: 'TikTok URL',
          placeholder: 'https://tiktok.com/@yourhandle'
        };
      case 'website':
        return { 
          label: 'Website URL',
          placeholder: 'https://yourwebsite.com'
        };
      case 'phone-call':
        return { 
          label: 'Phone Number',
          placeholder: '+44 7123 456789'
        };
      case 'email':
        return { 
          label: 'Email Address',
          placeholder: 'you@example.com'
        };
      case 'whatsapp':
        return { 
          label: 'WhatsApp Number',
          placeholder: '+44 7123 456789'
        };
      case 'custom':
        return { 
          label: 'Custom Link',
          placeholder: 'https://'
        };
      default:
        return { 
          label: 'Link URL',
          placeholder: 'https://'
        };
    }
  };

  const validateLink = (platform: string, value: string): boolean => {
    if (!value.trim()) {
      return false;
    }
    
    switch (platform.toLowerCase()) {
      case 'email':
        return value.includes('@');
      case 'phone-call':
      case 'whatsapp':
        // Allow numbers and + character
        return /^[+\d\s]+$/.test(value);
      default:
        // For all other platforms, they should start with http:// or https://
        return value.startsWith('http://') || value.startsWith('https://');
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'instagram': return <Instagram className="h-4 w-4" />;
      case 'facebook': return <Facebook className="h-4 w-4" />;
      case 'twitter': return <Twitter className="h-4 w-4" />;
      case 'tiktok': return <Twitter className="h-4 w-4" />;
      case 'website': return <Globe className="h-4 w-4" />;
      case 'phone-call': return <PhoneCall className="h-4 w-4" />;
      case 'email': return <Mail className="h-4 w-4" />;
      case 'whatsapp': return <Send className="h-4 w-4" />;
      default: return <Globe className="h-4 w-4" />;
    }
  };

  const getCardPrice = (type: CardType) => {
    switch (type) {
      case 'one-link': return 20;
      case 'multi-link': return 30;
      default: return 20;
    }
  };

  const addLink = () => {
    if (!newLink.url.trim()) {
      toast({
        title: "Invalid link",
        description: "Please enter a valid URL before adding a link.",
        variant: "destructive"
      });
      return;
    }
    
    const platformValue = isCustomPlatform ? customPlatform : newLink.platform;
    
    if (!validateLink(platformValue, newLink.url)) {
      let errorMessage = "Invalid format.";
      if (platformValue === 'email') {
        errorMessage = "Email must contain an @ symbol.";
      } else if (['phone-call', 'whatsapp'].includes(platformValue.toLowerCase())) {
        errorMessage = "Phone numbers should only contain numbers and optionally a + character.";
      } else {
        errorMessage = "URL must start with http:// or https://";
      }
      
      toast({
        title: "Invalid entry",
        description: errorMessage,
        variant: "destructive"
      });
      return;
    }
    
    setLinks([...links, { platform: platformValue, url: newLink.url }]);
    setNewLink({ platform: 'instagram', url: '' });
    setIsCustomPlatform(false);
    setCustomPlatform('');
  };

  const removeLink = (index: number) => {
    const newLinks = [...links];
    newLinks.splice(index, 1);
    setLinks(newLinks);
  };

  const validateFormLinks = (formValues: any): SocialLink[] => {
    const formLinks: SocialLink[] = [];
    
    Object.entries(formValues).forEach(([key, value]) => {
      if (key !== 'bio' && key !== 'name' && value && typeof value === 'string' && value.trim() !== '') {
        formLinks.push({
          platform: key,
          url: value as string
        });
      }
    });
    
    return formLinks;
  };

  const handleContinue = () => {
    setCurrentStep('card-setup');
    // Scroll to the top of the page
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };
  
  const handleBack = () => {
    setCurrentStep('select-card');
    // Reset card setup data when going back to selection
    setLinks([]);
    form.reset();
    // Scroll to the top of the page
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const addToCartHandler = () => {
    const formValues = form.getValues();
    let allLinks = [...links];
    
    if (cardType === 'multi-link') {
      const formLinks = validateFormLinks(formValues);
      allLinks = [...allLinks, ...formLinks];
    }
    
    if (allLinks.length === 0 || !allLinks.some(link => link.url && link.url.trim() !== '')) {
      toast({
        title: "No links added",
        description: "Please add at least one link before adding the card to your cart.",
        variant: "destructive"
      });
      return;
    }

    try {
      const newItem: ICartItem = {
        id: Date.now().toString(),
        cardNumber: generateCardNumber(),
        type: cardType,
        quantity: 1,
        price: getCardPrice(cardType),
        links: allLinks,
        name: cardType === 'multi-link' ? formValues.name : undefined,
        bio: cardType === 'multi-link' ? formValues.bio : undefined,
        email: customerEmail || undefined
      };

      addToCart(newItem);
      
      toast({
        title: "Added to cart",
        description: `${cardType.replace('-', ' ').toUpperCase()} card added to your cart.`
      });

      // Reset form for adding additional cards
      setLinks([]);
      setName('');
      form.reset();
      
      // Stay on card setup page to allow adding more cards
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add item to cart",
        variant: "destructive"
      });
    }
  };

  const getTotalPrice = () => {
    const itemsPrice = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    
    // Check if there are any physical cards in the cart (not update requests)
    const hasPhysicalCards = cart.some(item => item.type !== 'update-request');
    
    // Only apply delivery fee if there are physical cards
    const deliveryFee = hasPhysicalCards ? 9.99 : 0;
    
    return itemsPrice + deliveryFee;
  };

  // Helper function to check if there are physical cards in the cart
  const hasPhysicalCards = () => {
    return cart.some(item => item.type !== 'update-request');
  };

  useEffect(() => {
    const type = searchParams.get('type');
    if (type === 'one-link' || type === 'multi-link') {
      setCardType(type);
      setCurrentStep('card-setup');
    }
  }, [searchParams]);

  return (
    <Layout>
      <section className="py-12 md:py-24">
        <div className="container px-4 md:px-6">
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-4">Order Your Card</h1>
          
          {/* Progress steps */}
          <div className="flex items-center space-x-2 mb-8">
            <div className={`rounded-full h-8 w-8 flex items-center justify-center ${currentStep === 'select-card' ? 'bg-primary text-white' : 'bg-gray-200'}`}>
              1
            </div>
            <div className="h-1 w-8 bg-gray-200"></div>
            <div className={`rounded-full h-8 w-8 flex items-center justify-center ${currentStep === 'card-setup' ? 'bg-primary text-white' : 'bg-gray-200'}`}>
              2
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              {currentStep === 'select-card' ? (
                <Card className="mb-8">
                  <CardHeader>
                    <CardTitle>Step 1: Select Your Card Type</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div 
                        className={`border rounded-lg p-4 cursor-pointer transition-all ${cardType === 'one-link' ? 'border-black bg-gray-50' : 'border-gray-200'}`}
                        onClick={() => setCardType('one-link')}
                      >
                        <h3 className="font-medium">One Link Card</h3>
                        <p className="text-sm text-gray-500 mb-2">Perfect for personal use with one single link</p>
                        <p className="font-bold mb-2">£20</p>
                        <ul className="text-sm space-y-1">
                          <li className="flex items-center gap-2">
                            <span className="text-xs">✓</span> 1 Physical White Card
                          </li>
                          <li className="flex items-center gap-2">
                            <span className="text-xs">✓</span> One single link
                          </li>
                          <li className="flex items-center gap-2">
                            <span className="text-xs">✓</span> Personal use only
                          </li>
                          <li className="flex items-center gap-2">
                            <span className="text-xs">✓</span> One-time payment
                          </li>
                          <li className="flex items-center gap-2">
                            <span className="text-xs">✓</span> Link is permanent
                          </li>
                        </ul>
                      </div>
                      
                      <div 
                        className={`border rounded-lg p-4 cursor-pointer transition-all ${cardType === 'multi-link' ? 'border-black bg-gray-50' : 'border-gray-200'}`}
                        onClick={() => setCardType('multi-link')}
                      >
                        <h3 className="font-medium">Multi Link Card</h3>
                        <p className="text-sm text-gray-500 mb-2">Complete social profile with multiple links</p>
                        <p className="font-bold mb-2">£30</p>
                        <ul className="text-sm space-y-1">
                          <li className="flex items-center gap-2">
                            <span className="text-xs">✓</span> 1 Physical Card
                          </li>
                          <li className="flex items-center gap-2">
                            <span className="text-xs">✓</span> Multiple links
                          </li>
                          <li className="flex items-center gap-2">
                            <span className="text-xs">✓</span> Dashboard included
                          </li>
                          <li className="flex items-center gap-2">
                            <span className="text-xs">✓</span> Personal use only
                          </li>
                          <li className="flex items-center gap-2">
                            <span className="text-xs">✓</span> One-time payment
                          </li>
                          <li className="flex items-center gap-2">
                            <span className="text-xs">✓</span> £1 per link changes
                          </li>
                        </ul>
                      </div>
                    </div>
                    
                    <div className="flex justify-end mt-4">
                      <Button onClick={handleContinue}>
                        Continue to Card Setup
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={handleBack} 
                        className="mb-2"
                      >
                        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Selection
                      </Button>
                      <CardTitle className="mt-2">
                        {cardType === 'one-link' ? "One Link Card Setup" : "Multi Link Card Setup"}
                      </CardTitle>
                    </div>
                    <div className="text-sm bg-muted px-3 py-1 rounded-full">
                      {cardType === 'one-link' ? "£20" : "£30"}
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    {cardType === 'one-link' && (
                      <Form {...form}>
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label>Social Links</Label>
                            
                            <div className="space-y-3">
                              {links.map((link, index) => (
                                <div key={index} className="flex items-center gap-2 p-2 border rounded">
                                  <div className="flex-shrink-0">
                                    {getPlatformIcon(link.platform)}
                                  </div>
                                  <div className="flex-grow overflow-hidden">
                                    <p className="text-sm font-medium truncate">{link.platform}</p>
                                    <p className="text-xs text-gray-500 truncate">{link.url}</p>
                                  </div>
                                  <Button 
                                    variant="ghost" 
                                    size="sm"
                                    onClick={() => removeLink(index)}
                                    className="flex-shrink-0"
                                  >
                                    <Minus className="h-4 w-4" />
                                  </Button>
                                </div>
                              ))}
                            </div>

                            <div className="flex flex-col space-y-4">
                              <div className="space-y-2">
                                <Label htmlFor="platform">Platform</Label>
                                <select
                                  id="platform"
                                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                  value={newLink.platform}
                                  onChange={(e) => setNewLink({ ...newLink, platform: e.target.value })}
                                >
                                  <option value="instagram">Instagram</option>
                                  <option value="facebook">Facebook</option>
                                  <option value="twitter">Twitter/X</option>
                                  <option value="tiktok">TikTok</option>
                                  <option value="website">Website</option>
                                  <option value="whatsapp">WhatsApp</option>
                                  <option value="phone-call">Phone Call</option>
                                  <option value="email">Email</option>
                                </select>
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="url">{getPlatformInputDetails(newLink.platform).label}</Label>
                                <Input
                                  id="url"
                                  placeholder={getPlatformInputDetails(newLink.platform).placeholder}
                                  value={newLink.url}
                                  onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                                  required
                                />
                              </div>
                              <div className="flex gap-2">
                                <Button 
                                  onClick={addLink}
                                  className="flex-1"
                                  disabled={!newLink.url.trim()} 
                                >
                                  Add Link
                                </Button>
                                <Button 
                                  onClick={addToCartHandler}
                                  className="flex-1"
                                  disabled={links.length === 0} 
                                >
                                  <ShoppingCart className="h-4 w-4 mr-2" /> Add to Cart
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Form>
                    )}
                    
                    {cardType === 'multi-link' && (
                      <Form {...form}>
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <FormField
                              control={form.control}
                              name="name"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Your Name</FormLabel>
                                  <FormControl>
                                    <Input 
                                      placeholder="Name for your card dashboard page"
                                      {...field} 
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <FormField
                              control={form.control}
                              name="bio"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Bio / About</FormLabel>
                                  <FormControl>
                                    <Textarea
                                      placeholder="Tell us about yourself..."
                                      className="resize-none"
                                      {...field}
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            {['instagram', 'tiktok', 'twitter', 'facebook', 'website'].map((platform) => (
                              <FormField
                                key={platform}
                                control={form.control}
                                name={platform as any}
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>{platform.charAt(0).toUpperCase() + platform.slice(1)}</FormLabel>
                                    <FormControl>
                                      <Input 
                                        placeholder={`https://${platform}.com/yourusername`}
                                        {...field} 
                                      />
                                    </FormControl>
                                  </FormItem>
                                )}
                              />
                            ))}
                            <FormField
                              control={form.control}
                              name="whatsapp"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>WhatsApp</FormLabel>
                                  <FormControl>
                                    <Input 
                                      placeholder="+44"
                                      {...field} 
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={form.control}
                              name="phone"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Phone</FormLabel>
                                  <FormControl>
                                    <Input 
                                      placeholder="+44"
                                      {...field} 
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={form.control}
                              name="email"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Email</FormLabel>
                                  <FormControl>
                                    <Input 
                                      placeholder="your@email.com"
                                      {...field} 
                                    />
                                  </FormControl>
                                </FormItem>
                              )}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label>Additional Social Links</Label>
                            
                            <div className="space-y-3">
                              {links.map((link, index) => (
                                <div key={index} className="flex items-center gap-2 p-2 border rounded">
                                  <div className="flex-shrink-0">
                                    {getPlatformIcon(link.platform)}
                                  </div>
                                  <div className="flex-grow overflow-hidden">
                                    <p className="text-sm font-medium truncate">{link.platform}</p>
                                    <p className="text-xs text-gray-500 truncate">{link.url}</p>
                                  </div>
                                  <Button 
                                    variant="ghost" 
                                    size="sm"
                                    onClick={() => removeLink(index)}
                                    className="flex-shrink-0"
                                  >
                                    <Minus className="h-4 w-4" />
                                  </Button>
                                </div>
                              ))}
                            </div>

                            <div className="flex items-end gap-2 mt-4">
                              <div className="flex-grow space-y-2">
                                <Label htmlFor="platform">Platform</Label>
                                <div className="flex gap-2">
                                  {isCustomPlatform ? (
                                    <Input
                                      placeholder="Custom Platform Name"
                                      value={customPlatform}
                                      onChange={(e) => setCustomPlatform(e.target.value)}
                                      className="flex-grow"
                                    />
                                  ) : (
                                    <select
                                      id="platform"
                                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                      value={newLink.platform}
                                      onChange={(e) => {
                                        const value = e.target.value;
                                        if (value === "custom") {
                                          setIsCustomPlatform(true);
                                        } else {
                                          setNewLink({ ...newLink, platform: value });
                                        }
                                      }}
                                    >
                                      <option value="instagram">Instagram</option>
                                      <option value="facebook">Facebook</option>
                                      <option value="twitter">Twitter/X</option>
                                      <option value="tiktok">TikTok</option>
                                      <option value="website">Website</option>
                                      <option value="whatsapp">WhatsApp</option>
                                      <option value="phone">Phone</option>
                                      <option value="email">Email</option>
                                      <option value="custom">Custom Platform...</option>
                                    </select>
                                  )}
                                  {isCustomPlatform && (
                                    <Button
                                      variant="outline"
                                      onClick={() => {
                                        setIsCustomPlatform(false);
                                        setNewLink({ platform: 'instagram', url: '' });
                                      }}
                                      size="sm"
                                    >
                                      Cancel
                                    </Button>
                                  )}
                                </div>
                              </div>
                              <div className="flex-grow space-y-2">
                                <Label htmlFor="url">Enter your link</Label>
                                <Input
                                  id="url"
                                  placeholder={getPlatformInputDetails(isCustomPlatform ? 'custom' : newLink.platform).placeholder}
                                  value={newLink.url}
                                  onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                                  required
                                />
                              </div>
                              <Button 
                                onClick={addLink}
                                size="icon"
                                disabled={(!newLink.url.trim()) || (isCustomPlatform && !customPlatform.trim())}
                              >
                                <Plus className="h-4 w-4" />
                              </Button>
                            </div>
                            
                            {!isCustomPlatform && newLink.platform === 'custom' && (
                              <div className="mt-2">
                                <Button
                                  variant="outline"
                                  onClick={() => setIsCustomPlatform(true)}
                                  size="sm"
                                  className="w-full"
                                >
                                  Add Custom Platform
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <Button 
                          onClick={addToCartHandler}
                          disabled={(cardType === 'multi-link' && !validateFormLinks(form.getValues()).length && links.length === 0)}
                          className="mt-6"
                        >
                          <ShoppingCart className="h-4 w-4 mr-2" /> Add to Cart
                        </Button>
                      </Form>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
            
            <div>
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle>Your Cart</CardTitle>
                </CardHeader>
                <CardContent>
                  {cart.length === 0 ? (
                    <p className="text-center text-gray-500 py-6">Your cart is empty</p>
                  ) : (
                    <div className="space-y-4">
                      {cart.map((item) => (
                        <CartItem key={item.id} item={item} />
                      ))}
                      
                      <div className="pt-4 border-t">
                        <div className="flex justify-between mb-2">
                          <span>Subtotal</span>
                          <span>£{cart.reduce((total, item) => total + (item.price * item.quantity), 0).toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between mb-2">
                          <span>Delivery Fee (Track & Signed)</span>
                          <span>{hasPhysicalCards() ? '£9.99' : '£0.00'}</span>
                        </div>
                        <div className="flex justify-between font-bold text-lg">
                          <span>Total</span>
                          <span>£{getTotalPrice().toFixed(2)}</span>
                        </div>
                      </div>

                      {cart.length > 0 && (
                        <div className="space-y-4 mt-6">
                          <p className="text-center text-sm text-gray-600">
                            Continue to checkout to enter delivery information 
                          </p>
                          
                          <CheckoutButton 
                            cart={cart}
                            customerEmail=""
                            deliveryAddress={deliveryAddress}
                            disabled={isProcessing}
                          />
                          
                          <p className="text-xs text-gray-500 text-center">
                            {hasPhysicalCards() ? 
                              "All prices include Track & Signed delivery (1-3 working days)." :
                              "No delivery fee for update requests only."
                            }
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default OrderCard;
