import { useState, useEffect, useRef } from 'react';
import DashboardLayout from '@/components/DashboardLayout';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Business, Conversation, ConversationMessage, ColdCallScript } from '@/types/coldCalling';
import * as coldCallingService from '@/services/coldCallingService';
import { Phone, PlayCircle, StopCircle, Save, PlusCircle, User, Bot, PhoneCall } from 'lucide-react';

const ColdCalling = () => {
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [scripts, setScripts] = useState<ColdCallScript[]>([]);
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
  const [selectedScript, setSelectedScript] = useState<ColdCallScript | null>(null);
  const [isCallActive, setIsCallActive] = useState(false);
  const [isDialing, setIsDialing] = useState(false);
  const [currentMessage, setCurrentMessage] = useState("");
  const [callDuration, setCallDuration] = useState(0);
  const [conversationTranscript, setConversationTranscript] = useState<ConversationMessage[]>([]);
  const [callOutcome, setCallOutcome] = useState<Conversation['outcome']>('no_answer');
  const [followUpDate, setFollowUpDate] = useState<string>('');
  const [notes, setNotes] = useState("");
  const [showAddBusiness, setShowAddBusiness] = useState(false);
  const [newBusiness, setNewBusiness] = useState<Partial<Business>>({
    name: '',
    type: 'restaurant',
    contactName: '',
    phoneNumber: '',
    email: '',
    address: '',
    notes: ''
  });
  
  const timerRef = useRef<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const dialingAudioRef = useRef<HTMLAudioElement | null>(null);
  
  useEffect(() => {
    const audio = new Audio('https://cdn.freesound.org/previews/524/524495_11349543-lq.mp3');
    audio.loop = true;
    dialingAudioRef.current = audio;
    
    return () => {
      if (dialingAudioRef.current) {
        dialingAudioRef.current.pause();
        dialingAudioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    setBusinesses(coldCallingService.getBusinesses());
    setScripts(coldCallingService.getScripts());
  }, []);

  const formatDateForInput = (date: Date) => {
    return date.toISOString().split('T')[0];
  };

  const formatDate = (date: Date | undefined) => {
    if (!date) return 'Never';
    return new Date(date).toLocaleDateString();
  };

  const startTimer = () => {
    if (timerRef.current) return;
    const startTime = Date.now();
    timerRef.current = window.setInterval(() => {
      setCallDuration(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);
  };

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversationTranscript]);

  useEffect(() => {
    if (selectedBusiness) {
      setConversations(coldCallingService.getConversations(selectedBusiness.id));
      
      const businessScript = coldCallingService.getScriptForBusinessType(selectedBusiness.type);
      setSelectedScript(businessScript);
    }
  }, [selectedBusiness]);

  const handleSelectBusiness = (businessId: string) => {
    const business = coldCallingService.getBusiness(businessId);
    if (business) {
      setSelectedBusiness(business);
      setConversationTranscript([]);
      setCallDuration(0);
      setNotes("");
      setCallOutcome('no_answer');
      setFollowUpDate('');
    }
  };

  const makeRealPhoneCall = () => {
    if (!selectedBusiness) {
      toast({
        title: "No business selected",
        description: "Please select a business to call",
        variant: "destructive"
      });
      return;
    }

    const phoneNumber = selectedBusiness.phoneNumber;
    const telUrl = `tel:${phoneNumber.replace(/\D/g, '')}`;
    
    toast({
      title: "Initiating Call",
      description: `Calling ${selectedBusiness.contactName} at ${phoneNumber}`,
    });
    
    window.open(telUrl, '_self');
  };

  const simulateCallPickup = () => {
    if (dialingAudioRef.current) {
      dialingAudioRef.current.pause();
      dialingAudioRef.current.currentTime = 0;
    }
    
    setIsDialing(false);
    setIsCallActive(true);
    startTimer();
    
    if (selectedScript) {
      const introMessage = selectedScript.introduction.replace('[Business Name]', selectedBusiness!.name);
      addMessage('agent', introMessage);
      
      setTimeout(() => {
        const initialResponses = [
          `Hello, this is ${selectedBusiness!.contactName} speaking.`,
          `${selectedBusiness!.name}, how can I help you?`,
          `Thank you for calling ${selectedBusiness!.name}. This is ${selectedBusiness!.contactName}.`
        ];
        
        const randomResponse = initialResponses[Math.floor(Math.random() * initialResponses.length)];
        addMessage('prospect', randomResponse);
      }, 2000);
    }
  };

  const startCall = () => {
    if (!selectedBusiness) {
      toast({
        title: "No business selected",
        description: "Please select a business to call",
        variant: "destructive"
      });
      return;
    }

    if (isMobile) {
      makeRealPhoneCall();
    } else {
      toast({
        title: "Dialing...",
        description: `Calling ${selectedBusiness.contactName} at ${selectedBusiness.phoneNumber}`,
      });
      
      setIsDialing(true);
      
      if (dialingAudioRef.current) {
        dialingAudioRef.current.play().catch(e => console.log("Audio play failed:", e));
      }
      
      const dialingTime = 1000 + Math.random() * 2000;
      setTimeout(() => {
        const callPickedUp = Math.random() > 0.1;
        
        if (callPickedUp) {
          simulateCallPickup();
        } else {
          toast({
            title: "No Answer",
            description: `${selectedBusiness.contactName} did not pick up the call.`,
            variant: "destructive"
          });
          
          if (dialingAudioRef.current) {
            dialingAudioRef.current.pause();
            dialingAudioRef.current.currentTime = 0;
          }
          
          setIsDialing(false);
          setCallOutcome('no_answer');
        }
      }, dialingTime);
    }
  };

  const endCall = () => {
    setIsCallActive(false);
    setIsDialing(false);
    stopTimer();
    
    if (dialingAudioRef.current) {
      dialingAudioRef.current.pause();
      dialingAudioRef.current.currentTime = 0;
    }
    
    if (conversationTranscript.length === 0) {
      return;
    }
    
    toast({
      title: "Call ended",
      description: `Call with ${selectedBusiness?.name} ended after ${formatTime(callDuration)}`
    });
    
    if (conversationTranscript.length > 0) {
      addMessage('agent', "Thank you for your time. Have a great day!");
    }
  };

  const addMessage = (speaker: 'agent' | 'prospect', text: string) => {
    const newMessage: ConversationMessage = {
      speaker,
      text,
      timestamp: new Date()
    };
    
    setConversationTranscript(prev => [...prev, newMessage]);
    setCurrentMessage("");
  };

  const sendMessage = () => {
    if (!currentMessage.trim()) return;
    
    addMessage('agent', currentMessage);
    
    if (isCallActive && selectedScript) {
      setTimeout(() => {
        const messageLowerCase = currentMessage.toLowerCase();
        
        let responseType = 'general';
        if (messageLowerCase.includes('price') || messageLowerCase.includes('cost') || messageLowerCase.includes('how much')) {
          responseType = 'pricing';
        } else if (messageLowerCase.includes('meeting') || messageLowerCase.includes('schedule') || messageLowerCase.includes('appointment')) {
          responseType = 'meeting';
          setCallOutcome('meeting_scheduled');
        } else if (messageLowerCase.includes('benefit') || messageLowerCase.includes('why') || messageLowerCase.includes('value')) {
          responseType = 'value';
        }
        
        let randomResponse = '';
        
        switch (responseType) {
          case 'pricing':
            const pricingResponses = [
              "I'd like to know more about the pricing before we go further.",
              "How much would this cost for our business?",
              "What kind of investment are we looking at here?"
            ];
            randomResponse = pricingResponses[Math.floor(Math.random() * pricingResponses.length)];
            break;
          case 'meeting':
            const meetingResponses = [
              "Yes, I think a meeting would be good. When are you available?",
              "I'd be interested in learning more. Let's schedule something.",
              "That sounds like something we should discuss further. When can we meet?"
            ];
            randomResponse = meetingResponses[Math.floor(Math.random() * meetingResponses.length)];
            break;
          case 'value':
            const valueResponses = [
              "How exactly would this help our business compared to what we're doing now?",
              "I'm interested, but I need to understand the specific benefits for us.",
              "What kind of results have similar businesses seen with your product?"
            ];
            randomResponse = valueResponses[Math.floor(Math.random() * valueResponses.length)];
            break;
          default:
            const generalResponses = [
              "That sounds interesting. Tell me more about how it works.",
              "I'm not sure we need this right now.",
              "How much does it cost?",
              "Can you send me some more information?",
              "We're actually looking for something like this.",
              "I need to think about it.",
              "What makes this different from other solutions?",
              "Can we schedule a meeting to discuss this further?"
            ];
            randomResponse = generalResponses[Math.floor(Math.random() * generalResponses.length)];
        }
        
        addMessage('prospect', randomResponse);
      }, 1000 + Math.random() * 2000);
    }
  };

  const saveConversation = () => {
    if (!selectedBusiness || conversationTranscript.length === 0) {
      toast({
        title: "Cannot save",
        description: "No conversation to save",
        variant: "destructive"
      });
      return;
    }
    
    const conversation: Omit<Conversation, 'id'> = {
      businessId: selectedBusiness.id,
      date: new Date(),
      duration: callDuration,
      transcript: conversationTranscript,
      outcome: callOutcome,
      notes: notes,
      followUpDate: followUpDate ? new Date(followUpDate) : undefined
    };
    
    const savedConversation = coldCallingService.addConversation(conversation);
    
    if (savedConversation) {
      toast({
        title: "Conversation saved",
        description: `Conversation with ${selectedBusiness.name} has been saved`
      });
      
      setBusinesses(coldCallingService.getBusinesses());
      setConversations(coldCallingService.getConversations(selectedBusiness.id));
      
      setConversationTranscript([]);
      setCallDuration(0);
      setNotes("");
      setCallOutcome('no_answer');
      setFollowUpDate('');
      
      const updatedBusiness = coldCallingService.getBusiness(selectedBusiness.id);
      if (updatedBusiness) {
        setSelectedBusiness(updatedBusiness);
      }
    }
  };

  const addBusiness = () => {
    if (!newBusiness.name || !newBusiness.contactName || !newBusiness.phoneNumber) {
      toast({
        title: "Missing information",
        description: "Please provide business name, contact name, and phone number",
        variant: "destructive"
      });
      return;
    }
    
    const business = coldCallingService.addBusiness(newBusiness as Omit<Business, 'id'>);
    
    if (business) {
      toast({
        title: "Business added",
        description: `${business.name} has been added to your prospects`
      });
      
      setBusinesses(coldCallingService.getBusinesses());
      
      setNewBusiness({
        name: '',
        type: 'restaurant',
        contactName: '',
        phoneNumber: '',
        email: '',
        address: '',
        notes: ''
      });
      
      setShowAddBusiness(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="container mx-auto py-6 space-y-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Cold Calling Dashboard</CardTitle>
            <CardDescription>
              Call prospects, track conversations, and schedule follow-ups
            </CardDescription>
          </CardHeader>
        </Card>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle className="text-xl">Prospects</CardTitle>
              <div className="flex justify-end">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => setShowAddBusiness(!showAddBusiness)}
                >
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add Business
                </Button>
              </div>
            </CardHeader>
            
            {showAddBusiness && (
              <CardContent>
                <div className="space-y-4">
                  <div className="grid w-full items-center gap-1.5">
                    <Label htmlFor="business-name">Business Name</Label>
                    <Input 
                      type="text" 
                      id="business-name" 
                      value={newBusiness.name}
                      onChange={(e) => setNewBusiness({...newBusiness, name: e.target.value})}
                    />
                  </div>
                  
                  <div className="grid w-full items-center gap-1.5">
                    <Label htmlFor="business-type">Business Type</Label>
                    <Select 
                      value={newBusiness.type} 
                      onValueChange={(value) => setNewBusiness({...newBusiness, type: value as Business['type']})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select business type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="restaurant">Restaurant</SelectItem>
                        <SelectItem value="barbershop">Barbershop</SelectItem>
                        <SelectItem value="salon">Salon</SelectItem>
                        <SelectItem value="retail">Retail</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid w-full items-center gap-1.5">
                    <Label htmlFor="contact-name">Contact Name</Label>
                    <Input 
                      type="text" 
                      id="contact-name" 
                      value={newBusiness.contactName}
                      onChange={(e) => setNewBusiness({...newBusiness, contactName: e.target.value})}
                    />
                  </div>
                  
                  <div className="grid w-full items-center gap-1.5">
                    <Label htmlFor="phone-number">Phone Number</Label>
                    <Input 
                      type="tel" 
                      id="phone-number" 
                      value={newBusiness.phoneNumber}
                      onChange={(e) => setNewBusiness({...newBusiness, phoneNumber: e.target.value})}
                    />
                  </div>
                  
                  <div className="grid w-full items-center gap-1.5">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      type="email" 
                      id="email" 
                      value={newBusiness.email}
                      onChange={(e) => setNewBusiness({...newBusiness, email: e.target.value})}
                    />
                  </div>
                  
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setShowAddBusiness(false)}>Cancel</Button>
                    <Button onClick={addBusiness}>Add Business</Button>
                  </div>
                </div>
              </CardContent>
            )}
            
            <CardContent>
              {businesses.length === 0 ? (
                <div className="text-center py-6 text-gray-500">
                  No businesses added yet. Add your first prospect.
                </div>
              ) : (
                <div className="divide-y">
                  {businesses.map((business) => (
                    <div 
                      key={business.id} 
                      className={`py-3 cursor-pointer hover:bg-gray-50 px-2 rounded ${selectedBusiness?.id === business.id ? 'bg-gray-50' : ''}`}
                      onClick={() => handleSelectBusiness(business.id)}
                    >
                      <div className="font-medium">{business.name}</div>
                      <div className="text-sm text-gray-500">{business.type}</div>
                      <div className="text-sm">{business.contactName}</div>
                      <div className="flex justify-between items-center mt-1">
                        <div className="text-xs text-gray-500">
                          Last contacted: {formatDate(business.lastContactDate)}
                        </div>
                        <div className={`text-xs px-2 py-1 rounded ${getStatusColor(business.status)}`}>
                          {getStatusLabel(business.status)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card className="md:col-span-2">
            <CardHeader className="pb-3 flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-xl">
                  {selectedBusiness ? selectedBusiness.name : 'Select a business'}
                </CardTitle>
                {selectedBusiness && (
                  <CardDescription>
                    {selectedBusiness.contactName} • {selectedBusiness.phoneNumber}
                  </CardDescription>
                )}
              </div>
              <div className="flex items-center space-x-2">
                {isCallActive ? (
                  <>
                    <div className="text-sm font-medium">{formatTime(callDuration)}</div>
                    <Button variant="destructive" size="sm" onClick={endCall}>
                      <StopCircle className="h-4 w-4 mr-2" />
                      End Call
                    </Button>
                  </>
                ) : isDialing ? (
                  <Button variant="secondary" size="sm" onClick={endCall}>
                    <StopCircle className="h-4 w-4 mr-2" />
                    Cancel Call
                  </Button>
                ) : (
                  <Button 
                    variant="default" 
                    size="sm" 
                    onClick={startCall}
                    disabled={!selectedBusiness}
                  >
                    <PhoneCall className="h-4 w-4 mr-2" />
                    {isMobile ? "Call Now" : "Start Call"}
                  </Button>
                )}
              </div>
            </CardHeader>
            
            {selectedBusiness && (
              <>
                <CardContent className="border-t pt-4">
                  <div className="bg-gray-50 rounded-lg p-4 mb-4 max-h-[300px] overflow-y-auto">
                    {isDialing ? (
                      <div className="text-center py-10 text-gray-500">
                        <div className="flex justify-center items-center mb-4">
                          <Phone className="h-8 w-8 text-primary animate-pulse" />
                        </div>
                        <p className="text-lg font-medium">Dialing {selectedBusiness.phoneNumber}...</p>
                        <p className="text-sm">Calling {selectedBusiness.contactName} at {selectedBusiness.name}</p>
                      </div>
                    ) : conversationTranscript.length === 0 ? (
                      <div className="text-center py-10 text-gray-500">
                        Start a call to begin the conversation
                      </div>
                    ) : (
                      conversationTranscript.map((message, index) => (
                        <div key={index} className={`flex mb-3 ${message.speaker === 'agent' ? 'justify-start' : 'justify-end'}`}>
                          <div className={`px-4 py-2 rounded-lg max-w-[70%] ${message.speaker === 'agent' ? 'bg-primary text-primary-foreground' : 'bg-gray-200'}`}>
                            <div className="flex items-center mb-1">
                              {message.speaker === 'agent' ? (
                                <Bot className="h-3 w-3 mr-1" />
                              ) : (
                                <User className="h-3 w-3 mr-1" />
                              )}
                              <span className="text-xs font-semibold">
                                {message.speaker === 'agent' ? 'You' : selectedBusiness.contactName}
                              </span>
                            </div>
                            <div>{message.text}</div>
                            <div className="text-xs mt-1 opacity-70">
                              {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                  
                  <div className="flex space-x-2">
                    <Textarea
                      placeholder="Type your message..."
                      value={currentMessage}
                      onChange={(e) => setCurrentMessage(e.target.value)}
                      disabled={!isCallActive}
                      className="flex-grow resize-none"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          sendMessage();
                        }
                      }}
                    />
                    <Button
                      onClick={sendMessage}
                      disabled={!isCallActive || !currentMessage.trim()}
                    >
                      Send
                    </Button>
                  </div>
                  
                  {selectedScript && (
                    <div className="mt-6 border rounded-lg p-4">
                      <h3 className="font-medium mb-3">Call Script: {selectedScript.name}</h3>
                      <div className="space-y-3 text-sm">
                        <div>
                          <span className="font-medium">Introduction:</span>
                          <p className="text-gray-600">{selectedScript.introduction.replace('[Business Name]', selectedBusiness.name)}</p>
                        </div>
                        <div>
                          <span className="font-medium">Value Proposition:</span>
                          <p className="text-gray-600">{selectedScript.valueProposition}</p>
                        </div>
                        <div>
                          <span className="font-medium">Key Questions:</span>
                          <ul className="list-disc pl-5 text-gray-600">
                            {selectedScript.questions.map((q, i) => (
                              <li key={i}>{q}</li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <span className="font-medium">Closing:</span>
                          <p className="text-gray-600">{selectedScript.closingStatements[0]}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
                
                <CardFooter className="border-t pt-4 flex-col items-start">
                  <h3 className="font-medium mb-3">Call Summary</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                    <div className="space-y-2">
                      <Label htmlFor="outcome">Call Outcome</Label>
                      <Select 
                        value={callOutcome} 
                        onValueChange={(value) => setCallOutcome(value as Conversation['outcome'])}
                      >
                        <SelectTrigger id="outcome">
                          <SelectValue placeholder="Select outcome" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="no_answer">No Answer</SelectItem>
                          <SelectItem value="left_message">Left Message</SelectItem>
                          <SelectItem value="call_back">Call Back Later</SelectItem>
                          <SelectItem value="interested">Interested</SelectItem>
                          <SelectItem value="meeting_scheduled">Meeting Scheduled</SelectItem>
                          <SelectItem value="not_interested">Not Interested</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="follow-up">Follow-up Date</Label>
                      <Input 
                        type="date" 
                        id="follow-up" 
                        value={followUpDate}
                        onChange={(e) => setFollowUpDate(e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="notes">Notes</Label>
                      <Textarea 
                        id="notes" 
                        placeholder="Add notes about the call..."
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        className="resize-none"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-end w-full mt-4">
                    <Button onClick={saveConversation} disabled={conversationTranscript.length === 0}>
                      <Save className="h-4 w-4 mr-2" />
                      Save Conversation
                    </Button>
                  </div>
                </CardFooter>
              </>
            )}
          </Card>
        </div>
        
        {selectedBusiness && conversations.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Conversation History</CardTitle>
              <CardDescription>
                Previous conversations with {selectedBusiness.name}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableCaption>A list of previous conversations</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Outcome</TableHead>
                    <TableHead>Follow-up</TableHead>
                    <TableHead>Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {conversations.map((conversation) => (
                    <TableRow key={conversation.id}>
                      <TableCell>{new Date(conversation.date).toLocaleDateString()}</TableCell>
                      <TableCell>{conversation.duration ? formatTime(conversation.duration) : 'N/A'}</TableCell>
                      <TableCell>
                        <span className={`text-xs px-2 py-1 rounded ${getOutcomeColor(conversation.outcome)}`}>
                          {getOutcomeLabel(conversation.outcome)}
                        </span>
                      </TableCell>
                      <TableCell>{conversation.followUpDate ? new Date(conversation.followUpDate).toLocaleDateString() : 'N/A'}</TableCell>
                      <TableCell className="max-w-xs truncate">{conversation.notes || 'No notes'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
};

const getStatusColor = (status: Business['status']) => {
  switch (status) {
    case 'not_contacted':
      return 'bg-gray-100 text-gray-800';
    case 'contacted':
      return 'bg-blue-100 text-blue-800';
    case 'interested':
      return 'bg-green-100 text-green-800';
    case 'meeting_scheduled':
      return 'bg-purple-100 text-purple-800';
    case 'not_interested':
      return 'bg-red-100 text-red-800';
  }
};

const getStatusLabel = (status: Business['status']) => {
  switch (status) {
    case 'not_contacted':
      return 'Not Contacted';
    case 'contacted':
      return 'Contacted';
    case 'interested':
      return 'Interested';
    case 'meeting_scheduled':
      return 'Meeting Scheduled';
    case 'not_interested':
      return 'Not Interested';
  }
};

const getOutcomeColor = (outcome: Conversation['outcome']) => {
  switch (outcome) {
    case 'no_answer':
      return 'bg-gray-100 text-gray-800';
    case 'left_message':
      return 'bg-blue-100 text-blue-800';
    case 'call_back':
      return 'bg-yellow-100 text-yellow-800';
    case 'interested':
      return 'bg-green-100 text-green-800';
    case 'meeting_scheduled':
      return 'bg-purple-100 text-purple-800';
    case 'not_interested':
      return 'bg-red-100 text-red-800';
  }
};

const getOutcomeLabel = (outcome: Conversation['outcome']) => {
  switch (outcome) {
    case 'no_answer':
      return 'No Answer';
    case 'left_message':
      return 'Left Message';
    case 'call_back':
      return 'Call Back';
    case 'interested':
      return 'Interested';
    case 'meeting_scheduled':
      return 'Meeting Scheduled';
    case 'not_interested':
      return 'Not Interested';
  }
};

export default ColdCalling;
