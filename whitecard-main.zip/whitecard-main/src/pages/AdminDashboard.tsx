
import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { Edit, Trash2, Plus, ExternalLink, Store, Tag, Check, X } from 'lucide-react';
import { useCardPages } from '@/context/CardPagesContext';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

const AdminDashboard = () => {
  const { 
    cardPages, 
    shops,
    fetchCardPages, 
    deleteCardPage, 
    fetchShops,
    createShop,
    deleteShop,
    allocateCardToShop,
    markCardAsSold,
    isAdmin, 
    isLoading 
  } = useCardPages();
  
  const navigate = useNavigate();
  const { toast } = useToast();
  const [deleteInProgress, setDeleteInProgress] = useState<string | null>(null);
  const [isShopDialogOpen, setIsShopDialogOpen] = useState(false);
  const [isAllocationDialogOpen, setIsAllocationDialogOpen] = useState(false);
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  const [selectedShopId, setSelectedShopId] = useState<string | null>(null);

  // New shop form state
  const [newShop, setNewShop] = useState({
    name: '',
    location: '',
    contact_email: '',
    contact_phone: ''
  });

  // Redirect if not admin
  useEffect(() => {
    if (!isAdmin) {
      navigate('/admin-login');
      toast({
        title: "Access denied",
        description: "You must be logged in as an admin to view this page",
        variant: "destructive"
      });
    }
  }, [isAdmin, navigate, toast]);

  // Manual refresh functions instead of auto-refresh
  const handleRefreshCards = async () => {
    if (isAdmin) {
      try {
        await fetchCardPages();
        toast({
          title: "Refreshed",
          description: "Card pages data has been refreshed"
        });
      } catch (error) {
        console.error("Error refreshing card pages:", error);
        toast({
          title: "Error",
          description: "Failed to refresh card pages",
          variant: "destructive"
        });
      }
    }
  };

  const handleRefreshShops = async () => {
    if (isAdmin) {
      try {
        await fetchShops();
        toast({
          title: "Refreshed",
          description: "Shop data has been refreshed"
        });
      } catch (error) {
        console.error("Error refreshing shops:", error);
        toast({
          title: "Error",
          description: "Failed to refresh shops",
          variant: "destructive"
        });
      }
    }
  };

  const handleDelete = async (id: string) => {
    try {
      setDeleteInProgress(id);
      await deleteCardPage(id);
      toast({
        title: "Card page deleted",
        description: "The card page has been deleted successfully"
      });
    } catch (error) {
      console.error("Error deleting card page:", error);
      toast({
        title: "Error",
        description: "Failed to delete card page",
        variant: "destructive"
      });
    } finally {
      setDeleteInProgress(null);
    }
  };

  const handleDeleteShop = async (id: string) => {
    try {
      await deleteShop(id);
      toast({
        title: "Shop deleted",
        description: "The shop has been deleted successfully"
      });
    } catch (error) {
      console.error("Error deleting shop:", error);
      toast({
        title: "Error",
        description: "Failed to delete shop",
        variant: "destructive"
      });
    }
  };

  const handleCreateShop = async () => {
    try {
      await createShop(newShop);
      setNewShop({
        name: '',
        location: '',
        contact_email: '',
        contact_phone: ''
      });
      setIsShopDialogOpen(false);
      toast({
        title: "Shop created",
        description: "The shop has been created successfully"
      });
    } catch (error) {
      console.error("Error creating shop:", error);
      toast({
        title: "Error",
        description: "Failed to create shop",
        variant: "destructive"
      });
    }
  };

  const handleAllocateCard = async () => {
    try {
      if (selectedCardId) {
        await allocateCardToShop(selectedCardId, selectedShopId);
        setIsAllocationDialogOpen(false);
        toast({
          title: "Card allocated",
          description: selectedShopId ? "The card has been allocated to the shop" : "The card allocation has been removed"
        });
      }
    } catch (error) {
      console.error("Error allocating card:", error);
      toast({
        title: "Error",
        description: "Failed to allocate card",
        variant: "destructive"
      });
    }
  };

  const openAllocationDialog = (cardId: string) => {
    const card = cardPages.find(card => card.id === cardId);
    setSelectedCardId(cardId);
    setSelectedShopId(card?.shop_id || null);
    setIsAllocationDialogOpen(true);
  };

  const handleToggleSoldStatus = async (cardId: string, currentStatus: boolean) => {
    try {
      await markCardAsSold(cardId, !currentStatus);
      toast({
        title: currentStatus ? "Card marked as available" : "Card marked as sold",
        description: `The card status has been updated to ${currentStatus ? 'available' : 'sold'}`
      });
    } catch (error) {
      console.error("Error updating card status:", error);
      toast({
        title: "Error",
        description: "Failed to update card status",
        variant: "destructive"
      });
    }
  };

  if (!isAdmin) {
    return null;
  }

  const getShopNameById = (shopId: string | null | undefined) => {
    if (!shopId) return 'Not allocated';
    const shop = shops.find(s => s.id === shopId);
    return shop ? shop.name : 'Unknown shop';
  };

  return (
    <Layout>
      <div className="container py-8 px-4 max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        </div>

        <Tabs defaultValue="cards">
          <TabsList className="mb-6">
            <TabsTrigger value="cards">Card Pages</TabsTrigger>
            <TabsTrigger value="shops">Reseller Shops</TabsTrigger>
          </TabsList>

          <TabsContent value="cards">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Card Pages</CardTitle>
                <div className="flex gap-4">
                  <Button variant="outline" onClick={handleRefreshCards} disabled={isLoading}>
                    {isLoading ? (
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent" />
                    ) : 'Refresh'}
                  </Button>
                  <Link to="/admin-dashboard/create">
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Create New Card
                    </Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading && !cardPages.length ? (
                  <div className="text-center py-8">
                    <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                    <p className="mt-2">Loading card pages...</p>
                  </div>
                ) : cardPages.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No card pages found. Click "Create New Card" to add one.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Card #</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Slug</TableHead>
                          <TableHead>Links</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Shop</TableHead>
                          <TableHead>Created</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {cardPages.map((page) => (
                          <TableRow key={page.id}>
                            <TableCell className="font-medium">
                              {page.card_number || 'N/A'}
                            </TableCell>
                            <TableCell>
                              {page.name || page.business_name || 'Unnamed'}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <span className="mr-2">{page.slug}</span>
                                <a
                                  href={`/${page.slug}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-gray-500 hover:text-gray-800"
                                >
                                  <ExternalLink className="h-4 w-4" />
                                </a>
                              </div>
                            </TableCell>
                            <TableCell>{(page.links && page.links.length) || 0} links</TableCell>
                            <TableCell>
                              <Button
                                variant={page.is_sold ? "destructive" : "outline"}
                                size="sm"
                                onClick={() => handleToggleSoldStatus(page.id, !!page.is_sold)}
                                className={!page.is_sold ? "bg-green-100 text-green-800 hover:bg-green-200 hover:text-green-900" : ""}
                              >
                                {page.is_sold ? (
                                  <X className="h-4 w-4 mr-1" />
                                ) : (
                                  <Check className="h-4 w-4 mr-1" />
                                )}
                                {page.is_sold ? 'Sold' : 'Available'}
                              </Button>
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => openAllocationDialog(page.id)}
                              >
                                <Tag className="h-4 w-4 mr-1" />
                                {getShopNameById(page.shop_id)}
                              </Button>
                            </TableCell>
                            <TableCell>
                              {new Date(page.created_at).toLocaleDateString()}
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Link to={`/admin-dashboard/edit/${page.id}`}>
                                  <Button variant="outline" size="sm">
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </Link>
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button 
                                      variant="outline" 
                                      size="sm" 
                                      className="text-red-500 hover:bg-red-50 hover:text-red-600"
                                      disabled={deleteInProgress === page.id}
                                    >
                                      {deleteInProgress === page.id ? (
                                        <div className="h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent" />
                                      ) : (
                                        <Trash2 className="h-4 w-4" />
                                      )}
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This will permanently delete the card page for "{page.card_number}" and all its data.
                                        This action cannot be undone.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction 
                                        onClick={() => handleDelete(page.id)}
                                        className="bg-red-500 hover:bg-red-600 text-white"
                                      >
                                        Delete
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="shops">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Reseller Shops</CardTitle>
                <div className="flex gap-4">
                  <Button variant="outline" onClick={handleRefreshShops} disabled={isLoading}>
                    {isLoading ? (
                      <div className="h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent" />
                    ) : 'Refresh'}
                  </Button>
                  <Button onClick={() => setIsShopDialogOpen(true)}>
                    <Plus className="mr-2 h-4 w-4" />
                    <Store className="mr-2 h-4 w-4" />
                    Create Shop
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isLoading && !shops.length ? (
                  <div className="text-center py-8">
                    <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                    <p className="mt-2">Loading shops...</p>
                  </div>
                ) : shops.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No shops found. Click "Create Shop" to add one.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Shop Name</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Contact Email</TableHead>
                          <TableHead>Contact Phone</TableHead>
                          <TableHead>Created</TableHead>
                          <TableHead>Cards</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {shops.map((shop) => {
                          const assignedCards = cardPages.filter(card => card.shop_id === shop.id);
                          const soldCards = assignedCards.filter(card => card.is_sold);
                          return (
                            <TableRow key={shop.id}>
                              <TableCell className="font-medium">{shop.name}</TableCell>
                              <TableCell>{shop.location}</TableCell>
                              <TableCell>{shop.contact_email}</TableCell>
                              <TableCell>{shop.contact_phone}</TableCell>
                              <TableCell>{new Date(shop.created_at).toLocaleDateString()}</TableCell>
                              <TableCell>
                                {assignedCards.length} allocated, {soldCards.length} sold
                                {soldCards.length > 0 && (
                                  <div className="text-xs text-green-600 mt-1">
                                    {(soldCards.length * 30).toFixed(2)}% commission earned
                                  </div>
                                )}
                              </TableCell>
                              <TableCell>
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button 
                                      variant="outline" 
                                      size="sm" 
                                      className="text-red-500 hover:bg-red-50 hover:text-red-600"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This will permanently delete the shop "{shop.name}" and remove all card allocations.
                                        This action cannot be undone.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction 
                                        onClick={() => handleDeleteShop(shop.id)}
                                        className="bg-red-500 hover:bg-red-600 text-white"
                                      >
                                        Delete
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Create Shop Dialog */}
        <Dialog open={isShopDialogOpen} onOpenChange={setIsShopDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Reseller Shop</DialogTitle>
              <DialogDescription>
                Add a new shop that will resell White Cards and earn 30% commission on each sale
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Shop Name</Label>
                <Input 
                  id="name" 
                  value={newShop.name} 
                  onChange={(e) => setNewShop({...newShop, name: e.target.value})}
                  placeholder="E.g., London Digital Store" 
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="location">Location</Label>
                <Input 
                  id="location" 
                  value={newShop.location} 
                  onChange={(e) => setNewShop({...newShop, location: e.target.value})}
                  placeholder="E.g., London, UK" 
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="email">Contact Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  value={newShop.contact_email} 
                  onChange={(e) => setNewShop({...newShop, contact_email: e.target.value})}
                  placeholder="E.g., contact@shop.com" 
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="phone">Contact Phone</Label>
                <Input 
                  id="phone" 
                  value={newShop.contact_phone} 
                  onChange={(e) => setNewShop({...newShop, contact_phone: e.target.value})}
                  placeholder="E.g., +1 123 456 7890" 
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsShopDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleCreateShop}>Create Shop</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Allocate Card Dialog */}
        <Dialog open={isAllocationDialogOpen} onOpenChange={setIsAllocationDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Allocate Card to Shop</DialogTitle>
              <DialogDescription>
                Choose which shop will sell this card and earn 30% commission
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="shop">Select Shop</Label>
                <select
                  id="shop"
                  className="w-full p-2 border rounded-md"
                  value={selectedShopId || ''}
                  onChange={(e) => setSelectedShopId(e.target.value || null)}
                >
                  <option value="">No allocation</option>
                  {shops.map(shop => (
                    <option key={shop.id} value={shop.id}>{shop.name} - {shop.location}</option>
                  ))}
                </select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAllocationDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleAllocateCard}>Save Allocation</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
};

export default AdminDashboard;
