
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { QrCode, Copy, Download, Lock, ExternalLink } from 'lucide-react';
import { useCardPages, CardPage as CardPageType } from '@/context/CardPagesContext';
import { CardPageForm } from '@/components/CardPageForm';

const CardPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const { fetchCardPage, updateCardPage } = useCardPages();
  const [cardPage, setCardPage] = useState<CardPageType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [editMode, setEditMode] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordModalOpen, setPasswordModalOpen] = useState(false);
  const [qrModalOpen, setQrModalOpen] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const loadCardPage = async () => {
      if (!slug) return;

      try {
        setLoading(true);
        const page = await fetchCardPage(slug);
        
        if (page) {
          setCardPage(page);
        } else {
          setError('Card page not found');
        }
      } catch (err) {
        console.error('Error loading card page:', err);
        setError('Failed to load card page');
      } finally {
        setLoading(false);
      }
    };

    loadCardPage();
  }, [slug, fetchCardPage]);

  const handleEditClick = () => {
    setPasswordModalOpen(true);
  };

  const handlePasswordSubmit = () => {
    if (cardPage && passwordInput === cardPage.password) {
      setPasswordModalOpen(false);
      setEditMode(true);
      toast({
        title: "Edit mode activated",
        description: "You can now edit your card page"
      });
    } else {
      toast({
        title: "Incorrect password",
        description: "Please try again",
        variant: "destructive"
      });
    }
  };

  const handleUpdate = async (formData: any) => {
    if (!cardPage) return;
    
    setIsUpdating(true);
    
    try {
      await updateCardPage(cardPage.id, formData);
      
      // Fetch updated data
      const updatedPage = await fetchCardPage(slug || '');
      if (updatedPage) {
        setCardPage(updatedPage);
      }
      
      setEditMode(false);
      toast({
        title: "Changes saved",
        description: "Your card page has been updated successfully"
      });
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Failed to update card page",
        variant: "destructive"
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case 'instagram':
        return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg>;
      case 'facebook':
        return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>;
      case 'twitter':
        return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/></svg>;
      case 'linkedin':
        return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect width="4" height="12" x="2" y="9"/><circle cx="4" cy="4" r="2"/></svg>;
      case 'youtube':
        return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/><path d="m10 15 5-3-5-3z"/></svg>;
      case 'github':
        return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"/><path d="M9 18c-4.51 2-5-2-7-2"/></svg>;
      case 'mail':
        return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>;
      case 'phone':
        return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>;
      default:
        return <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" x2="22" y1="12" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>;
    }
  };

  const copyPageUrl = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    toast({
      title: "URL Copied",
      description: "Link copied to clipboard"
    });
  };

  const generateQrCode = () => {
    setQrModalOpen(true);
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-black mx-auto"></div>
          <p className="mt-4">Loading card page...</p>
        </div>
      </div>
    );
  }

  if (error || !cardPage) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center max-w-md px-4">
          <h1 className="text-3xl font-bold mb-4">Card Not Found</h1>
          <p className="mb-8">The card page you're looking for doesn't exist or has been removed.</p>
          <Button onClick={() => navigate('/')}>Go to Homepage</Button>
        </div>
      </div>
    );
  }

  if (editMode) {
    return (
      <div className="min-h-screen bg-gray-50 py-10 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Edit Your Card</h1>
            <Button variant="outline" onClick={() => setEditMode(false)}>
              Cancel
            </Button>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <CardPageForm 
              initialData={{
                name: cardPage.name || '',
                business_name: cardPage.business_name || '',
                slug: cardPage.slug,
                password: cardPage.password,
                bio: cardPage.bio || '',
                contact_email: cardPage.contact_email || '',
                contact_phone: cardPage.contact_phone || '',
                profile_image_url: cardPage.profile_image_url || '',
                links: cardPage.links
              }}
              onSubmit={handleUpdate}
              isLoading={isUpdating}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <div className="flex-grow flex flex-col items-center px-4 py-12 md:py-20 max-w-md mx-auto">
        {/* Profile */}
        <div className="w-full bg-white rounded-xl shadow-md overflow-hidden mb-6">
          <div className="p-6 flex flex-col items-center">
            {cardPage.profile_image_url ? (
              <img 
                src={cardPage.profile_image_url} 
                alt={cardPage.name || 'Profile'} 
                className="w-24 h-24 rounded-full object-cover border-2 border-gray-200"
              />
            ) : (
              <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center text-gray-400 text-3xl font-bold">
                {cardPage.name?.charAt(0) || cardPage.business_name?.charAt(0) || '?'}
              </div>
            )}
            
            <h1 className="text-xl font-bold mt-4">
              {cardPage.name || 'No Name'}
            </h1>
            
            {cardPage.business_name && (
              <h2 className="text-gray-600 text-sm">
                {cardPage.business_name}
              </h2>
            )}
            
            {cardPage.bio && (
              <p className="text-gray-700 text-center mt-4">
                {cardPage.bio}
              </p>
            )}
            
            <div className="flex items-center mt-4 space-x-2">
              <Button variant="outline" size="sm" onClick={copyPageUrl}>
                <Copy className="h-4 w-4 mr-1" /> Copy URL
              </Button>
              <Button variant="outline" size="sm" onClick={generateQrCode}>
                <QrCode className="h-4 w-4 mr-1" /> QR Code
              </Button>
            </div>
          </div>
        </div>
        
        {/* Links */}
        <div className="w-full space-y-3">
          {cardPage.links && cardPage.links.length > 0 ? (
            cardPage.links.map((link, index) => (
              <a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center p-3 bg-white rounded-lg shadow-sm hover:shadow transition-all border border-gray-100"
              >
                <div className="flex-shrink-0 mr-3 text-gray-600">
                  {getIconComponent(link.icon || 'globe')}
                </div>
                <span>{link.title}</span>
                <ExternalLink className="ml-auto h-4 w-4 text-gray-400" />
              </a>
            ))
          ) : (
            <div className="text-center py-8 bg-white rounded-lg">
              No links added yet
            </div>
          )}
        </div>
        
        {/* Edit Button */}
        <div className="mt-12 w-full">
          <Separator className="my-4" />
          <div className="flex justify-center">
            <Button variant="outline" onClick={handleEditClick}>
              <Lock className="h-4 w-4 mr-1" /> Edit This Card
            </Button>
          </div>
          <div className="flex justify-center mt-4">
            <div className="text-xs text-gray-400">
              Card #{cardPage.card_number} · <a href="/" className="hover:underline">White Cards</a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Password Modal */}
      <Dialog open={passwordModalOpen} onOpenChange={setPasswordModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Enter Password</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <Input
              type="password"
              placeholder="Enter your card password"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
            />
            <p className="text-sm text-gray-500 mt-2">
              Enter the password provided when you purchased this card
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPasswordModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handlePasswordSubmit}>
              Continue
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* QR Code Modal */}
      <Dialog open={qrModalOpen} onOpenChange={setQrModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>QR Code</DialogTitle>
          </DialogHeader>
          <div className="py-4 flex flex-col items-center">
            <div className="bg-white p-4 rounded-xl shadow-sm">
              <img 
                src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(window.location.href)}`} 
                alt="QR Code"
                className="w-48 h-48"
              />
            </div>
            <p className="text-sm text-gray-500 mt-4 text-center">
              Scan this QR code to visit this card page directly
            </p>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={() => {
                const link = document.createElement('a');
                link.download = `${cardPage.slug || 'card'}-qrcode.png`;
                link.href = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(window.location.href)}`;
                link.click();
              }}
            >
              <Download className="h-4 w-4 mr-1" /> Download
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CardPage;
