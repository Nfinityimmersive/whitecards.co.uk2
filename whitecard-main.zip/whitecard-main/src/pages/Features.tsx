
import Layout from '@/components/Layout';
import FeatureCard from '@/components/FeatureCard';
import { CheckCircle2, Smartphone, Zap, Shield, Share2, Database } from 'lucide-react';

const Features = () => {
  return (
    <Layout>
      <section className="py-16 md:py-24 bg-gradient-to-b from-white to-gray-50">
        <div className="container px-4 md:px-6 mx-auto">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl md:text-6xl">
              White Cards Features
            </h1>
            <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-2xl/relaxed">
              All you need to share your digital profile in one tap
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            <FeatureCard 
              title="Digital Profile Sharing" 
              description="Share all your social profiles, payment links, and websites with just one tap of your White Card."
              icon={<Share2 className="h-6 w-6 text-purple-600" />}
            />
            
            <FeatureCard 
              title="Personal Dashboard" 
              description="Easily manage and update your links and profile information through an intuitive dashboard."
              icon={<Database className="h-6 w-6 text-purple-600" />}
            />
            
            <FeatureCard 
              title="Premium Card Quality" 
              description="High-quality materials that are water-resistant and durable for everyday use."
              icon={<Shield className="h-6 w-6 text-purple-600" />}
            />

            <FeatureCard 
              title="Instant Connectivity" 
              description="Connect with others immediately - no apps to download or accounts to create for your recipients."
              icon={<Zap className="h-6 w-6 text-purple-600" />}
            />
            
            <FeatureCard 
              title="Works with All Phones" 
              description="Compatible with both Android and iOS devices - just tap and connect."
              icon={<Smartphone className="h-6 w-6 text-purple-600" />}
            />
            
            <FeatureCard 
              title="Fast Delivery" 
              description="1-3 working day delivery with tracked and signed service included in the price."
              icon={<CheckCircle2 className="h-6 w-6 text-purple-600" />}
            />
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Features;
