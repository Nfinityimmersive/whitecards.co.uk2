
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useCardPages } from '@/context/CardPagesContext';
import { CardPageForm } from '@/components/CardPageForm';

const EditCardPage = () => {
  const { id } = useParams<{ id: string }>();
  const { isAdmin, cardPages, updateCardPage, fetchCardPage, isLoading: contextLoading, shops, fetchShops } = useCardPages();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [cardPage, setCardPage] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isFetchingCardPage, setIsFetchingCardPage] = useState(true);
  
  // Redirect if not admin
  useEffect(() => {
    if (!isAdmin) {
      navigate('/admin-login');
      toast({
        title: "Access denied",
        description: "You must be logged in as an admin to view this page",
        variant: "destructive"
      });
    } else {
      // Fetch shops for shop selection dropdown
      fetchShops().catch(err => {
        console.error("Error fetching shops:", err);
      });
    }
  }, [isAdmin, navigate, toast, fetchShops]);

  // Find the card page directly from context first, then try to fetch it if not found
  useEffect(() => {
    if (!id || !isAdmin) return;

    const loadCardPage = async () => {
      setIsFetchingCardPage(true);
      try {
        // First check if it's in our already loaded cardPages array
        const existingPage = cardPages.find(p => p.id === id);
        
        if (existingPage) {
          console.log("Found card page in context:", existingPage);
          setCardPage(existingPage);
        } else {
          // If not found in context, try to fetch directly
          console.log("Card page not found in context, fetching directly...");
          
          // Get slug from card pages or use empty string if not found
          const pageWithId = cardPages.find(p => p.id === id);
          const slug = pageWithId?.slug || '';
          
          if (slug) {
            const fetchedPage = await fetchCardPage(slug);
            if (fetchedPage) {
              console.log("Fetched card page:", fetchedPage);
              setCardPage(fetchedPage);
            } else {
              throw new Error("Card page not found");
            }
          } else {
            throw new Error("Cannot fetch card page without slug");
          }
        }
      } catch (error) {
        console.error("Error loading card page:", error);
        toast({
          title: "Error",
          description: "Failed to load card page",
          variant: "destructive"
        });
        navigate('/admin-dashboard');
      } finally {
        setIsFetchingCardPage(false);
      }
    };

    loadCardPage();
  }, [id, cardPages, isAdmin, navigate, toast, fetchCardPage]);

  const handleUpdate = async (formData: any) => {
    if (!id) return;
    
    setIsLoading(true);
    
    try {
      // Ensure slug is properly formatted
      const slugFormatted = formData.slug.trim().toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
      
      console.log("Updating card page with data:", {
        ...formData,
        slug: slugFormatted
      });
      
      await updateCardPage(id, {
        ...formData,
        slug: slugFormatted
      });
      
      toast({
        title: "Card page updated",
        description: "The card page has been updated successfully"
      });
      navigate('/admin-dashboard');
    } catch (error) {
      console.error("Error updating card page:", error);
      toast({
        title: "Error",
        description: "Failed to update card page",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  if (!isAdmin) {
    return null;
  }

  return (
    <Layout>
      <div className="container py-8 px-4 mx-auto max-w-3xl">
        <Button
          variant="outline"
          className="mb-4"
          onClick={() => navigate('/admin-dashboard')}
        >
          Back to Dashboard
        </Button>
        
        <Card>
          <CardHeader>
            <CardTitle>
              {isFetchingCardPage || contextLoading ? 
                "Loading..." : 
                cardPage ? `Edit Card #${cardPage.card_number}` : "Card Not Found"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isFetchingCardPage || contextLoading ? (
              <div className="text-center py-8">
                <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                <p className="mt-2">Loading card details...</p>
              </div>
            ) : cardPage ? (
              <CardPageForm 
                onSubmit={handleUpdate}
                isLoading={isLoading}
                initialData={cardPage}
                shops={shops}
              />
            ) : (
              <div className="text-center py-8 text-gray-500">
                Card page not found. Please return to the dashboard.
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default EditCardPage;
