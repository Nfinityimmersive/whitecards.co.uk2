
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useCardPages } from '@/context/CardPagesContext';
import { CardPageForm } from '@/components/CardPageForm';

const CreateCardPage = () => {
  const { isAdmin, createCardPage, shops, fetchShops } = useCardPages();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  // Redirect if not admin
  useEffect(() => {
    if (!isAdmin) {
      navigate('/admin-login');
      toast({
        title: "Access denied",
        description: "You must be logged in as an admin to view this page",
        variant: "destructive"
      });
    } else {
      // Fetch shops for shop selection dropdown
      fetchShops().catch(err => {
        console.error("Error fetching shops:", err);
        toast({
          title: "Error",
          description: "Failed to fetch shops. Please try again.",
          variant: "destructive"
        });
      });
    }
  }, [isAdmin, navigate, toast, fetchShops]);

  const handleCreate = async (formData: any) => {
    setIsLoading(true);
    
    try {
      // Ensure slug is properly formatted
      const slugFormatted = formData.slug.trim().toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
      
      console.log("Creating card page with data:", {
        ...formData,
        slug: slugFormatted
      });
      
      const newCardPage = await createCardPage({
        ...formData,
        slug: slugFormatted,
        is_sold: false
      });
      
      if (newCardPage) {
        toast({
          title: "Card page created",
          description: `New card #${newCardPage.card_number} has been created successfully`
        });
        navigate('/admin-dashboard');
      } else {
        throw new Error("Failed to create card page - no response data");
      }
    } catch (error) {
      console.error("Error creating card page:", error);
      toast({
        title: "Error",
        description: "Failed to create card page. Please check the console for details.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  if (!isAdmin) {
    return null;
  }

  return (
    <Layout>
      <div className="container py-8 px-4 mx-auto max-w-3xl">
        <Button
          variant="outline"
          className="mb-4"
          onClick={() => navigate('/admin-dashboard')}
        >
          Back to Dashboard
        </Button>
        
        <Card>
          <CardHeader>
            <CardTitle>Create New Card Page</CardTitle>
          </CardHeader>
          <CardContent>
            <CardPageForm 
              onSubmit={handleCreate}
              isLoading={isLoading}
              initialData={{
                name: '',
                business_name: '',
                slug: '',
                password: 'Abc', // Default password
                bio: '',
                contact_email: '',
                contact_phone: '',
                profile_image_url: '',
                links: [{ title: 'Website', url: '', icon: 'globe', sort_order: 0 }],
                is_sold: false,
                shop_id: null
              }}
              shops={shops}
            />
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default CreateCardPage;
