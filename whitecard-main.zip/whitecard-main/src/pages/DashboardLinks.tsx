
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PlusCircle, Trash2, Edit, Eye, Instagram, Twitter, Facebook, Youtube, Globe } from 'lucide-react';
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';

type Link = {
  id: string;
  title: string;
  url: string;
  icon: string;
  clicks: number;
};

const DashboardLinks = () => {
  const { toast } = useToast();
  const [links, setLinks] = useState<Link[]>([
    { id: '1', title: 'My Instagram', url: 'https://instagram.com/username', icon: 'instagram', clicks: 45 },
    { id: '2', title: 'My Twitter', url: 'https://twitter.com/username', icon: 'twitter', clicks: 32 },
    { id: '3', title: 'My Website', url: 'https://mywebsite.com', icon: 'globe', clicks: 27 },
    { id: '4', title: 'My YouTube', url: 'https://youtube.com/channel/username', icon: 'youtube', clicks: 18 },
    { id: '5', title: 'My Facebook', url: 'https://facebook.com/username', icon: 'facebook', clicks: 14 },
  ]);

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'instagram':
        return <Instagram className="h-4 w-4" />;
      case 'twitter':
        return <Twitter className="h-4 w-4" />;
      case 'facebook':
        return <Facebook className="h-4 w-4" />;
      case 'youtube':
        return <Youtube className="h-4 w-4" />;
      default:
        return <Globe className="h-4 w-4" />;
    }
  };

  const handleAddLink = () => {
    toast({
      title: "Coming soon",
      description: "This feature will be available soon",
    });
  };

  const handleEditLink = (id: string) => {
    toast({
      title: "Edit link",
      description: `Editing link with ID: ${id}`,
    });
  };

  const handleDeleteLink = (id: string) => {
    toast({
      title: "Delete link",
      description: `Deleting link with ID: ${id}`,
    });
  };

  return (
    <DashboardLayout>
      <div className="px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Manage Links</h1>
          <p className="mt-1 text-sm text-gray-500">Add, edit, or remove links from your White Card profile.</p>
        </div>

        <Tabs defaultValue="all">
          <div className="flex justify-between items-center mb-4">
            <TabsList>
              <TabsTrigger value="all">All Links</TabsTrigger>
              <TabsTrigger value="social">Social</TabsTrigger>
              <TabsTrigger value="payment">Payment</TabsTrigger>
              <TabsTrigger value="other">Other</TabsTrigger>
            </TabsList>
            <Button onClick={handleAddLink}>
              <PlusCircle className="h-4 w-4 mr-2" /> Add Link
            </Button>
          </div>

          <TabsContent value="all" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>My Links</CardTitle>
                <CardDescription>
                  You have {links.length} links. You can add up to 20 links on the basic plan.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {links.map((link) => (
                    <div key={link.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center">
                        <div className="rounded-full bg-gray-100 p-2 mr-3">
                          {getIcon(link.icon)}
                        </div>
                        <div>
                          <h3 className="font-medium">{link.title}</h3>
                          <p className="text-sm text-muted-foreground">{link.url}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="text-sm text-muted-foreground mr-4">
                          {link.clicks} clicks
                        </div>
                        <Button variant="outline" size="sm" onClick={() => handleEditLink(link.id)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => window.open(link.url, '_blank')}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleDeleteLink(link.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="social" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Social Media Links</CardTitle>
                <CardDescription>
                  Manage your social media presence.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Showing social media links only.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="payment" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Payment Links</CardTitle>
                <CardDescription>
                  Manage your payment and donation links.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">You haven't added any payment links yet.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="other" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Other Links</CardTitle>
                <CardDescription>
                  Manage your other links.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Showing other links.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
};

export default DashboardLinks;
