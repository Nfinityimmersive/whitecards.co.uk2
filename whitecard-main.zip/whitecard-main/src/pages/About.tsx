
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const About = () => {
  return (
    <Layout>
      <section className="py-24">
        <div className="container px-4 md:px-6 mx-auto">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">About White Cards</h1>
            <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed">
              Creating seamless digital connections with premium smart cards
            </p>
          </div>
          
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2 lg:gap-12 mb-12">
            <div className="flex flex-col justify-center space-y-4">
              <h2 className="text-2xl font-bold">Our Story</h2>
              <p className="text-gray-500">
                White Cards began with a simple vision: to create a more elegant way for professionals to share their digital presence. We saw too many people fumbling with phones, searching for apps, or exchanging paper business cards that would ultimately be lost or forgotten.
              </p>
              <p className="text-gray-500">
                Founded in 2023, our team brings together expertise in technology, design, and business networking to create a product that seamlessly bridges the physical and digital worlds.
              </p>
            </div>
            <div className="flex items-center justify-center">
              <img 
                src="/lovable-uploads/65281feb-337f-4791-a75c-6e9f170962b2.png" 
                alt="White Card" 
                className="rounded-lg shadow-lg max-w-full h-auto"
              />
            </div>
          </div>
          
          <div className="flex flex-col space-y-4 mb-12">
            <h2 className="text-2xl font-bold text-center">Our Mission</h2>
            <p className="text-gray-500 text-center max-w-3xl mx-auto">
              We're on a mission to simplify professional connections while reducing waste from traditional business cards. With White Cards, we aim to make networking more efficient, more meaningful, and more environmentally friendly.
            </p>
          </div>
          
          <div className="flex justify-center">
            <Link to="/contact">
              <Button size="lg">Get in Touch</Button>
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default About;
