
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Check, ArrowRight, Download, Printer, CreditCard } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Define a proper interface for the order item
interface OrderItem {
  type: string;
  cardNumber: string;
  quantity: number;
  price: number;
  links: Array<{ url: string; platform: string }>;
  customerEmail: string;
  deliveryAddress: {
    fullName: string;
    addressLine1: string;
    addressLine2?: string;
    city: string;
    postalCode: string;
    country: string;
  };
  dateOrdered: string;
}

const PaymentSuccess = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [orderInfo, setOrderInfo] = useState<OrderItem[]>([]);
  const [receiptHtml, setReceiptHtml] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Log that the component is mounting for debugging
    console.log('PaymentSuccess component mounted');
    
    try {
      // Fetch the session details from local storage if available
      const savedOrders = JSON.parse(localStorage.getItem('cardOrders') || '[]');
      console.log('Loaded saved orders:', savedOrders.length);
      
      if (savedOrders.length > 0) {
        // Check if the last item is an array (previously saved format) or a direct object
        const lastOrder = savedOrders[savedOrders.length - 1];
        
        // If lastOrder is an array, use it directly, otherwise wrap it in an array
        const orderItems = Array.isArray(lastOrder) ? lastOrder : [lastOrder];
        setOrderInfo(orderItems);
        
        console.log('Setting order info:', orderItems);
        
        // Generate receipt HTML if we have valid order items
        if (orderItems.length > 0) {
          const totalAmount = orderItems.reduce(
            (total: number, item: OrderItem) => total + (item.price * item.quantity), 0
          ) + (orderItems.some((item: OrderItem) => item.type !== 'update-request') ? 9.99 : 0);
          
          // Build receipt HTML for downloading
          const receiptContent = generateReceiptHtml(
            orderItems,
            'unknown',
            new Date().toLocaleString(),
            totalAmount
          );
          
          setReceiptHtml(receiptContent);
        }
        
        // Show success notification
        toast({
          title: "Order Received!",
          description: "Your order has been received. Please complete payment via bank transfer.",
        });
      } else {
        console.log('No saved orders found');
        toast({
          title: "Order Received",
          description: "Thank you for your order. Please complete payment via bank transfer.",
        });
      }
    } catch (error) {
      console.error('Error loading order data:', error);
      toast({
        title: "Order Received",
        description: "Thank you for your order. Please complete payment via bank transfer.",
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  // Generate a downloadable receipt HTML
  const generateReceiptHtml = (
    orderItems: OrderItem[],
    orderId: string,
    orderDate: string,
    totalAmount: number
  ) => {
    if (!orderItems || orderItems.length === 0 || !orderItems[0].deliveryAddress) {
      return null;
    }

    const address = orderItems[0].deliveryAddress;
    const customerEmail = orderItems[0].customerEmail;
    
    // Generate items HTML
    const itemsHtml = orderItems.map((item: any) => {
      const validLinks = item.links.filter((link: any) => link.url && link.url.trim() !== '');
      return `
        <tr>
          <td style="padding: 12px; border-bottom: 1px solid #eee;">${item.type.replace('-', ' ').toUpperCase()} Card - ${item.cardNumber}</td>
          <td style="padding: 12px; border-bottom: 1px solid #eee;">${validLinks.length} link${validLinks.length === 1 ? '' : 's'}</td>
          <td style="padding: 12px; border-bottom: 1px solid #eee;">${item.quantity}</td>
          <td style="padding: 12px; border-bottom: 1px solid #eee;">£${item.price.toFixed(2)}</td>
          <td style="padding: 12px; border-bottom: 1px solid #eee;">£${(item.price * item.quantity).toFixed(2)}</td>
        </tr>
      `;
    }).join('');

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Order Receipt - White Cards</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 0 auto; padding: 20px; }
          h1, h2 { color: #000; }
          .receipt { border: 1px solid #ddd; padding: 20px; margin-bottom: 20px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
          th { text-align: left; padding: 12px; border-bottom: 2px solid #ddd; }
          .address { margin-bottom: 20px; }
          .total { font-weight: bold; font-size: 1.2em; margin-top: 20px; }
          .footer { font-size: 0.9em; color: #666; margin-top: 30px; text-align: center; }
          .payment-info { background-color: #f9f9f9; padding: 15px; border: 1px solid #eee; margin-top: 20px; }
          @media print {
            body { font-size: 12px; }
            .no-print { display: none; }
          }
          .print-button { background: #000; color: white; border: none; padding: 10px 20px; cursor: pointer; margin-top: 20px; }
        </style>
      </head>
      <body>
        <div class="receipt">
          <h1>White Cards - Order Receipt</h1>
          <p>Order Date: ${orderDate}</p>
          <p>Order ID: ${orderId}</p>
          
          <div class="address">
            <h2>Delivery Address:</h2>
            <p>
              ${address.fullName}<br>
              ${address.addressLine1}<br>
              ${address.addressLine2 ? address.addressLine2 + '<br>' : ''}
              ${address.city}, ${address.postalCode}<br>
              ${address.country}
            </p>
            <p>Email: ${customerEmail}</p>
          </div>
          
          <h2>Order Items:</h2>
          <table>
            <thead>
              <tr>
                <th>Product</th>
                <th>Links</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              ${itemsHtml}
            </tbody>
          </table>
          
          <p><strong>Note:</strong> All orders include 1-3 working day tracked and signed delivery (£9.99 included in price)</p>
          
          <div class="total">
            <p>Total: £${totalAmount.toFixed(2)}</p>
          </div>
          
          <div class="payment-info">
            <h2>Payment Information</h2>
            <p>Please complete your payment via bank transfer to:</p>
            <p>
              <strong>Account Name:</strong> NFINITYIMMERSIVE LTD<br>
              <strong>Bank:</strong> Revolut<br>
              <strong>Sort Code:</strong> 04-29-09<br>
              <strong>Account Number:</strong> 70589364<br>
              <strong>Reference:</strong> Your Order ID
            </p>
            <p>Once your payment has been received, your order will be processed.</p>
          </div>
        </div>
        
        <button class="print-button no-print" onclick="window.print();">Print Receipt</button>
        
        <div class="footer">
          <p>Thank you for your order!</p>
          <p>White Cards | Email: nfinityimmersive@gmail.com</p>
        </div>
        
        <script>
          document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
              window.print();
            }, 1000);
          });
        </script>
      </body>
      </html>
    `;
  };

  const downloadReceipt = () => {
    if (!receiptHtml) return;

    const element = document.createElement('a');
    const file = new Blob([receiptHtml], {type: 'text/html'});
    element.href = URL.createObjectURL(file);
    element.download = `white-cards-receipt-order.html`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const printReceipt = () => {
    if (!receiptHtml) return;
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(receiptHtml);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => {
        printWindow.print();
      }, 500);
    }
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="container max-w-4xl py-12 px-4">
          <Card className="border-green-200 shadow-md">
            <CardHeader className="text-center border-b pb-6">
              <div className="mx-auto w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4 animate-pulse">
                <Check className="text-green-600 h-6 w-6" />
              </div>
              <CardTitle className="text-2xl text-green-700">Processing Your Order...</CardTitle>
              <CardDescription>Please wait while we confirm your order.</CardDescription>
            </CardHeader>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container max-w-4xl py-12 px-4">
        <Card className="border-green-200 shadow-md">
          <CardHeader className="text-center border-b pb-6">
            <div className="mx-auto w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <Check className="text-green-600 h-6 w-6" />
            </div>
            <CardTitle className="text-2xl text-green-700">Thank You for Your Order!</CardTitle>
            <CardDescription>Your order has been received and is awaiting payment.</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <p className="text-center">
                We've received your order. Please complete payment via bank transfer to process your White Card.
              </p>
              
              <div className="bg-gray-50 border border-gray-200 rounded-md p-4 mt-4">
                <h3 className="font-medium text-lg mb-2 flex items-center">
                  <CreditCard className="mr-2 h-5 w-5" />
                  Bank Transfer Details
                </h3>
                <div className="space-y-1 text-sm">
                  <p><strong>Account Name:</strong> NFINITYIMMERSIVE LTD</p>
                  <p><strong>Bank:</strong> Revolut</p>
                  <p><strong>Sort Code:</strong> 04-29-09</p>
                  <p><strong>Account Number:</strong> 70589364</p>
                  <p><strong>Reference:</strong> Please include your name as reference</p>
                </div>
              </div>
              
              {orderInfo && orderInfo.length > 0 && (
                <div className="border-t border-b py-4 my-4">
                  <h3 className="font-medium mb-2">Order Summary</h3>
                  <div className="space-y-2">
                    {orderInfo.map((item: OrderItem, index: number) => {
                      const validLinks = item.links ? item.links.filter((link: any) => link.url && link.url.trim() !== '') : [];
                      return (
                        <div key={index} className="flex justify-between">
                          <span>
                            {item.type.replace('-', ' ').toUpperCase()} Card (×{item.quantity}) - 
                            {validLinks.length} {validLinks.length === 1 ? 'link' : 'links'}
                          </span>
                          <span>£{(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                      );
                    })}
                    <div className="flex justify-between font-bold pt-2 border-t">
                      <span>Total (including delivery)</span>
                      <span>£{(orderInfo.reduce((total: number, item: OrderItem) => 
                        total + (item.price * item.quantity), 0) + 
                        (orderInfo.some((item: OrderItem) => item.type !== 'update-request') ? 9.99 : 0)).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              )}

              {receiptHtml && (
                <div className="flex flex-col sm:flex-row gap-2 justify-center mt-4">
                  <Button onClick={downloadReceipt} variant="outline" className="flex items-center gap-2">
                    <Download className="h-4 w-4" /> Download Receipt
                  </Button>
                  <Button onClick={printReceipt} variant="outline" className="flex items-center gap-2">
                    <Printer className="h-4 w-4" /> Print Receipt
                  </Button>
                </div>
              )}

              <div className="bg-blue-50 p-4 rounded-md text-blue-800 text-sm">
                <p className="font-medium">What happens next?</p>
                <p className="mt-1">
                  Once we receive your payment, your White Card will be processed and shipped within 1-3 working days via tracked and signed delivery.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 pt-4 justify-center">
                <Button asChild className="flex-1 max-w-xs">
                  <Link to="/">
                    Return to Home
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default PaymentSuccess;
