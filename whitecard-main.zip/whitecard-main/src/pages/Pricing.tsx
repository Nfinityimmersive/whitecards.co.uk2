import Layout from '@/components/Layout';
import AnimatedSection from '@/components/AnimatedSection';
import PricingCard from '@/components/PricingCard';
import { CreditCard } from 'lucide-react';

const Pricing = () => {
  // Pricing cards with correct buttons to go to order-card page
  const pricingCards = [
    {
      title: "One Link Card",
      price: "£20",
      description: "Perfect for sharing one permanent link",
      features: [
        "One permanent link",
        "Premium white NFC card",
        "No monthly fees",
        "Works with any smartphone"
      ],
      buttonText: "Get Your Card",
      buttonLink: "/order-card?type=one-link"
    },
    {
      title: "Multi Link Card",
      price: "£30",
      description: "Share multiple links and social profiles",
      features: [
        "Multiple social links",
        "Custom platform options",
        "Premium white NFC card",
        "No monthly fees"
      ],
      highlighted: true,
      buttonText: "Get Your Card",
      buttonLink: "/order-card?type=multi-link"
    }
  ];

  return (
    <Layout>
      <section className="py-12 md:py-20 animate-on-scroll">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
          <AnimatedSection className="text-center max-w-3xl mx-auto mb-10 md:mb-16">
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight mb-4">
              Pricing
            </h1>
            <p className="text-base md:text-lg text-gray-600">
              Simple, transparent pricing with no hidden fees
            </p>
          </AnimatedSection>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 max-w-4xl mx-auto">
            {pricingCards.map((card, index) => (
              <PricingCard 
                key={index}
                title={card.title}
                price={card.price}
                description={card.description}
                features={card.features}
                highlighted={card.highlighted}
                buttonText={card.buttonText}
                buttonLink={card.buttonLink}
              />
            ))}
          </div>
          
          <div className="mt-10 text-center space-y-4">
            <p className="text-sm md:text-base text-gray-600 max-w-2xl mx-auto">
              All cards include £9.99 Track & Signed delivery (1-3 working days). 
              International shipping available for an additional fee. 
              Expedited delivery options available at checkout.
            </p>
            
            <div className="flex items-center justify-center text-sm text-gray-600 max-w-xl mx-auto bg-gray-50 p-4 rounded-md border border-gray-200">
              <CreditCard className="h-5 w-5 mr-2 flex-shrink-0" />
              <p>Payment is accepted via bank transfer to our Revolut Business account. Details provided at checkout.</p>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Pricing;
