import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { MapPin, Search, Phone, Mail, ExternalLink, Facebook, Instagram, Twitter, Linkedin, DollarSign, Share2 } from 'lucide-react';
import { useState } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";

type Reseller = {
  id: string;
  name: string;
  location: string;
  address: string;
  phone: string;
  email: string;
  distance: string;
};

type Affiliate = {
  id: string;
  name: string;
  profession: string;
  location: string;
  avatar: string;
  bio: string;
  social: {
    facebook?: string;
    instagram?: string;
    twitter?: string;
    linkedin?: string;
  };
  paymentLink: string;
};

const DashboardResellers = () => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [selectedAffiliate, setSelectedAffiliate] = useState<Affiliate | null>(null);
  
  const [resellers, setResellers] = useState<Reseller[]>([
    {
      id: '1',
      name: 'London Digital Store',
      location: 'London',
      address: '123 Oxford Street, London, W1D 1DF',
      phone: '+44 20 1234 5678',
      email: 'contact@londondigital.com',
      distance: '0.8 miles',
    },
    {
      id: '2',
      name: 'Manchester Tech Hub',
      location: 'Manchester',
      address: '45 Deansgate, Manchester, M3 2AY',
      phone: '+44 161 987 6543',
      email: 'sales@manchestertechhub.com',
      distance: '1.2 miles',
    },
    {
      id: '3',
      name: 'Birmingham Gadget Shop',
      location: 'Birmingham',
      address: '78 New Street, Birmingham, B2 4QA',
      phone: '+44 121 456 7890',
      email: 'info@bhamgadgets.co.uk',
      distance: '0.5 miles',
    },
    {
      id: '4',
      name: 'Edinburgh Tech Centre',
      location: 'Edinburgh',
      address: '15 Princes Street, Edinburgh, EH2 2AN',
      phone: '+44 131 876 5432',
      email: 'hello@edinburghtech.com',
      distance: '1.5 miles',
    },
    {
      id: '5',
      name: 'Cardiff Digital Store',
      location: 'Cardiff',
      address: '33 Queen Street, Cardiff, CF10 2HQ',
      phone: '+44 29 2045 6789',
      email: 'info@cardiffdigital.co.uk',
      distance: '0.7 miles',
    },
  ]);

  const [affiliates, setAffiliates] = useState<Affiliate[]>([
    {
      id: '1',
      name: 'Sarah Johnson',
      profession: 'Digital Marketing Specialist',
      location: 'London, UK',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&h=300&auto=format&fit=crop',
      bio: 'Helping businesses grow their online presence for over 8 years. Specializing in social media strategy and content marketing.',
      social: {
        instagram: 'https://instagram.com/sarahjohnson',
        twitter: 'https://twitter.com/sarahjohnson',
        linkedin: 'https://linkedin.com/in/sarahjohnson',
      },
      paymentLink: 'https://payment.example.com/sarahjohnson',
    },
    {
      id: '2',
      name: 'James Wilson',
      profession: 'Tech Entrepreneur',
      location: 'Manchester, UK',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=300&h=300&auto=format&fit=crop',
      bio: 'Founder of three successful tech startups. Passionate about connecting people through innovative technology solutions.',
      social: {
        facebook: 'https://facebook.com/jameswilson',
        linkedin: 'https://linkedin.com/in/jameswilson',
        twitter: 'https://twitter.com/jameswilson',
      },
      paymentLink: 'https://payment.example.com/jameswilson',
    },
    {
      id: '3',
      name: 'Emily Chen',
      profession: 'UX/UI Designer',
      location: 'Edinburgh, UK',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=300&h=300&auto=format&fit=crop',
      bio: 'Award-winning designer with a focus on creating intuitive, beautiful user experiences for both web and mobile applications.',
      social: {
        instagram: 'https://instagram.com/emilychen',
        linkedin: 'https://linkedin.com/in/emilychen',
      },
      paymentLink: 'https://payment.example.com/emilychen',
    },
    {
      id: '4',
      name: 'David Okafor',
      profession: 'E-commerce Consultant',
      location: 'Birmingham, UK',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&h=300&auto=format&fit=crop',
      bio: 'Helping retail businesses transition to successful online stores. Specialized in conversion optimization and customer retention.',
      social: {
        linkedin: 'https://linkedin.com/in/davidokafor',
        twitter: 'https://twitter.com/davidokafor',
        facebook: 'https://facebook.com/davidokafor',
      },
      paymentLink: 'https://payment.example.com/davidokafor',
    },
  ]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Searching for resellers",
      description: `Finding resellers near: ${searchQuery}`,
    });
  };

  const handleApplyAsReseller = () => {
    toast({
      title: "Coming soon",
      description: "Reseller applications will be available soon",
    });
  };

  const handleContactAffiliate = (affiliateName: string) => {
    toast({
      title: "Contact initiated",
      description: `Your request to connect with ${affiliateName} has been sent`,
    });
  };

  const handleShareAffiliate = (affiliate: Affiliate) => {
    setSelectedAffiliate(affiliate);
    setShowShareDialog(true);
  };

  const copyProfileLink = () => {
    if (selectedAffiliate) {
      const profileUrl = `${window.location.origin}/affiliate/${selectedAffiliate.id}`;
      navigator.clipboard.writeText(profileUrl);
      toast({
        title: "Link copied",
        description: "Affiliate profile link copied to clipboard",
      });
      setShowShareDialog(false);
    }
  };

  const shareOnSocial = (platform: string) => {
    if (selectedAffiliate) {
      const profileUrl = `${window.location.origin}/affiliate/${selectedAffiliate.id}`;
      let shareUrl = '';
      
      switch (platform) {
        case 'facebook':
          shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(profileUrl)}`;
          break;
        case 'twitter':
          shareUrl = `https://twitter.com/intent/tweet?url=${encodeURIComponent(profileUrl)}&text=${encodeURIComponent(`Check out ${selectedAffiliate.name}'s profile`)}`;
          break;
        case 'linkedin':
          shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(profileUrl)}`;
          break;
      }
      
      if (shareUrl) {
        window.open(shareUrl, '_blank');
        setShowShareDialog(false);
      }
    }
  };

  return (
    <DashboardLayout>
      <div className="px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Resellers & Affiliates</h1>
          <p className="mt-1 text-sm text-gray-500">Find White Cards resellers near you, connect with our affiliates, or apply to become a reseller yourself.</p>
        </div>

        <Tabs defaultValue="resellers" className="mb-8">
          <TabsList className="mb-6">
            <TabsTrigger value="resellers">Retail Resellers</TabsTrigger>
            <TabsTrigger value="affiliates">Affiliate Partners</TabsTrigger>
          </TabsList>
          
          <TabsContent value="resellers">
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Find a Reseller</CardTitle>
                    <CardDescription>Enter your location to find resellers near you</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSearch} className="flex space-x-2 mb-6">
                      <div className="relative flex-1">
                        <MapPin className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                        <Input 
                          placeholder="Enter city or postcode" 
                          className="pl-10" 
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                        />
                      </div>
                      <Button type="submit">
                        <Search className="mr-2 h-4 w-4" /> Search
                      </Button>
                    </form>

                    <div className="space-y-4">
                      {resellers.map((reseller) => (
                        <div key={reseller.id} className="border rounded-lg p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">{reseller.name}</h3>
                              <p className="text-sm text-muted-foreground">{reseller.location} · {reseller.distance}</p>
                            </div>
                            <div className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full">
                              Official Reseller
                            </div>
                          </div>
                          <p className="text-sm mt-2">{reseller.address}</p>
                          <div className="flex flex-wrap gap-3 mt-3">
                            <div className="flex items-center text-sm">
                              <Phone className="h-3.5 w-3.5 mr-1" />
                              {reseller.phone}
                            </div>
                            <div className="flex items-center text-sm">
                              <Mail className="h-3.5 w-3.5 mr-1" />
                              {reseller.email}
                            </div>
                          </div>
                          <div className="mt-4">
                            <Button variant="outline" size="sm" className="text-xs" onClick={() => window.open(`https://maps.google.com/?q=${reseller.address}`, '_blank')}>
                              <ExternalLink className="h-3 w-3 mr-1" /> View on map
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>Become a Reseller</CardTitle>
                    <CardDescription>Join our reseller program and earn by selling White Cards</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm">
                      As a White Cards reseller, you'll get access to:
                    </p>
                    <ul className="text-sm space-y-2">
                      <li className="flex items-start">
                        <div className="rounded-full bg-green-500 p-0.5 mr-2 mt-1">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                        Wholesale pricing
                      </li>
                      <li className="flex items-start">
                        <div className="rounded-full bg-green-500 p-0.5 mr-2 mt-1">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                        Marketing materials
                      </li>
                      <li className="flex items-start">
                        <div className="rounded-full bg-green-500 p-0.5 mr-2 mt-1">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                        Dedicated support
                      </li>
                      <li className="flex items-start">
                        <div className="rounded-full bg-green-500 p-0.5 mr-2 mt-1">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                        Free listing on our website
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" onClick={handleApplyAsReseller}>
                      Apply as Reseller
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="affiliates">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {affiliates.map((affiliate) => (
                <Card key={affiliate.id}>
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-4">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={affiliate.avatar} alt={affiliate.name} />
                          <AvatarFallback>{affiliate.name.substring(0, 2)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle className="text-lg">{affiliate.name}</CardTitle>
                          <CardDescription className="pt-1">{affiliate.profession}</CardDescription>
                          <p className="text-xs text-muted-foreground mt-1">{affiliate.location}</p>
                        </div>
                      </div>
                      <div className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full">
                        Affiliate Partner
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm mb-4">{affiliate.bio}</p>
                    
                    <div className="flex space-x-2 mb-4">
                      {affiliate.social.facebook && (
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => window.open(affiliate.social.facebook, '_blank')}>
                          <Facebook className="h-4 w-4" />
                        </Button>
                      )}
                      {affiliate.social.instagram && (
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => window.open(affiliate.social.instagram, '_blank')}>
                          <Instagram className="h-4 w-4" />
                        </Button>
                      )}
                      {affiliate.social.twitter && (
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => window.open(affiliate.social.twitter, '_blank')}>
                          <Twitter className="h-4 w-4" />
                        </Button>
                      )}
                      {affiliate.social.linkedin && (
                        <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => window.open(affiliate.social.linkedin, '_blank')}>
                          <Linkedin className="h-4 w-4" />
                        </Button>
                      )}
                      <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => window.open(affiliate.paymentLink, '_blank')}>
                        <DollarSign className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => handleShareAffiliate(affiliate)}>
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      className="w-full" 
                      variant="outline"
                      onClick={() => handleContactAffiliate(affiliate.name)}
                    >
                      Contact for White Cards
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share Affiliate Profile</DialogTitle>
            <DialogDescription>
              Share {selectedAffiliate?.name}'s profile via these options
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-3 gap-4">
              <Button variant="outline" onClick={() => shareOnSocial('facebook')}>
                <Facebook className="mr-2 h-4 w-4" />
                Facebook
              </Button>
              <Button variant="outline" onClick={() => shareOnSocial('twitter')}>
                <Twitter className="mr-2 h-4 w-4" />
                Twitter
              </Button>
              <Button variant="outline" onClick={() => shareOnSocial('linkedin')}>
                <Linkedin className="mr-2 h-4 w-4" />
                LinkedIn
              </Button>
            </div>
            <Button onClick={copyProfileLink}>
              Copy Profile Link
            </Button>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowShareDialog(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
};

export default DashboardResellers;
