
import Layout from '@/components/Layout';

const Privacy = () => {
  return (
    <Layout>
      <section className="py-24">
        <div className="container px-4 md:px-6 mx-auto max-w-4xl">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Privacy Policy</h1>
            <p className="text-gray-500">
              Last updated: April 6, 2025
            </p>
          </div>
          
          <div className="prose max-w-none">
            <h2>1. Introduction</h2>
            <p>
              This Privacy Policy explains how White Cards ("we", "us", "our") collects, uses, shares, and protects information obtained from users of our website and services.
            </p>
            
            <h2>2. Information We Collect</h2>
            <p>
              We collect information you provide directly to us, such as when you create an account, order a product, or contact customer support. This may include:
            </p>
            <ul>
              <li>Contact information (name, email address, mailing address, phone number)</li>
              <li>Account credentials (username, password)</li>
              <li>Payment information (processed by our secure payment processors)</li>
              <li>Profile information (social media links, websites, biographical information)</li>
              <li>Communications you send to us</li>
            </ul>
            
            <h2>3. How We Use Information</h2>
            <p>
              We use the information we collect to:
            </p>
            <ul>
              <li>Provide, maintain, and improve our services</li>
              <li>Process transactions and send related information</li>
              <li>Respond to your comments, questions, and requests</li>
              <li>Communicate with you about products, services, offers, and events</li>
              <li>Monitor and analyze trends, usage, and activities</li>
              <li>Detect, investigate, and prevent fraudulent transactions and other illegal activities</li>
            </ul>
            
            <h2>4. Information Sharing</h2>
            <p>
              We do not sell, trade, or otherwise transfer your personal information to outside parties except in the following circumstances:
            </p>
            <ul>
              <li>With vendors, consultants, and other service providers who need access to such information to carry out work on our behalf</li>
              <li>In response to a legal request if we believe disclosure is in accordance with applicable law</li>
              <li>If we believe your actions are inconsistent with our user agreements or policies</li>
              <li>In connection with a sale, merger, or acquisition of all or a portion of our company</li>
            </ul>
            
            <h2>5. Data Security</h2>
            <p>
              We implement a variety of security measures to maintain the safety of your personal information. However, no method of transmission over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
            </p>
            
            <h2>6. Your Choices</h2>
            <p>
              You may update or correct your account information at any time by logging into your account. You may also opt out of marketing communications by following the instructions in those messages.
            </p>
            
            <h2>7. Children's Privacy</h2>
            <p>
              Our services are not directed to children under 16, and we do not knowingly collect personal information from children under 16.
            </p>
            
            <h2>8. Changes to this Policy</h2>
            <p>
              We may change this Privacy Policy from time to time. If we make changes, we will notify you by revising the date at the top of the policy and, in some cases, provide additional notice.
            </p>
            
            <h2>9. Contact Us</h2>
            <p>
              If you have any questions about this Privacy Policy, please contact us at nfinityimmersive@gmail.com.
            </p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Privacy;
