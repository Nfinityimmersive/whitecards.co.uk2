
import Layout from '@/components/Layout';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const Faq = () => {
  return (
    <Layout>
      <section className="py-24">
        <div className="container px-4 md:px-6 mx-auto">
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Frequently Asked Questions</h1>
            <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed">
              Get answers to the most common questions about White Cards
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="w-full mb-8">
              <AccordionItem value="item-1">
                <AccordionTrigger>How does a White Card work?</AccordionTrigger>
                <AccordionContent>
                  White Cards contain embedded smart technology that communicates with smartphones and other enabled devices when tapped. Simply tap your card on someone&apos;s phone, and your digital profile will appear on their screen.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-2">
                <AccordionTrigger>Do I need a special app to use my card?</AccordionTrigger>
                <AccordionContent>
                  No, White Cards work with any smartphone without requiring an app. The recipient simply needs to tap your card to their device, and your profile will open in their web browser.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-3">
                <AccordionTrigger>Can I update my links after I&apos;ve received my card?</AccordionTrigger>
                <AccordionContent>
                  Yes, but with conditions. Only custom multi-link cards can be updated remotely for £1 per link change. If you own a single-link card, the link is permanent. To change a single-link card, you must post it to us via track and signed delivery (fee paid by you), then pay £1 for the link change, and we will return it via track and signed delivery (fee paid by you).
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-4">
                <AccordionTrigger>How long does shipping take?</AccordionTrigger>
                <AccordionContent>
                  We offer mandatory signed next working day delivery within the UK for £9.00. International shipping times vary by country, typically taking 7-14 business days.
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="item-5">
                <AccordionTrigger>Can I customise my card design?</AccordionTrigger>
                <AccordionContent>
                  Yes, we offer several design options and customisation features. You can add your logo, choose colour schemes, and select from different card layouts during the ordering process.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
            
            <div className="text-center">
              <p className="mb-4 text-gray-500">Still have questions?</p>
              <Link to="/contact">
                <Button>Contact Us</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Faq;
