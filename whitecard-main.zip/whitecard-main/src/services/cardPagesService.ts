
import { supabase } from '@/integrations/supabase/client';
import { CardPage, Link } from '@/types/cardPages';

export const fetchCardPagesService = async (): Promise<CardPage[]> => {
  try {
    console.log("Fetching all card pages");
    // First fetch all card pages
    const { data: pagesData, error: pagesError } = await supabase
      .from('card_pages')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (pagesError) {
      console.error("Error fetching card pages:", pagesError);
      throw pagesError;
    }
    
    console.log("Fetched card pages:", pagesData);
    
    // Then fetch all links
    const { data: linksData, error: linksError } = await supabase
      .from('page_links')
      .select('*')
      .order('sort_order', { ascending: true });
      
    if (linksError) {
      console.error("Error fetching links:", linksError);
      throw linksError;
    }
    
    console.log("Fetched links:", linksData);
    
    // Combine the data
    const combinedData = pagesData.map(page => ({
      ...page,
      links: linksData.filter(link => link.card_page_id === page.id) || []
    }));
    
    console.log("Combined data:", combinedData);
    return combinedData;
  } catch (err) {
    console.error('Error fetching card pages:', err);
    throw err;
  }
};

export const fetchCardPageService = async (slug: string): Promise<CardPage | null> => {
  try {
    console.log("Fetching card page with slug:", slug);
    // Fetch the card page by slug
    const { data: pageData, error: pageError } = await supabase
      .from('card_pages')
      .select('*')
      .eq('slug', slug)
      .maybeSingle();
    
    if (pageError) {
      console.error("Error fetching card page:", pageError);
      throw pageError;
    }
    
    if (!pageData) {
      console.log("No card page found with slug:", slug);
      return null;
    }
    
    console.log("Fetched card page:", pageData);
    
    // Fetch all links for this page
    const { data: linksData, error: linksError } = await supabase
      .from('page_links')
      .select('*')
      .eq('card_page_id', pageData.id)
      .order('sort_order', { ascending: true });
      
    if (linksError) {
      console.error("Error fetching links:", linksError);
      throw linksError;
    }
    
    console.log("Fetched links for page:", linksData);
    
    // Combine the data
    const combinedData = {
      ...pageData,
      links: linksData || []
    };
    
    return combinedData as CardPage;
  } catch (err) {
    console.error('Error fetching card page:', err);
    throw err;
  }
};

export const updateCardPageService = async (id: string, updates: Partial<CardPage>): Promise<void> => {
  try {
    // Extract links from updates if present
    const { links, ...pageUpdates } = updates;
    
    console.log("Updating card page with id:", id, "updates:", pageUpdates);
    
    // Update the card page
    const { data, error: updateError } = await supabase
      .from('card_pages')
      .update({
        ...pageUpdates,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select();
    
    if (updateError) {
      console.error("Error updating card page:", updateError);
      throw updateError;
    }
    
    console.log("Card page updated successfully:", data);
    
    // Update the links if provided
    if (links && links.length > 0) {
      console.log("Updating page links:", links);
      
      // First delete all existing links
      const { error: deleteError } = await supabase
        .from('page_links')
        .delete()
        .eq('card_page_id', id);
      
      if (deleteError) {
        console.error("Error deleting existing links:", deleteError);
        throw deleteError;
      }
      
      // Then insert the new links
      const linksWithPageId = links.map(link => ({
        ...link,
        card_page_id: id
      }));
      
      const { data: newLinks, error: insertError } = await supabase
        .from('page_links')
        .insert(linksWithPageId)
        .select();
      
      if (insertError) {
        console.error("Error inserting new links:", insertError);
        throw insertError;
      }
      
      console.log("New links inserted:", newLinks);
    }
  } catch (err) {
    console.error('Error updating card page:', err);
    throw err;
  }
};

export const createCardPageService = async (cardPage: Partial<Omit<CardPage, 'id' | 'created_at' | 'updated_at' | 'links'>>): Promise<CardPage> => {
  try {
    // Extract links from cardPage if present
    const { links, ...pageData } = cardPage as any;
    
    console.log("Creating new card page:", pageData);
    
    // Ensure required fields
    const dataToInsert = {
      ...pageData,
      // Make sure slug is defined
      slug: pageData.slug || `card-${Date.now()}`,
      // Make sure card_number is empty string so the trigger generates it
      card_number: '',
      is_sold: false
    };
    
    // Insert the new card page
    const { data: newPage, error: insertError } = await supabase
      .from('card_pages')
      .insert(dataToInsert)
      .select()
      .single();
    
    if (insertError) {
      console.error("Error creating card page:", insertError);
      throw insertError;
    }
    
    console.log("New card page created:", newPage);
    
    // Insert the links if provided
    let createdLinks: Link[] = [];
    if (links && links.length > 0) {
      console.log("Adding links to new page:", links);
      
      const linksWithPageId = links.map((link: any) => ({
        ...link,
        card_page_id: newPage.id
      }));
      
      const { data: newLinks, error: linksError } = await supabase
        .from('page_links')
        .insert(linksWithPageId)
        .select();
      
      if (linksError) {
        console.error("Error adding links:", linksError);
        throw linksError;
      }
      
      console.log("New links created:", newLinks);
      createdLinks = newLinks || [];
    }
    
    // Return the newly created card page with links
    return {
      ...newPage,
      links: createdLinks
    } as CardPage;
  } catch (err) {
    console.error('Error creating card page:', err);
    throw err;
  }
};

export const deleteCardPageService = async (id: string): Promise<void> => {
  try {
    console.log("Deleting card page with id:", id);
    
    // Delete the card page (links will be deleted via cascade)
    const { error } = await supabase
      .from('card_pages')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error("Error deleting card page:", error);
      throw error;
    }
  } catch (err) {
    console.error('Error deleting card page:', err);
    throw err;
  }
};

export const addLinkService = async (cardPageId: string, link: Omit<Link, 'id'>): Promise<Link> => {
  try {
    // Insert the new link
    const { data, error } = await supabase
      .from('page_links')
      .insert({
        ...link,
        card_page_id: cardPageId
      })
      .select();
    
    if (error) throw error;
    
    return data[0] as Link;
  } catch (err) {
    console.error('Error adding link:', err);
    throw err;
  }
};

export const updateLinkService = async (linkId: string, updates: Partial<Link>): Promise<Link> => {
  try {
    // Update the link
    const { data, error } = await supabase
      .from('page_links')
      .update(updates)
      .eq('id', linkId)
      .select();
    
    if (error) throw error;
    
    return data[0] as Link;
  } catch (err) {
    console.error('Error updating link:', err);
    throw err;
  }
};

export const deleteLinkService = async (linkId: string): Promise<void> => {
  try {
    // Delete the link
    const { error } = await supabase
      .from('page_links')
      .delete()
      .eq('id', linkId);
    
    if (error) throw error;
  } catch (err) {
    console.error('Error deleting link:', err);
    throw err;
  }
};
