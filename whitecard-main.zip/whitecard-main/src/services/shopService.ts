
import { supabase } from '@/integrations/supabase/client';
import type { Shop } from '@/types/shop';

// Extend the Supabase client with our functions
// This tells TypeScript that these RPC functions exist on the client
declare module '@supabase/supabase-js' {
  interface SupabaseClient {
    rpc(
      fn: 'get_all_shops' | 'create_shop' | 'update_shop' | 'delete_shop' | 'allocate_card_to_shop' | 'update_card_sold_status',
      params?: Record<string, unknown>
    ): Promise<{
      data: any;
      error: Error | null;
    }>;
  }
}

export const fetchShopsService = async () => {
  try {
    const { data, error } = await supabase
      .rpc('get_all_shops') as {
        data: Shop[] | null;
        error: Error | null;
      };
      
    if (error) throw error;
    return data as Shop[];
  } catch (error) {
    console.error('Error fetching shops:', error);
    throw error;
  }
};

export const createShopService = async (shop: Partial<Omit<Shop, 'id' | 'created_at' | 'updated_at'>>) => {
  try {
    const { data, error } = await supabase
      .rpc('create_shop', {
        p_name: shop.name || null,
        p_location: shop.location || null,
        p_contact_email: shop.contact_email || null,
        p_contact_phone: shop.contact_phone || null
      }) as {
        data: Shop | null;
        error: Error | null;
      };
      
    if (error) throw error;
    return data as Shop;
  } catch (error) {
    console.error('Error creating shop:', error);
    throw error;
  }
};

export const updateShopService = async (id: string, updates: Partial<Shop>) => {
  try {
    const { data, error } = await supabase
      .rpc('update_shop', {
        p_id: id,
        p_name: updates.name !== undefined ? updates.name : null,
        p_location: updates.location !== undefined ? updates.location : null,
        p_contact_email: updates.contact_email !== undefined ? updates.contact_email : null,
        p_contact_phone: updates.contact_phone !== undefined ? updates.contact_phone : null
      }) as {
        data: Shop | null;
        error: Error | null;
      };
      
    if (error) throw error;
    return data as Shop;
  } catch (error) {
    console.error('Error updating shop:', error);
    throw error;
  }
};

export const deleteShopService = async (id: string) => {
  try {
    const { error } = await supabase
      .rpc('delete_shop', {
        p_id: id
      }) as {
        data: null;
        error: Error | null;
      };
      
    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error deleting shop:', error);
    throw error;
  }
};

export const allocateCardToShopService = async (cardId: string, shopId: string | null) => {
  try {
    const { error } = await supabase
      .rpc('allocate_card_to_shop', {
        p_card_id: cardId,
        p_shop_id: shopId
      }) as {
        data: null;
        error: Error | null;
      };
      
    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error allocating card to shop:', error);
    throw error;
  }
};

export const markCardAsSoldService = async (cardId: string, isSold: boolean) => {
  try {
    const { error } = await supabase
      .rpc('update_card_sold_status', {
        p_card_id: cardId,
        p_is_sold: isSold
      }) as {
        data: null;
        error: Error | null;
      };
      
    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Error updating card sold status:', error);
    throw error;
  }
};
