
import { Business, Conversation, ColdCallScript } from '../types/coldCalling';

// In-memory storage for demo purposes
// In a real app, this would use a database
let businesses: Business[] = [];
let conversations: Conversation[] = [];
let scripts: ColdCallScript[] = [];

// Sample cold calling scripts
const initializeDefaultScripts = () => {
  if (scripts.length === 0) {
    scripts = [
      {
        id: '1',
        name: 'Restaurant Script',
        businessType: 'restaurant',
        introduction: "Hello, am I speaking with the owner or manager of [Business Name]? My name is [Agent Name] from White Cards. We help restaurant owners increase their customer engagement and loyalty.",
        valueProposition: "Our White Cards allow your customers to tap and instantly get your menu, special offers, and make reservations without downloading any apps. Many restaurants see an increase in repeat customers by 20% within the first three months.",
        questions: [
          "What methods are you currently using to encourage repeat customers?",
          "How do you currently collect customer contact information for marketing?",
          "Would having a simple digital system that captures customer information be valuable to you?"
        ],
        objectionHandling: [
          {
            objection: "We already have a website and social media.",
            response: "That's great! White Cards actually complement your existing digital presence by connecting all those platforms in one tap. It makes it much easier for customers to find everything about your restaurant instantly."
          },
          {
            objection: "I don't have time to learn a new system.",
            response: "I understand completely. The beauty of White Cards is there's almost nothing to learn. We set everything up for you, and you can make updates in just a few clicks whenever needed."
          },
          {
            objection: "It sounds expensive.",
            response: "I appreciate your concern about costs. Our clients typically find the ROI is within the first month through increased repeat visits. We have various pricing options, including a plan specifically designed for restaurants that costs less than a single advertisement in most local publications."
          }
        ],
        closingStatements: [
          "Based on what you've shared, I think our White Card solution would be perfect for your restaurant. Would you be interested in scheduling a quick 15-minute meeting where I can show you how it works?",
          "Many restaurant owners I speak with find this valuable enough to see a demo. Can I schedule a brief meeting to show you exactly how it would work for your restaurant?"
        ]
      },
      {
        id: '2',
        name: 'Barbershop Script',
        businessType: 'barbershop',
        introduction: "Hello, am I speaking with the owner or manager of [Business Name]? My name is [Agent Name] from White Cards. We specialize in helping barbershops increase their bookings and customer loyalty.",
        valueProposition: "Our White Cards allow your clients to tap and instantly book appointments, view your services, and even get reminders for their next cut. Barbershops using our system typically see a 30% reduction in no-shows and a significant increase in repeat business.",
        questions: [
          "How are your clients currently booking appointments with you?",
          "Do you have any challenges with appointment no-shows?",
          "How do you remind clients when it's time for their next cut?"
        ],
        objectionHandling: [
          {
            objection: "We use a booking app already.",
            response: "That's excellent! White Cards can actually integrate with most booking systems and make it even easier for clients to access it. One tap and they're booking instead of having to search for your app or remember a website."
          },
          {
            objection: "Our clients prefer to call us.",
            response: "Many barbershops tell us the same thing. What they find is that while regular clients continue calling, new clients love the digital option. Plus, it frees up your phone line for more urgent matters."
          },
          {
            objection: "I'm not tech-savvy.",
            response: "That's exactly why our clients love White Cards. There's nothing complicated to install or maintain. We set everything up for you, and any updates you need can be done with our support team's help."
          }
        ],
        closingStatements: [
          "Based on what you've shared, I think our White Card solution could really help streamline your booking process. Would you be open to a quick 15-minute meeting where I can show you exactly how it works?",
          "Many barbershop owners find this valuable enough to see a demo. Can I schedule a brief meeting to show you how it would work specifically for your business?"
        ]
      },
      {
        id: '3',
        name: 'Salon Script',
        businessType: 'salon',
        introduction: "Hello, am I speaking with the owner or manager of [Business Name]? My name is [Agent Name] from White Cards. We help salon owners modernize their client experience and increase bookings.",
        valueProposition: "Our White Cards allow your clients to tap and instantly see your services, book appointments, and view your portfolio of work. Salons using our system have seen booking increases of up to 25% and improved client retention.",
        questions: [
          "How do your clients currently discover your new services or promotions?",
          "What system do you use for appointment booking and reminders?",
          "How do you showcase your stylists' work to potential clients?"
        ],
        objectionHandling: [
          {
            objection: "We use social media to showcase our work.",
            response: "Social media is fantastic for salons! White Cards actually make it easier for clients to find all your social platforms in one place. Plus, you can update your profile with new work samples instantly."
          },
          {
            objection: "We're happy with our current booking system.",
            response: "That's great to hear. White Cards can actually integrate with most booking systems, making it even easier for clients to access it directly. One tap instead of searching for your business online."
          },
          {
            objection: "We've tried digital tools before with limited success.",
            response: "I understand your hesitation. What makes White Cards different is how simple they are for clients to use - just a tap, no app downloads or complicated steps. Our salon clients see much higher adoption rates because of this simplicity."
          }
        ],
        closingStatements: [
          "Based on what you've shared about your salon, I believe our White Card solution could help enhance your client experience. Would you be open to a quick 15-minute meeting where I can show you exactly how it works?",
          "Other salon owners I've spoken with found enough value in this to see a demo. Could I schedule a brief meeting to show you how it would work specifically for your salon?"
        ]
      }
    ];
  }
};

// Initialize some data
const initialize = () => {
  initializeDefaultScripts();
};

// Business methods
export const addBusiness = (business: Omit<Business, 'id'>) => {
  const newBusiness: Business = {
    ...business,
    id: Date.now().toString(),
    status: 'not_contacted'
  };
  businesses.push(newBusiness);
  return newBusiness;
};

export const getBusinesses = () => {
  return [...businesses];
};

export const getBusiness = (id: string) => {
  return businesses.find(b => b.id === id);
};

export const updateBusiness = (id: string, updates: Partial<Business>) => {
  const index = businesses.findIndex(b => b.id === id);
  if (index !== -1) {
    businesses[index] = { ...businesses[index], ...updates };
    return businesses[index];
  }
  return null;
};

export const deleteBusiness = (id: string) => {
  const index = businesses.findIndex(b => b.id === id);
  if (index !== -1) {
    const deleted = businesses[index];
    businesses.splice(index, 1);
    // Also delete associated conversations
    conversations = conversations.filter(c => c.businessId !== id);
    return deleted;
  }
  return null;
};

// Conversation methods
export const addConversation = (conversation: Omit<Conversation, 'id'>) => {
  const newConversation: Conversation = {
    ...conversation,
    id: Date.now().toString(),
    date: new Date()
  };
  conversations.push(newConversation);
  
  // Update business status and last contact date
  const businessIndex = businesses.findIndex(b => b.id === conversation.businessId);
  if (businessIndex !== -1) {
    businesses[businessIndex] = {
      ...businesses[businessIndex],
      lastContactDate: new Date(),
      status: getStatusFromOutcome(conversation.outcome)
    };
  }
  
  return newConversation;
};

export const getConversations = (businessId?: string) => {
  if (businessId) {
    return conversations.filter(c => c.businessId === businessId);
  }
  return [...conversations];
};

export const getConversation = (id: string) => {
  return conversations.find(c => c.id === id);
};

// Script methods
export const getScripts = () => {
  initializeDefaultScripts();
  return [...scripts];
};

export const getScript = (id: string) => {
  initializeDefaultScripts();
  return scripts.find(s => s.id === id);
};

export const getScriptForBusinessType = (type: Business['type']) => {
  initializeDefaultScripts();
  return scripts.find(s => s.businessType === type) || scripts[0];
};

// Helper function
const getStatusFromOutcome = (outcome: Conversation['outcome']): Business['status'] => {
  switch (outcome) {
    case 'interested':
      return 'interested';
    case 'meeting_scheduled':
      return 'meeting_scheduled';
    case 'not_interested':
      return 'not_interested';
    default:
      return 'contacted';
  }
};

// Initialize data
initialize();
