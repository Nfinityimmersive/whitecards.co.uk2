
import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CardPage, CardPagesContextType, Link } from '@/types/cardPages';
import { Shop } from '@/types/shop';
import * as cardPagesService from '@/services/cardPagesService';
import * as shopService from '@/services/shopService';

const CardPagesContext = createContext<CardPagesContextType | undefined>(undefined);

export function CardPagesProvider({ children }: { children: ReactNode }) {
  const [cardPages, setCardPages] = useState<CardPage[]>([]);
  const [shops, setShops] = useState<Shop[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    const storedValue = localStorage.getItem('whiteCards_isAdmin');
    return storedValue ? JSON.parse(storedValue) : false;
  });

  useEffect(() => {
    localStorage.setItem('whiteCards_isAdmin', JSON.stringify(isAdmin));
  }, [isAdmin]);

  const fetchCardPages = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const data = await cardPagesService.fetchCardPagesService();
      setCardPages(data);
    } catch (err) {
      console.error('Error fetching card pages:', err);
      setError('Failed to fetch card pages');
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCardPage = async (slug: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const page = await cardPagesService.fetchCardPageService(slug);
      return page;
    } catch (err) {
      console.error('Error fetching card page:', err);
      setError('Failed to fetch card page');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const updateCardPage = async (id: string, updates: Partial<CardPage>) => {
    setIsLoading(true);
    setError(null);
    
    try {
      await cardPagesService.updateCardPageService(id, updates);
      
      // Update local state without doing a full refetch
      setCardPages(prevPages => {
        return prevPages.map(page => {
          if (page.id === id) {
            const updatedPage = {
              ...page,
              ...updates,
              updated_at: new Date().toISOString()
            };
            // If links were provided, update them too
            if (updates.links) {
              updatedPage.links = updates.links;
            }
            return updatedPage;
          }
          return page;
        });
      });
    } catch (err) {
      console.error('Error updating card page:', err);
      setError('Failed to update card page');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const createCardPage = async (cardPage: Partial<Omit<CardPage, 'id' | 'created_at' | 'updated_at' | 'links'>>) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const newCardPage = await cardPagesService.createCardPageService(cardPage);
      
      // Update the local state with the newly created card page
      setCardPages(prevPages => [newCardPage, ...prevPages]);
      
      return newCardPage;
    } catch (err) {
      console.error('Error creating card page:', err);
      setError('Failed to create card page');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const deleteCardPage = async (id: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      await cardPagesService.deleteCardPageService(id);
      
      // Update local state without doing a full refetch
      setCardPages(prevPages => prevPages.filter(page => page.id !== id));
    } catch (err) {
      console.error('Error deleting card page:', err);
      setError('Failed to delete card page');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const addLink = async (cardPageId: string, link: Omit<Link, 'id'>) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const newLink = await cardPagesService.addLinkService(cardPageId, link);
      
      // Update local state without doing a full refetch
      setCardPages(prevPages => {
        return prevPages.map(page => {
          if (page.id === cardPageId) {
            return {
              ...page,
              links: [...page.links, newLink]
            };
          }
          return page;
        });
      });
    } catch (err) {
      console.error('Error adding link:', err);
      setError('Failed to add link');
    } finally {
      setIsLoading(false);
    }
  };

  const updateLink = async (linkId: string, updates: Partial<Link>) => {
    setIsLoading(true);
    setError(null);
    
    try {
      await cardPagesService.updateLinkService(linkId, updates);
      
      // Update local state without doing a full refetch
      setCardPages(prevPages => {
        return prevPages.map(page => {
          const updatedLinks = page.links.map(link => {
            if (link.id === linkId) {
              return { ...link, ...updates };
            }
            return link;
          });
          
          return {
            ...page,
            links: updatedLinks
          };
        });
      });
    } catch (err) {
      console.error('Error updating link:', err);
      setError('Failed to update link');
    } finally {
      setIsLoading(false);
    }
  };

  const deleteLink = async (linkId: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      await cardPagesService.deleteLinkService(linkId);
      
      // Update local state without doing a full refetch
      setCardPages(prevPages => {
        return prevPages.map(page => {
          return {
            ...page,
            links: page.links.filter(link => link.id !== linkId)
          };
        });
      });
    } catch (err) {
      console.error('Error deleting link:', err);
      setError('Failed to delete link');
    } finally {
      setIsLoading(false);
    }
  };

  // Shop management functions
  const fetchShops = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const data = await shopService.fetchShopsService();
      setShops(data);
    } catch (err) {
      console.error('Error fetching shops:', err);
      setError('Failed to fetch shops');
    } finally {
      setIsLoading(false);
    }
  };
  
  const createShop = async (shop: Partial<Omit<Shop, 'id' | 'created_at' | 'updated_at'>>) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const newShop = await shopService.createShopService(shop);
      
      // Update local state
      setShops(prevShops => [newShop, ...prevShops]);
      
      return newShop;
    } catch (err) {
      console.error('Error creating shop:', err);
      setError('Failed to create shop');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };
  
  const updateShop = async (id: string, updates: Partial<Shop>) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const updatedShop = await shopService.updateShopService(id, updates);
      
      // Update local state
      setShops(prevShops => 
        prevShops.map(shop => 
          shop.id === id ? updatedShop : shop
        )
      );
    } catch (err) {
      console.error('Error updating shop:', err);
      setError('Failed to update shop');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };
  
  const deleteShop = async (id: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      await shopService.deleteShopService(id);
      
      // Update local state
      setShops(prevShops => prevShops.filter(shop => shop.id !== id));
      
      // Also update any cards that were associated with this shop
      setCardPages(prevCards => 
        prevCards.map(card => 
          card.shop_id === id ? { ...card, shop_id: null } : card
        )
      );
    } catch (err) {
      console.error('Error deleting shop:', err);
      setError('Failed to delete shop');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };
  
  const allocateCardToShop = async (cardId: string, shopId: string | null) => {
    setIsLoading(true);
    setError(null);
    
    try {
      await shopService.allocateCardToShopService(cardId, shopId);
      
      // Update local state
      setCardPages(prevCards => 
        prevCards.map(card => 
          card.id === cardId ? { ...card, shop_id: shopId } : card
        )
      );
    } catch (err) {
      console.error('Error allocating card to shop:', err);
      setError('Failed to allocate card to shop');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };
  
  const markCardAsSold = async (cardId: string, isSold: boolean) => {
    setIsLoading(true);
    setError(null);
    
    try {
      await shopService.markCardAsSoldService(cardId, isSold);
      
      // Update local state
      setCardPages(prevCards => 
        prevCards.map(card => 
          card.id === cardId ? { ...card, is_sold: isSold } : card
        )
      );
    } catch (err) {
      console.error('Error updating card sold status:', err);
      setError('Failed to update card sold status');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Initial fetch of card pages - removed auto refresh
  useEffect(() => {
    if (isAdmin) {
      console.log("Admin is logged in, fetching card pages initially");
      fetchCardPages().catch(err => {
        console.error("Error in initial card pages fetch:", err);
      });
      
      // Also fetch shops
      fetchShops().catch(err => {
        console.error("Error in initial shops fetch:", err);
      });
    }
  }, [isAdmin]);

  const value = {
    cardPages,
    shops,
    isLoading,
    error,
    fetchCardPages,
    fetchCardPage,
    updateCardPage,
    createCardPage,
    deleteCardPage,
    addLink,
    updateLink,
    deleteLink,
    fetchShops,
    createShop,
    updateShop,
    deleteShop,
    allocateCardToShop,
    markCardAsSold,
    isAdmin,
    setIsAdmin
  };

  return <CardPagesContext.Provider value={value}>{children}</CardPagesContext.Provider>;
}

export const useCardPages = () => {
  const context = useContext(CardPagesContext);
  if (context === undefined) {
    throw new Error('useCardPages must be used within a CardPagesProvider');
  }
  return context;
};

// Re-export types for convenience - use 'export type' for TypeScript's isolatedModules mode
export type { CardPage, Link };
