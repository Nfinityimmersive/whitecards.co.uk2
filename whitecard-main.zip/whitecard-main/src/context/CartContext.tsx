import React, { createContext, useContext, useState, useEffect } from 'react';

interface ICartItem {
  id: string;
  cardNumber: string;
  type: string;
  quantity: number;
  price: number;
  links: any[];
  name?: string;
  customImageUrl?: string;
  bio?: string;
  cardDesign?: string;
}

interface CartContextType {
  cart: ICartItem[];
  addToCart: (item: ICartItem) => void;
  updateQuantity: (id: string, change: number) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  cartCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [cart, setCart] = useState<ICartItem[]>([]);
  const [cartCount, setCartCount] = useState(0);

  // Load cart from localStorage when component mounts
  useEffect(() => {
    const savedCart = localStorage.getItem('whiteCardsCart');
    if (savedCart) {
      try {
        const parsedCart = JSON.parse(savedCart);
        setCart(parsedCart);
        updateCartCount(parsedCart);
      } catch (error) {
        console.error('Failed to parse cart from localStorage:', error);
      }
    }
  }, []);

  // Update cart count helper function
  const updateCartCount = (currentCart: ICartItem[]) => {
    const count = currentCart.reduce((total, item) => total + item.quantity, 0);
    setCartCount(count);
  };

  // Update localStorage whenever cart changes
  useEffect(() => {
    localStorage.setItem('whiteCardsCart', JSON.stringify(cart));
    updateCartCount(cart);
  }, [cart]);

  // Generate a unique card number (exactly 6 characters with WC prefix)
  const generateCardNumber = (): string => {
    const prefix = 'WC';
    const randomNum = Math.floor(1000 + Math.random() * 9000); // 4-digit number between 1000-9999
    return `${prefix}${randomNum}`;
  };

  const addToCart = (item: ICartItem) => {
    // Validate that item has at least one valid link
    const validLinks = item.links.filter(link => link.url && link.url.trim() !== '');
    if (validLinks.length === 0 && item.type !== 'update-request') {
      throw new Error('Card must have at least one valid link');
    }
    
    setCart(prevCart => {
      const existingItemIndex = prevCart.findIndex(cartItem => cartItem.id === item.id);
      
      if (existingItemIndex >= 0) {
        // If item exists, update quantity
        const updatedCart = [...prevCart];
        updatedCart[existingItemIndex].quantity += item.quantity;
        return updatedCart;
      } else {
        // Otherwise add new item with a generated card number if it doesn't have one
        const newItem = {
          ...item,
          cardNumber: item.cardNumber || generateCardNumber()
        };
        return [...prevCart, newItem];
      }
    });
  };

  const updateQuantity = (id: string, change: number) => {
    setCart(prevCart => 
      prevCart.map(item => 
        item.id === id 
          ? { ...item, quantity: Math.max(1, item.quantity + change) } 
          : item
      )
    );
  };

  const removeFromCart = (id: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== id));
  };

  const clearCart = () => {
    setCart([]);
  };

  return (
    <CartContext.Provider 
      value={{ 
        cart, 
        addToCart, 
        updateQuantity, 
        removeFromCart, 
        clearCart,
        cartCount
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
