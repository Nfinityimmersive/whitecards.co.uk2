
/// <reference types="vite/client" />

// Extend the Database namespace for Supabase RPC functions
declare namespace Database {
  interface FunctionsMap {
    get_all_shops: {
      args: Record<string, never>;
      returns: import('@/types/shop').Shop[];
    };
    create_shop: {
      args: {
        p_name: string | null;
        p_location: string | null;
        p_contact_email: string | null;
        p_contact_phone: string | null;
      };
      returns: import('@/types/shop').Shop;
    };
    update_shop: {
      args: {
        p_id: string;
        p_name: string | null;
        p_location: string | null;
        p_contact_email: string | null;
        p_contact_phone: string | null;
      };
      returns: import('@/types/shop').Shop;
    };
    delete_shop: {
      args: {
        p_id: string;
      };
      returns: null;
    };
    allocate_card_to_shop: {
      args: {
        p_card_id: string;
        p_shop_id: string | null;
      };
      returns: null;
    };
    update_card_sold_status: {
      args: {
        p_card_id: string;
        p_is_sold: boolean;
      };
      returns: null;
    };
  }
}
