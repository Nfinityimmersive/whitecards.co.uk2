
-- Function to get all shops
CREATE OR REPLACE FUNCTION get_all_shops()
RETURNS SETOF shops
LANGUAGE sql
AS $$
  SELECT * FROM shops ORDER BY created_at DESC;
$$;

-- Function to create a shop
CREATE OR REPLACE FUNCTION create_shop(
  p_name TEXT,
  p_location TEXT,
  p_contact_email TEXT,
  p_contact_phone TEXT
)
RETURNS shops
LANGUAGE plpgsql
AS $$
DECLARE
  new_shop shops;
BEGIN
  INSERT INTO shops (name, location, contact_email, contact_phone)
  VALUES (p_name, p_location, p_contact_email, p_contact_phone)
  RETURNING * INTO new_shop;
  
  RETURN new_shop;
END;
$$;

-- Function to update a shop
CREATE OR REPLACE FUNCTION update_shop(
  p_id UUID,
  p_name TEXT,
  p_location TEXT,
  p_contact_email TEXT,
  p_contact_phone TEXT
)
RETURNS shops
LANGUAGE plpgsql
AS $$
DECLARE
  updated_shop shops;
BEGIN
  UPDATE shops
  SET 
    name = COALESCE(p_name, name),
    location = COALESCE(p_location, location),
    contact_email = COALESCE(p_contact_email, contact_email),
    contact_phone = COALESCE(p_contact_phone, contact_phone),
    updated_at = NOW()
  WHERE id = p_id
  RETURNING * INTO updated_shop;
  
  RETURN updated_shop;
END;
$$;

-- Function to delete a shop
CREATE OR REPLACE FUNCTION delete_shop(p_id UUID)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  -- First update any cards associated with this shop
  UPDATE card_pages SET shop_id = NULL WHERE shop_id = p_id;
  
  -- Then delete the shop
  DELETE FROM shops WHERE id = p_id;
END;
$$;

-- Function to allocate a card to a shop
CREATE OR REPLACE FUNCTION allocate_card_to_shop(
  p_card_id UUID,
  p_shop_id UUID
)
RETURNS card_pages
LANGUAGE plpgsql
AS $$
DECLARE
  updated_card card_pages;
BEGIN
  UPDATE card_pages
  SET 
    shop_id = p_shop_id,
    updated_at = NOW()
  WHERE id = p_card_id
  RETURNING * INTO updated_card;
  
  RETURN updated_card;
END;
$$;

-- Function to update a card's sold status
CREATE OR REPLACE FUNCTION update_card_sold_status(
  p_card_id UUID,
  p_is_sold BOOLEAN
)
RETURNS card_pages
LANGUAGE plpgsql
AS $$
DECLARE
  updated_card card_pages;
BEGIN
  UPDATE card_pages
  SET 
    is_sold = p_is_sold,
    updated_at = NOW()
  WHERE id = p_card_id
  RETURNING * INTO updated_card;
  
  RETURN updated_card;
END;
$$;
