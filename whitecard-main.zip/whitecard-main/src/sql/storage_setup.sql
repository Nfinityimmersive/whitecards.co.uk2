
-- Create a bucket for card images if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('card-images', 'card-images', true)
ON CONFLICT (id) DO NOTHING;

-- Create a policy to allow public access to files in the card-images bucket
CREATE POLICY "Allow public access to card-images"
ON storage.objects
FOR SELECT
USING (bucket_id = 'card-images');

-- Create a policy to allow authenticated uploads to card-images
CREATE POLICY "Allow authenticated uploads to card-images"
ON storage.objects
FOR INSERT
WITH CHECK (bucket_id = 'card-images');
