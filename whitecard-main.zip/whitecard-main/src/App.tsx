
import { Route, Routes } from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import { CartProvider } from "@/context/CartContext";
import { CardPagesProvider } from "@/context/CardPagesContext";

import Index from "@/pages/Index";
import About from "@/pages/About";
import Features from "@/pages/Features";
import Contact from "@/pages/Contact";
import ColdCalling from "@/pages/ColdCalling";
import Dashboard from "@/pages/Dashboard";
import DashboardLinks from "@/pages/DashboardLinks";
import DashboardCards from "@/pages/DashboardCards";
import DashboardResellers from "@/pages/DashboardResellers";
import DashboardSettings from "@/pages/DashboardSettings";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import NotFound from "@/pages/NotFound";
import OrderCard from "@/pages/OrderCard";
import Admin from "@/pages/Admin";
import Privacy from "@/pages/Privacy";
import Terms from "@/pages/Terms";
import Faq from "@/pages/Faq";
import PaymentSuccess from "@/pages/PaymentSuccess";
import PaymentCanceled from "@/pages/PaymentCanceled";
import CardPage from "@/pages/CardPage";
import AdminLogin from "@/pages/AdminLogin";
import AdminDashboard from "@/pages/AdminDashboard";
import CreateCardPage from "@/pages/CreateCardPage";
import EditCardPage from "@/pages/EditCardPage";
import UpdateLinks from "@/pages/UpdateLinks";
import Pricing from "@/pages/Pricing";

import "./App.css";

function App() {
  return (
    <CardPagesProvider>
      <CartProvider>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/about" element={<About />} />
          <Route path="/features" element={<Features />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/update-links" element={<UpdateLinks />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/cold-calling" element={<ColdCalling />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/dashboard-links" element={<DashboardLinks />} />
          <Route path="/dashboard-cards" element={<DashboardCards />} />
          <Route path="/dashboard-resellers" element={<DashboardResellers />} />
          <Route path="/dashboard-settings" element={<DashboardSettings />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/order-card" element={<OrderCard />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/admin-login" element={<AdminLogin />} />
          <Route path="/admin-dashboard" element={<AdminDashboard />} />
          <Route path="/admin-dashboard/create" element={<CreateCardPage />} />
          <Route path="/admin-dashboard/edit/:id" element={<EditCardPage />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/faq" element={<Faq />} />
          <Route path="/payment-success" element={<PaymentSuccess />} />
          <Route path="/payment-canceled" element={<PaymentCanceled />} />
          <Route path="/:slug" element={<CardPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Toaster />
      </CartProvider>
    </CardPagesProvider>
  );
}

export default App;
