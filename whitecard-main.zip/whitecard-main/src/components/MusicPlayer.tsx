
import { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useIsMobile } from '@/hooks/use-mobile';

const MusicPlayer = () => {
  const [isMuted, setIsMuted] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const isMobile = useIsMobile();

  useEffect(() => {
    // Initialize YouTube player when component mounts
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    const firstScriptTag = document.getElementsByTagName('script')[0];
    if (firstScriptTag && firstScriptTag.parentNode) {
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
    }

    // Set isLoaded to true when iframe content is loaded
    const handleIframeLoad = () => {
      setIsLoaded(true);
    };

    if (iframeRef.current) {
      iframeRef.current.addEventListener('load', handleIframeLoad);
    }

    return () => {
      if (iframeRef.current) {
        iframeRef.current.removeEventListener('load', handleIframeLoad);
      }
    };
  }, []);

  const toggleMute = () => {
    setIsMuted(!isMuted);
    
    // Send message to the iframe to mute/unmute
    if (iframeRef.current && iframeRef.current.contentWindow) {
      iframeRef.current.contentWindow.postMessage(
        JSON.stringify({
          event: 'command',
          func: isMuted ? 'unMute' : 'mute',
          args: []
        }),
        '*'
      );
    }
  };

  // Additional parameters for mobile to ensure autoplay
  const mobileParams = isMobile ? '&playsinline=1&mute=1' : '';

  return (
    <div className="fixed bottom-6 left-6 z-50 bg-white/80 backdrop-blur-sm rounded-lg shadow-lg p-2 flex items-center">
      <div className="w-60 h-16 overflow-hidden relative">
        <iframe
          ref={iframeRef}
          width="100"
          height="50"
          src={`https://www.youtube.com/embed/UwKTFpQzcsI?autoplay=1&loop=1&playlist=UwKTFpQzcsI&controls=0&disablekb=1&fs=0&modestbranding=1&enablejsapi=1&origin=${encodeURIComponent(window.location.origin)}${mobileParams}`}
          title="Background Music"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          className="absolute opacity-0 pointer-events-none"
        ></iframe>
        <div className="flex items-center gap-3">
          <div className="min-w-10 min-h-10 bg-black/10 rounded-full flex items-center justify-center">
            {isLoaded ? (
              isMuted ? (
                <VolumeX className="h-5 w-5 text-gray-700" />
              ) : (
                <Volume2 className="h-5 w-5 text-gray-700" />
              )
            ) : (
              <div className="h-5 w-5 rounded-full animate-pulse bg-gray-300"></div>
            )}
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-medium">Background Music</span>
            <span className="text-xs text-gray-500">Experience White Cards</span>
          </div>
        </div>
      </div>
      <Button
        variant="ghost"
        size="sm"
        className="ml-2"
        onClick={toggleMute}
      >
        {isMuted ? 'Unmute' : 'Mute'}
      </Button>
    </div>
  );
};

export default MusicPlayer;
