
import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface FeatureCardProps {
  title: string;
  description: string;
  icon: ReactNode;
  className?: string;
}

const FeatureCard = ({ title, description, icon, className }: FeatureCardProps) => {
  return (
    <div 
      className={cn(
        "p-6 rounded-xl border border-gray-200 bg-white hover:shadow-md transition-all duration-300 ease-in-out",
        className
      )}
    >
      <div className="w-12 h-12 flex items-center justify-center rounded-lg bg-gray-100 mb-4">
        {icon}
      </div>
      <h3 className="text-lg font-medium mb-2">{title}</h3>
      <p className="text-gray-500 text-sm">{description}</p>
    </div>
  );
};

export default FeatureCard;
