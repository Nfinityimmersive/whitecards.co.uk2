import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { ShoppingCart, Loader2 } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { CustomerInfoForm, CustomerData } from './CustomerInfoForm';
import { PaymentInfoDialog } from './PaymentInfoDialog';

interface DeliveryAddress {
  fullName: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  postalCode: string;
  country: string;
}

interface CheckoutButtonProps {
  cart: any[];
  customerEmail: string;
  deliveryAddress: DeliveryAddress;
  disabled?: boolean;
  isDemoMode?: boolean;
}

export function CheckoutButton({ cart, disabled, isDemoMode }: CheckoutButtonProps) {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const { clearCart } = useCart();
  const [customerInfoOpen, setCustomerInfoOpen] = useState(false);
  const [paymentInfoOpen, setPaymentInfoOpen] = useState(false);
  const [customerData, setCustomerData] = useState<CustomerData | null>(null);
  const [orderReference, setOrderReference] = useState('');

  // Check for one-link cards in cart
  const oneLinkCardItems = cart.filter(item => item.type === 'one-link');
  const hasOneLinkCard = oneLinkCardItems.length > 0;
  const oneLinkCardQuantity = oneLinkCardItems.reduce((total, item) => total + item.quantity, 0);

  // Generate a unique reference number - WC followed by 6 numbers
  const generateOrderReference = () => {
    const randomNum = Math.floor(100000 + Math.random() * 900000); // 6-digit number between 100000-999999
    return `WC${randomNum}`;
  };

  // Get total amount including delivery fee
  const getTotalAmount = () => {
    const cartTotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    // Add delivery fee if not just update requests
    const deliveryFee = cart.some(item => item.type !== 'update-request') ? 9.99 : 0;
    return cartTotal + deliveryFee;
  };

  const handleCheckout = async () => {
    // Regular checkout flow - validate cart items have valid links
    for (const item of cart) {
      if (item.type !== 'update-request') {
        const validLinks = item.links.filter(link => link.url && link.url.trim() !== '');
        if (validLinks.length === 0) {
          toast({
            title: "Invalid cart item",
            description: `Card has no valid links. Please add at least one link.`,
            variant: "destructive"
          });
          return;
        }
      }
    }
    
    if (cart.length === 0) {
      toast({
        title: "Cart is empty",
        description: "Please add at least one card to your cart before checking out.",
        variant: "destructive"
      });
      return;
    }

    // Open customer info form
    setCustomerInfoOpen(true);
  };

  const handleCustomerInfoSubmit = (data: CustomerData) => {
    setCustomerData(data);
    // Generate the order reference when the customer info is submitted
    const ref = generateOrderReference();
    setOrderReference(ref);
    setPaymentInfoOpen(true);
  };

  const handlePaymentConfirm = () => {
    if (!customerData || !orderReference) return;

    try {
      setIsProcessing(true);

      // Save the cart data to localStorage for reference
      const cartWithTimeStamp = cart.map(item => ({
        ...item,
        dateOrdered: new Date().toLocaleString(),
        customerEmail: customerData.email,
        deliveryAddress: {
          fullName: customerData.fullName,
          addressLine1: customerData.addressLine1,
          addressLine2: customerData.addressLine2,
          city: customerData.city,
          postalCode: customerData.postalCode,
          country: customerData.country,
        }
      }));
      
      const existingOrders = JSON.parse(localStorage.getItem('cardOrders') || '[]');
      localStorage.setItem('cardOrders', JSON.stringify([...existingOrders, ...cartWithTimeStamp]));

      // Generate order details for WhatsApp message
      const totalAmount = getTotalAmount();
      
      // Format cart items for the detailed receipt
      const orderItems = cart.map(item => {
        const validLinks = item.links.filter(link => link.url && link.url.trim() !== '');
        const linkText = validLinks.length > 0 
          ? validLinks.map(link => `- ${link.platform}: ${link.url}`).join('\n') 
          : 'No links';
          
        return `*${item.type.replace('-', ' ')} Card (${item.cardNumber})* - £${item.price}\n` +
               `Quantity: ${item.quantity}\n` +
               `Links:\n${linkText}`;
      }).join('\n\n');
      
      const addressText = `${customerData.fullName}\n${customerData.addressLine1}${customerData.addressLine2 ? '\n'+customerData.addressLine2 : ''}\n${customerData.city}, ${customerData.postalCode}\n${customerData.country}`;
      
      // Create detailed WhatsApp order message with reference number
      const messageBody = 
        `*New White Card Order - Reference: ${orderReference}*\n\n` +
        `*Customer Details*\n` +
        `Name: ${customerData.fullName}\n` +
        `Email: ${customerData.email}\n` +
        `Phone: ${customerData.phone}\n\n` +
        `*Delivery Address*\n` +
        `${addressText}\n\n` +
        `*Order Items*\n\n` +
        `${orderItems}\n\n` +
        `*Summary*\n` +
        `Subtotal: £${cart.reduce((total, item) => total + (item.price * item.quantity), 0).toFixed(2)}\n` +
        `Delivery: £${cart.some(item => item.type !== 'update-request') ? '9.99' : '0.00'}\n` +
        `*Total: £${totalAmount.toFixed(2)}*\n\n` +
        `*Payment Method: Bank Transfer*\n` +
        `Bank: Revolut\n` +
        `Account Name: NFINITYIMMERSIVE LTD\n` +
        `Sort Code: 04-29-09\n` +
        `Account Number: 70589364\n` +
        `Reference: ${orderReference}\n\n` +
        `IMPORTANT: Reference number is MANDATORY to validate your order. Without the correct reference, we cannot process your payment.`;
      
      // Automatically send WhatsApp message
      sendWhatsAppMessage(messageBody);
      
      // Show success toast
      toast({
        title: "Order Confirmed!",
        description: "Your order has been sent via WhatsApp. Please complete the bank transfer.",
      });

      // Redirect to payment success page
      setTimeout(() => {
        // Clear the cart on successful checkout
        clearCart();
        window.location.href = '/payment-success';
        setIsProcessing(false);
      }, 1500);
      
    } catch (error) {
      console.error("Error during checkout:", error);
      toast({
        title: "Checkout error",
        description: error instanceof Error ? error.message : "An error occurred during checkout.",
        variant: "destructive"
      });
      setIsProcessing(false);
    }
  };
  
  // Function to automatically send WhatsApp message
  const sendWhatsAppMessage = (messageBody: string) => {
    try {
      // Use WhatsApp Business API or a service like Twilio to automatically send messages
      // For this implementation, we'll use the direct WhatsApp link approach
      const encodedMessage = encodeURIComponent(messageBody);
      const whatsappUrl = `https://wa.me/447984365665?text=${encodedMessage}`;
      
      // Open WhatsApp in a new tab
      window.open(whatsappUrl, '_blank');
    } catch (error) {
      console.error("Error sending WhatsApp message:", error);
    }
  };

  return (
    <>
      <Button 
        className="w-full py-2 h-auto" 
        onClick={handleCheckout}
        disabled={disabled || isProcessing}
      >
        {isProcessing ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
          </>
        ) : (
          <>
            <ShoppingCart className="mr-2 h-4 w-4" /> Complete Order
          </>
        )}
      </Button>

      <CustomerInfoForm 
        isOpen={customerInfoOpen} 
        onClose={() => setCustomerInfoOpen(false)}
        onSubmit={handleCustomerInfoSubmit}
      />

      <PaymentInfoDialog 
        isOpen={paymentInfoOpen}
        onClose={() => setPaymentInfoOpen(false)}
        onConfirm={handlePaymentConfirm}
        totalAmount={getTotalAmount()}
        orderReference={orderReference}
        hasOneLinkCard={hasOneLinkCard}
        oneLinkCardQuantity={oneLinkCardQuantity}
      />
    </>
  );
}
