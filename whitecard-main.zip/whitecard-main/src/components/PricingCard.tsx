
import { Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';

interface PricingCardProps {
  title: string;
  price: string;
  description: string;
  features: string[];
  highlighted?: boolean;
  className?: string;
  buttonText?: string;
  buttonLink?: string;
  showAddToCartOnly?: boolean;
}

const PricingCard = ({ 
  title, 
  price, 
  description, 
  features, 
  highlighted = false,
  className,
  buttonText = "Get Started",
  buttonLink = "/order-card",
  showAddToCartOnly = false
}: PricingCardProps) => {
  return (
    <div 
      className={cn(
        "relative rounded-xl border p-6 transition-all duration-300 h-full flex flex-col",
        highlighted 
          ? "border-black bg-black text-white shadow-xl scale-105 z-10" 
          : "border-gray-200 bg-white hover:shadow-md",
        className
      )}
    >
      {highlighted && (
        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-white text-black px-3 py-1 rounded-full text-xs font-medium">
          Popular
        </div>
      )}
      
      <div className="mb-5">
        <h3 className="text-lg font-medium mb-2">{title}</h3>
        <div className="flex items-baseline gap-1">
          <span className="text-3xl font-bold">{price}</span>
        </div>
        <p className={cn("text-sm mt-2", highlighted ? "text-gray-300" : "text-gray-500")}>
          {description}
        </p>
      </div>
      
      <ul className="space-y-3 mb-6 flex-grow">
        {features.map((feature, i) => (
          <li key={i} className="flex items-start gap-2 text-sm">
            <span className={cn(
              "flex-shrink-0 mt-1", 
              highlighted ? "text-white" : "text-black"
            )}>
              <Check size={14} />
            </span>
            <span>{feature}</span>
          </li>
        ))}
      </ul>
      
      <Link to={buttonLink} className="w-full mt-auto">
        <Button 
          className={cn(
            "w-full", 
            highlighted 
              ? "bg-white text-black hover:bg-gray-100" 
              : "bg-black text-white hover:bg-black/90"
          )}
        >
          {buttonText}
        </Button>
      </Link>
    </div>
  );
};

export default PricingCard;
