import { cn } from '@/lib/utils';

interface WhiteCardProps {
  className?: string;
}

const WhiteCard = ({ className }: WhiteCardProps) => {
  return (
    <div 
      className={cn(
        "relative w-[240px] h-[380px] rounded-xl shadow-xl overflow-hidden",
        "bg-gradient-to-br from-purple-100 to-purple-200", // Added color gradient
        "border border-purple-200", // Added border color
        "before:absolute before:inset-0 before:bg-gradient-to-t before:from-purple-50/30 before:to-purple-100/10",
        "after:absolute after:inset-0 after:bg-gradient-to-b after:from-purple-100/30 after:to-transparent",
        className
      )}
    >
      
      <div className="absolute top-0 left-0 right-0 h-12 bg-gradient-to-r from-purple-50 to-purple-100 flex items-center px-4">
        <div className="w-24 h-4 bg-purple-200 rounded-full"></div>
      </div>
      
      <div className="absolute top-20 left-0 right-0 flex flex-col items-center">
        <div className="w-16 h-16 bg-purple-100 rounded-full mb-4"></div>
        <div className="w-32 h-3 bg-purple-200 rounded-full mb-2"></div>
        <div className="w-24 h-2 bg-purple-100 rounded-full"></div>
      </div>
      
      <div className="absolute bottom-12 left-6 right-6 flex flex-col gap-3">
        <div className="w-full h-8 bg-purple-100 rounded-md"></div>
        <div className="w-full h-8 bg-purple-100 rounded-md"></div>
        <div className="w-full h-8 bg-purple-100 rounded-md"></div>
      </div>
      
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-purple-200 flex items-center justify-center">
        <div className="w-6 h-6 rounded-full bg-purple-50"></div>
      </div>
    </div>
  );
};

export default WhiteCard;
