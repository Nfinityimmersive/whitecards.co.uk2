
import { ReactNode, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { 
  Home, 
  Link as LinkIcon, 
  CreditCard, 
  Settings, 
  LogOut, 
  Users, 
  Phone,
  Menu,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';

interface DashboardLayoutProps {
  children: ReactNode;
}

const DashboardLayout = ({ children }: DashboardLayoutProps) => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  
  const handleLogout = () => {
    // Simulate logout
    toast({
      title: "Logged out",
      description: "You have been successfully logged out",
    });
    navigate('/login');
  };

  const isActive = (path: string) => {
    return location.pathname === path ? 'bg-primary/10 text-primary font-medium' : '';
  };

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Desktop Sidebar */}
      <div className="hidden md:flex md:w-64 md:flex-col">
        <div className="flex flex-col flex-grow pt-5 overflow-y-auto border-r bg-white">
          <div className="flex items-center flex-shrink-0 px-4">
            <Link to="/" className="text-xl font-display font-semibold tracking-tight">
              White Cards
            </Link>
          </div>
          <div className="mt-8 flex flex-col flex-1">
            <nav className="flex-1 px-2 pb-4 space-y-1">
              <Link 
                to="/dashboard" 
                className={`flex items-center px-4 py-2 text-sm rounded-md ${isActive('/dashboard')}`}
              >
                <Home className="mr-3 h-5 w-5" />
                Dashboard
              </Link>
              <Link 
                to="/dashboard/links" 
                className={`flex items-center px-4 py-2 text-sm rounded-md ${isActive('/dashboard/links')}`}
              >
                <LinkIcon className="mr-3 h-5 w-5" />
                My Links
              </Link>
              <Link 
                to="/dashboard/cards" 
                className={`flex items-center px-4 py-2 text-sm rounded-md ${isActive('/dashboard/cards')}`}
              >
                <CreditCard className="mr-3 h-5 w-5" />
                Cards
              </Link>
              <Link 
                to="/dashboard/resellers" 
                className={`flex items-center px-4 py-2 text-sm rounded-md ${isActive('/dashboard/resellers')}`}
              >
                <Users className="mr-3 h-5 w-5" />
                Resellers
              </Link>
              <Link 
                to="/dashboard/cold-calling" 
                className={`flex items-center px-4 py-2 text-sm rounded-md ${isActive('/dashboard/cold-calling')}`}
              >
                <Phone className="mr-3 h-5 w-5" />
                Cold Calling
              </Link>
              <Link 
                to="/dashboard/settings" 
                className={`flex items-center px-4 py-2 text-sm rounded-md ${isActive('/dashboard/settings')}`}
              >
                <Settings className="mr-3 h-5 w-5" />
                Settings
              </Link>
              <Button 
                variant="ghost" 
                className="w-full justify-start px-4 py-2 text-sm"
                onClick={handleLogout}
              >
                <LogOut className="mr-3 h-5 w-5" />
                Logout
              </Button>
            </nav>
          </div>
        </div>
      </div>

      {/* Mobile header */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-10 bg-white border-b">
        <div className="flex items-center justify-between h-16 px-4">
          <Link to="/" className="text-xl font-display font-semibold tracking-tight">
            White Cards
          </Link>
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Open menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[80%] sm:w-[350px] pt-16">
              <div className="flex flex-col h-full py-6">
                <div className="flex-1 space-y-1">
                  <Link 
                    to="/dashboard" 
                    className={`flex items-center px-4 py-3 text-base rounded-md ${isActive('/dashboard')}`}
                    onClick={() => setIsOpen(false)}
                  >
                    <Home className="mr-3 h-5 w-5" />
                    Dashboard
                  </Link>

                  <Link 
                    to="/dashboard/links" 
                    className={`flex items-center px-4 py-3 text-base rounded-md ${isActive('/dashboard/links')}`}
                    onClick={() => setIsOpen(false)}
                  >
                    <LinkIcon className="mr-3 h-5 w-5" />
                    My Links
                  </Link>

                  <Link 
                    to="/dashboard/cards" 
                    className={`flex items-center px-4 py-3 text-base rounded-md ${isActive('/dashboard/cards')}`}
                    onClick={() => setIsOpen(false)}
                  >
                    <CreditCard className="mr-3 h-5 w-5" />
                    Cards
                  </Link>

                  <Link 
                    to="/dashboard/resellers" 
                    className={`flex items-center px-4 py-3 text-base rounded-md ${isActive('/dashboard/resellers')}`}
                    onClick={() => setIsOpen(false)}
                  >
                    <Users className="mr-3 h-5 w-5" />
                    Resellers
                  </Link>

                  <Collapsible
                    open={menuOpen}
                    onOpenChange={setMenuOpen}
                    className="w-full rounded-md"
                  >
                    <CollapsibleTrigger asChild>
                      <Button
                        variant="ghost"
                        className="flex items-center justify-between w-full px-4 py-3 text-base rounded-md"
                      >
                        <div className="flex items-center">
                          <Phone className="mr-3 h-5 w-5" />
                          <span>Cold Calling</span>
                        </div>
                        {menuOpen ? (
                          <ChevronUp className="h-5 w-5" />
                        ) : (
                          <ChevronDown className="h-5 w-5" />
                        )}
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="pl-12 pr-4 py-2 space-y-2">
                      <Link 
                        to="/dashboard/cold-calling" 
                        className={`block py-2 text-sm hover:text-primary ${isActive('/dashboard/cold-calling')}`}
                        onClick={() => setIsOpen(false)}
                      >
                        Overview
                      </Link>
                      <Link 
                        to="/dashboard/cold-calling?tab=prospects" 
                        className="block py-2 text-sm hover:text-primary"
                        onClick={() => setIsOpen(false)}
                      >
                        Prospects
                      </Link>
                      <Link 
                        to="/dashboard/cold-calling?tab=scripts" 
                        className="block py-2 text-sm hover:text-primary"
                        onClick={() => setIsOpen(false)}
                      >
                        Scripts
                      </Link>
                      <Link 
                        to="/dashboard/cold-calling?tab=history" 
                        className="block py-2 text-sm hover:text-primary"
                        onClick={() => setIsOpen(false)}
                      >
                        Call History
                      </Link>
                    </CollapsibleContent>
                  </Collapsible>

                  <Link 
                    to="/dashboard/settings" 
                    className={`flex items-center px-4 py-3 text-base rounded-md ${isActive('/dashboard/settings')}`}
                    onClick={() => setIsOpen(false)}
                  >
                    <Settings className="mr-3 h-5 w-5" />
                    Settings
                  </Link>
                </div>

                <div className="pt-6 border-t mt-6">
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start px-4 py-3 text-base"
                    onClick={() => {
                      handleLogout();
                      setIsOpen(false);
                    }}
                  >
                    <LogOut className="mr-3 h-5 w-5" />
                    Logout
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-col flex-1">
        <main className="flex-1 pb-8 pt-16 md:pt-0">
          {children}
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
