import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { ShoppingCart, Package, Menu, X } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { useCart } from '@/context/CartContext';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const isMobile = useIsMobile();
  const { cartCount } = useCart();
  const location = useLocation();
  const [sheetOpen, setSheetOpen] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 20;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [scrolled]);

  const handleMobileLinkClick = () => {
    // Close the mobile sheet
    return () => {
      setSheetOpen(false);
    };
  };

  const mobileLinks = [
    { text: "Home", path: "/" },
    { text: "Features", path: "/features" },
    { text: "Pricing", path: "/pricing" },
    { text: "Update Links", path: "/update-links" },
    { text: "Contact", path: "/contact" },
  ];

  return (
    <header 
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 lg:px-10 bg-white',
        scrolled ? 'py-3 border-b border-gray-200' : 'py-6'
      )}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center">
          <img 
            src="/lovable-uploads/672f7114-977d-4396-8401-47ef516a6438.png" 
            alt="White Cards Logo" 
            className="h-10 mr-2" 
          />
          <span className="text-xl font-display font-semibold tracking-tight">White Cards</span>
        </Link>

        {!isMobile ? (
          <>
            <nav className="flex items-center space-x-8">
              <Link to="/" className="font-medium text-sm hover:opacity-70 transition-opacity">
                Home
              </Link>
              <Link to="/features" className="font-medium text-sm hover:opacity-70 transition-opacity">
                Features
              </Link>
              <Link 
                to="/pricing" 
                className="font-medium text-sm hover:opacity-70 transition-opacity"
              >
                Pricing
              </Link>
              <Link to="/update-links" className="font-medium text-sm hover:opacity-70 transition-opacity">
                Update Links
              </Link>
              <Link to="/contact" className="font-medium text-sm hover:opacity-70 transition-opacity">
                Contact
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Link to="/order-card">
                <Button variant="outline" size="sm" className="px-4">
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  {cartCount > 0 ? (
                    <span className="flex items-center">
                      Cart 
                      <span className="ml-1 bg-black text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                        {cartCount}
                      </span>
                    </span>
                  ) : (
                    <span>Order Now</span>
                  )}
                </Button>
              </Link>
            </div>
          </>
        ) : (
          <div className="flex items-center space-x-3">
            {/* Cart button for mobile - remove the count indicator */}
            <Link to="/order-card">
              <Button variant="outline" size="sm" className="px-2 py-1">
                <ShoppingCart className="h-4 w-4" />
              </Button>
            </Link>
            
            {/* Mobile menu sheet */}
            <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="h-9 w-9 p-0">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[80%] sm:w-[385px] p-0">
                <div className="h-full flex flex-col">
                  <div className="px-6 py-6 border-b border-gray-100">
                    <div className="flex items-center justify-between mb-6">
                      <Link to="/" className="flex items-center">
                        <img 
                          src="/lovable-uploads/672f7114-977d-4396-8401-47ef516a6438.png" 
                          alt="White Cards Logo" 
                          className="h-7 mr-2" 
                        />
                        <span className="text-lg font-display font-semibold tracking-tight">White Cards</span>
                      </Link>
                    </div>
                  </div>
                  <div className="flex-1 px-6 py-4">
                    <nav className="flex flex-col space-y-6 text-lg">
                      {mobileLinks.map((link) => (
                        <Link 
                          key={link.path}
                          to={link.path}
                          className="flex items-center py-2 border-b border-gray-100 hover:text-gray-900"
                          onClick={handleMobileLinkClick()}
                        >
                          {link.text}
                        </Link>
                      ))}
                    </nav>
                  </div>
                  <div className="mt-auto border-t border-gray-100 p-6">
                    <Link to="/order-card" onClick={() => setSheetOpen(false)}>
                      <Button className="w-full bg-black text-white">
                        Order Your Card
                      </Button>
                    </Link>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navbar;
