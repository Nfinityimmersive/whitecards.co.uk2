
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";

interface CustomerInfoFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: CustomerData) => void;
}

export interface CustomerData {
  fullName: string;
  email: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  postalCode: string;
  country: string;
}

export function CustomerInfoForm({ isOpen, onClose, onSubmit }: CustomerInfoFormProps) {
  const { register, handleSubmit, formState: { errors, isValid } } = useForm<CustomerData>({
    defaultValues: {
      fullName: '',
      email: '',
      phone: '',
      addressLine1: '',
      addressLine2: '',
      city: '',
      postalCode: '',
      country: 'United Kingdom',
    }
  });

  const onFormSubmit = (data: CustomerData) => {
    onSubmit(data);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md md:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-center">Delivery Information</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="fullName">Full Name</Label>
            <Input 
              id="fullName" 
              placeholder="John Doe"
              {...register("fullName", { required: "Full name is required" })} 
            />
            {errors.fullName && <p className="text-sm text-red-500">{errors.fullName.message}</p>}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input 
                id="email" 
                type="email"
                placeholder="you@example.com" 
                {...register("email", { 
                  required: "Email is required",
                  pattern: {
                    value: /\S+@\S+\.\S+/,
                    message: "Invalid email address"
                  }
                })} 
              />
              {errors.email && <p className="text-sm text-red-500">{errors.email.message}</p>}
            </div>
            
            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input 
                id="phone" 
                placeholder="+44 7123 456789" 
                {...register("phone", { required: "Phone number is required" })} 
              />
              {errors.phone && <p className="text-sm text-red-500">{errors.phone.message}</p>}
            </div>
          </div>
          
          <div>
            <Label htmlFor="addressLine1">Address Line 1</Label>
            <Input 
              id="addressLine1" 
              placeholder="123 Main St" 
              {...register("addressLine1", { required: "Address is required" })} 
            />
            {errors.addressLine1 && <p className="text-sm text-red-500">{errors.addressLine1.message}</p>}
          </div>
          
          <div>
            <Label htmlFor="addressLine2">Address Line 2 (Optional)</Label>
            <Input 
              id="addressLine2" 
              placeholder="Apartment, suite, etc." 
              {...register("addressLine2")} 
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="city">City</Label>
              <Input 
                id="city" 
                placeholder="London" 
                {...register("city", { required: "City is required" })} 
              />
              {errors.city && <p className="text-sm text-red-500">{errors.city.message}</p>}
            </div>
            
            <div>
              <Label htmlFor="postalCode">Postal Code</Label>
              <Input 
                id="postalCode" 
                placeholder="SW1A 1AA" 
                {...register("postalCode", { required: "Postal code is required" })} 
              />
              {errors.postalCode && <p className="text-sm text-red-500">{errors.postalCode.message}</p>}
            </div>
          </div>
          
          <div>
            <Label htmlFor="country">Country</Label>
            <Input 
              id="country" 
              placeholder="United Kingdom" 
              {...register("country", { required: "Country is required" })} 
            />
            {errors.country && <p className="text-sm text-red-500">{errors.country.message}</p>}
          </div>
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              Continue to Payment
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
