
import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Grip, Globe, Instagram, Facebook, Twitter, Linkedin, Youtube, Github, Mail, Phone, Upload, Image } from 'lucide-react';
import { cn } from '@/lib/utils';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { supabase } from '@/integrations/supabase/client';
import { Shop } from '@/types/shop';

interface Link {
  id?: string;
  title: string;
  url: string;
  icon?: string;
  sort_order: number;
}

interface CardPageFormProps {
  initialData: {
    name: string;
    business_name: string;
    slug: string;
    password: string;
    bio: string;
    contact_email: string;
    contact_phone: string;
    profile_image_url: string;
    links: Link[];
    is_sold?: boolean;
    shop_id?: string | null;
  };
  onSubmit: (data: any) => void;
  isLoading: boolean;
  shops?: Shop[];
}

const ICONS = [
  { name: 'globe', icon: <Globe size={20} /> },
  { name: 'instagram', icon: <Instagram size={20} /> },
  { name: 'facebook', icon: <Facebook size={20} /> },
  { name: 'twitter', icon: <Twitter size={20} /> },
  { name: 'linkedin', icon: <Linkedin size={20} /> },
  { name: 'youtube', icon: <Youtube size={20} /> },
  { name: 'github', icon: <Github size={20} /> },
  { name: 'mail', icon: <Mail size={20} /> },
  { name: 'phone', icon: <Phone size={20} /> }
];

export function CardPageForm({ initialData, onSubmit, isLoading, shops = [] }: CardPageFormProps) {
  const [formData, setFormData] = useState({
    name: initialData.name || '',
    business_name: initialData.business_name || '',
    slug: initialData.slug || '',
    password: initialData.password || 'Abc',
    bio: initialData.bio || '',
    contact_email: initialData.contact_email || '',
    contact_phone: initialData.contact_phone || '',
    profile_image_url: initialData.profile_image_url || '',
    links: initialData.links || [],
    is_sold: initialData.is_sold || false,
    shop_id: initialData.shop_id || null
  });
  
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [previewImage, setPreviewImage] = useState<string | null>(initialData.profile_image_url || null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleShopChange = (value: string) => {
    setFormData(prev => ({ ...prev, shop_id: value === 'null' ? null : value }));
  };

  const addLink = () => {
    setFormData(prev => ({
      ...prev,
      links: [
        ...prev.links,
        { 
          title: '', 
          url: '', 
          icon: 'globe',
          sort_order: prev.links.length 
        }
      ]
    }));
  };

  const updateLink = (index: number, field: keyof Link, value: string) => {
    setFormData(prev => {
      const newLinks = [...prev.links];
      newLinks[index] = { ...newLinks[index], [field]: value };
      return { ...prev, links: newLinks };
    });
  };

  const removeLink = (index: number) => {
    setFormData(prev => {
      const newLinks = prev.links.filter((_, i) => i !== index);
      // Update sort order for remaining links
      return {
        ...prev,
        links: newLinks.map((link, i) => ({ ...link, sort_order: i }))
      };
    });
  };

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;
    
    const sourceIndex = result.source.index;
    const destIndex = result.destination.index;
    
    if (sourceIndex === destIndex) return;
    
    setFormData(prev => {
      const newLinks = [...prev.links];
      const [removed] = newLinks.splice(sourceIndex, 1);
      newLinks.splice(destIndex, 0, removed);
      
      // Update sort_order values
      return {
        ...prev,
        links: newLinks.map((link, i) => ({ ...link, sort_order: i }))
      };
    });
  };

  const getIconComponent = (iconName: string) => {
    const icon = ICONS.find(i => i.name === iconName);
    return icon ? icon.icon : ICONS[0].icon;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
      setUploadError('Please select an image file');
      return;
    }
    
    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('Image should be less than 5MB');
      return;
    }
    
    setUploading(true);
    setUploadError('');
    
    try {
      // Create a preview
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setPreviewImage(e.target.result as string);
        }
      };
      reader.readAsDataURL(file);
      
      // Upload to Supabase Storage
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
      const filePath = `card-images/${fileName}`;
      
      const { data, error } = await supabase.storage
        .from('card-images')
        .upload(filePath, file);
      
      if (error) {
        throw error;
      }
      
      // Get the public URL
      const { data: { publicUrl } } = supabase.storage
        .from('card-images')
        .getPublicUrl(filePath);
      
      // Update form data with the new image URL
      setFormData(prev => ({
        ...prev,
        profile_image_url: publicUrl
      }));
    } catch (error) {
      console.error('Error uploading image:', error);
      setUploadError('Failed to upload image. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleUploadClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Name</Label>
          <Input
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="John Doe"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="business_name">Business Name</Label>
          <Input
            id="business_name"
            name="business_name"
            value={formData.business_name}
            onChange={handleChange}
            placeholder="Acme Inc."
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="slug">Page URL Slug</Label>
          <Input
            id="slug"
            name="slug"
            value={formData.slug}
            onChange={handleChange}
            placeholder="john-doe"
            required
          />
          <p className="text-xs text-gray-500">This will be the URL: yoursite.com/{formData.slug || 'your-slug'}</p>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="password">Edit Password</Label>
          <Input
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="Password for editing the page"
            required
          />
          <p className="text-xs text-gray-500">The user will need this password to edit their page</p>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="contact_email">Email</Label>
          <Input
            id="contact_email"
            name="contact_email"
            type="email"
            value={formData.contact_email}
            onChange={handleChange}
            placeholder="john@example.com"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="contact_phone">Phone</Label>
          <Input
            id="contact_phone"
            name="contact_phone"
            value={formData.contact_phone}
            onChange={handleChange}
            placeholder="+1 234 567 8900"
          />
        </div>
        
        {shops && shops.length > 0 && (
          <div className="space-y-2">
            <Label htmlFor="shop_id">Assign to Shop</Label>
            <Select
              value={formData.shop_id === null ? "null" : formData.shop_id}
              onValueChange={handleShopChange}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select a shop" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="null">No shop (unassigned)</SelectItem>
                {shops.map((shop) => (
                  <SelectItem key={shop.id} value={shop.id}>
                    {shop.name} - {shop.location}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
        
        <div className="space-y-2 md:col-span-2">
          <Label>Profile Image</Label>
          <div className="flex flex-col items-center border-2 border-dashed rounded-md p-6 transition-colors hover:border-primary/50">
            {previewImage ? (
              <div className="relative w-full flex flex-col items-center">
                <img 
                  src={previewImage} 
                  alt="Profile" 
                  className="h-48 object-contain rounded mb-4"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleUploadClick}
                  disabled={uploading}
                  className="flex items-center"
                >
                  {uploading ? (
                    <>
                      <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-r-transparent" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Image className="mr-2 h-4 w-4" />
                      Change Image
                    </>
                  )}
                </Button>
              </div>
            ) : (
              <Button
                type="button"
                variant="outline"
                onClick={handleUploadClick}
                disabled={uploading}
                className="flex items-center"
              >
                {uploading ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-r-transparent" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    Upload Image
                  </>
                )}
              </Button>
            )}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
            <input
              type="hidden"
              name="profile_image_url"
              value={formData.profile_image_url}
            />
            {uploadError && (
              <p className="text-red-500 text-sm mt-2">{uploadError}</p>
            )}
            <p className="text-xs text-gray-500 mt-2">
              Upload an image (JPG, PNG, GIF) up to 5MB
            </p>
          </div>
        </div>
        
        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="bio">Bio</Label>
          <Textarea
            id="bio"
            name="bio"
            value={formData.bio}
            onChange={handleChange}
            placeholder="Write a short bio..."
            className="min-h-24"
          />
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <Label>Links</Label>
          <Button type="button" onClick={addLink} variant="outline" size="sm">
            <Plus className="h-4 w-4 mr-1" /> Add Link
          </Button>
        </div>
        
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="links">
            {(provided) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className="space-y-3"
              >
                {formData.links.map((link, index) => (
                  <Draggable key={index} draggableId={`link-${index}`} index={index}>
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className="flex items-center space-x-2 p-3 border rounded-md bg-gray-50"
                      >
                        <div
                          {...provided.dragHandleProps}
                          className="cursor-grab"
                        >
                          <Grip className="h-4 w-4 text-gray-400" />
                        </div>
                        
                        <div className="flex-grow grid grid-cols-1 md:grid-cols-5 gap-2">
                          <div className="md:col-span-1">
                            <select
                              value={link.icon || 'globe'}
                              onChange={(e) => updateLink(index, 'icon', e.target.value)}
                              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                            >
                              {ICONS.map((icon) => (
                                <option key={icon.name} value={icon.name}>
                                  {icon.name.charAt(0).toUpperCase() + icon.name.slice(1)}
                                </option>
                              ))}
                            </select>
                          </div>
                          
                          <div className="md:col-span-1">
                            <Input
                              value={link.title}
                              onChange={(e) => updateLink(index, 'title', e.target.value)}
                              placeholder="Link Title"
                              required
                            />
                          </div>
                          
                          <div className="md:col-span-3">
                            <Input
                              value={link.url}
                              onChange={(e) => updateLink(index, 'url', e.target.value)}
                              placeholder="https://example.com"
                              required
                            />
                          </div>
                        </div>
                        
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeLink(index)}
                          className="h-8 w-8 text-red-500"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
        
        {formData.links.length === 0 && (
          <div className="text-center py-4 text-gray-500 border rounded-md">
            No links added. Click "Add Link" to add some.
          </div>
        )}
      </div>
      
      <div className="flex justify-end space-x-2">
        <Button type="submit" disabled={isLoading || uploading}>
          {isLoading ? "Saving..." : "Save Card Page"}
        </Button>
      </div>
    </form>
  );
}
