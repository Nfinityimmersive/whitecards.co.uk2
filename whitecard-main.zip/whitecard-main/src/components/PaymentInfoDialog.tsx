
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface PaymentInfoDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  totalAmount: number;
  orderReference: string;
  hasOneLinkCard?: boolean;
  oneLinkCardQuantity?: number;
}

export function PaymentInfoDialog({ 
  isOpen, 
  onClose, 
  onConfirm, 
  totalAmount, 
  orderReference,
  hasOneLinkCard = false,
  oneLinkCardQuantity = 0
}: PaymentInfoDialogProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleConfirmOrder = () => {
    setIsSubmitting(true);
    
    // Execute onConfirm which will handle WhatsApp action
    onConfirm();
    
    setTimeout(() => {
      setIsSubmitting(false);
    }, 1000);
  };

  const handleStripePayment = () => {
    // Construct the Stripe link with the quantity parameter
    const baseStripeLink = "https://buy.stripe.com/cNibJ0cb2c1H25zgLP3Ru00";
    const stripeLink = oneLinkCardQuantity > 1 
      ? `${baseStripeLink}?quantity=${oneLinkCardQuantity}` 
      : baseStripeLink;
    
    // Open in new tab
    window.open(stripeLink, '_blank');
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">Payment Information</DialogTitle>
          <DialogDescription className="text-center">
            Please make a bank transfer to our business account
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="p-4 border rounded-md bg-white text-center">
            <p className="font-semibold text-lg mb-2">Total Amount: £{totalAmount.toFixed(2)}</p>
            
            <div className="bg-gray-50 p-4 rounded-md text-sm text-left space-y-2 mb-4">
              <p><strong>Account Name:</strong> NFINITYIMMERSIVE LTD</p>
              <p><strong>Bank:</strong> Revolut</p>
              <p><strong>Sort Code:</strong> 04-29-09</p>
              <p><strong>Account Number:</strong> 70589364</p>
              <p><strong>Reference:</strong> {orderReference}</p>
            </div>
            
            <p className="text-xs text-gray-600 font-medium mb-3">
              Important: The reference number is MANDATORY to validate your order.
              Without the correct reference in your bank transfer, we cannot validate your payment.
            </p>
            
            <p className="text-xs text-gray-500 text-center">
              After making the payment, click 'Confirm Order' to process this order (via WhatsApp Business)
            </p>
          </div>
          
          <div className="flex flex-col space-y-2">
            {hasOneLinkCard && (
              <Button onClick={handleStripePayment} className="w-full bg-indigo-600 hover:bg-indigo-700">
                Pay with Stripe (One Link Card)
              </Button>
            )}
            <Button onClick={handleConfirmOrder} className="w-full" disabled={isSubmitting}>
              {isSubmitting ? "Sending..." : "Confirm Order"}
            </Button>
            <Button variant="outline" onClick={onClose} className="w-full" disabled={isSubmitting}>
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
