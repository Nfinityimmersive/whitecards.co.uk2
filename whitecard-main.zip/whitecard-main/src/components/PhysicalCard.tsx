
import { cn } from '@/lib/utils';

interface PhysicalCardProps {
  className?: string;
}

const PhysicalCard = ({ className }: PhysicalCardProps) => {
  return (
    <div 
      className={cn(
        "relative w-[300px] h-[180px] rounded-xl bg-white shadow-lg",
        "before:absolute before:inset-0 before:rounded-xl before:bg-gradient-to-br before:from-white before:to-gray-100",
        "border border-gray-100",
        className
      )}
    >
      <div className="absolute inset-0 rounded-xl overflow-hidden">
        <div className="absolute w-16 h-16 rounded-full bg-black/5 top-4 right-4"></div>
        <div className="absolute w-24 h-3 bg-gray-100 rounded-full bottom-10 left-6"></div>
        <div className="absolute w-32 h-2 bg-gray-100 rounded-full bottom-6 left-6"></div>
      </div>
      
      {/* NFC Symbol */}
      <div className="absolute top-1/2 right-12 transform -translate-y-1/2 w-14 h-14">
        <div className="relative w-full h-full">
          <div className="absolute inset-0 border-2 border-gray-200 rounded-full"></div>
          <div className="absolute inset-[4px] border-2 border-gray-200 rounded-full"></div>
          <div className="absolute inset-[8px] border-2 border-gray-200 rounded-full"></div>
        </div>
      </div>
    </div>
  );
};

export default PhysicalCard;
