import { Button } from '@/components/ui/button';
import { Plus, Minus, X } from 'lucide-react';
import { useCart } from '@/context/CartContext';

interface ICartItem {
  id: string;
  cardNumber: string;
  type: string;
  quantity: number;
  price: number;
  links: any[];
  name?: string;
  customImageUrl?: string;
  bio?: string;
  cardDesign?: string;
}

interface CartItemProps {
  item: ICartItem;
}

const CartItem = ({ item }: CartItemProps) => {
  const { updateQuantity, removeFromCart } = useCart();
  
  // Calculate actual links count - ensure we always show at least 1 link
  const linksCount = Math.max(1, item.links ? item.links.filter(link => link.url && link.url.trim() !== '').length : 0);
  
  return (
    <div className="flex flex-col pb-3 border-b last:border-b-0">
      <div className="flex justify-between items-start mb-1">
        <div>
          <div className="flex items-center gap-2">
            <p className="font-medium">{item.type.replace('-', ' ').toUpperCase()}</p>
            <span className="text-xs bg-gray-100 px-1.5 py-0.5 rounded-md">
              {item.cardNumber}
            </span>
          </div>
          <p className="text-xs text-gray-500">
            {item.type !== 'update-request' ? 
              `${linksCount} ${linksCount === 1 ? 'link' : 'links'} · £${item.price}` :
              `Update Request · £${item.price}`
            }
          </p>
          {item.name && <p className="text-xs text-gray-500">Name: {item.name}</p>}
        </div>
        <div className="flex items-center space-x-1">
          <div className="flex items-center border rounded-md overflow-hidden h-7">
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-7 w-7 rounded-none px-0"
              onClick={() => updateQuantity(item.id, -1)}
            >
              <Minus className="h-3 w-3" />
            </Button>
            <span className="text-xs w-6 text-center">{item.quantity}</span>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-7 w-7 rounded-none px-0" 
              onClick={() => updateQuantity(item.id, 1)}
            >
              <Plus className="h-3 w-3" />
            </Button>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-7 w-7 text-red-500 p-0"
            onClick={() => removeFromCart(item.id)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      {/* Display profile image if available */}
      {item.customImageUrl && (
        <div className="mt-1 flex justify-center">
          <img 
            src={item.customImageUrl} 
            alt="Profile" 
            className="h-16 w-16 object-cover rounded-full border" 
          />
        </div>
      )}
      
      {/* Display all links in a more compact way */}
      {item.links && item.links.length > 0 && item.type !== 'update-request' && (
        <div className="mt-1">
          {item.links.map((link, index) => (
            link.url && link.url.trim() !== '' && (
              <p key={index} className="text-xs text-gray-500 truncate max-w-full">
                <span className="font-medium">{link.platform}:</span> {link.url}
              </p>
            )
          ))}
          {!item.links.some(link => link.url && link.url.trim() !== '') && (
            <p className="text-xs text-gray-500">1 link</p>
          )}
        </div>
      )}
      
      {/* Display update request details if applicable */}
      {item.type === 'update-request' && item.links && item.links.length > 0 && (
        <div className="mt-1">
          <p className="text-xs font-medium">Request Details:</p>
          {item.links.map((update, index) => (
            <p key={index} className="text-xs text-gray-500">
              {update.action}: {update.details}
            </p>
          ))}
        </div>
      )}
    </div>
  );
};

export default CartItem;
