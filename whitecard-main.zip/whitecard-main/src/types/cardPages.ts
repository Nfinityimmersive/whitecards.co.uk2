
import { Shop } from './shop';

export interface Link {
  id: string;
  title: string;
  url: string;
  icon?: string;
  sort_order: number;
  card_page_id?: string;
}

export interface CardPage {
  id: string;
  card_number: string;
  slug: string;
  password: string;
  name: string | null;
  business_name: string | null;
  bio: string | null;
  profile_image_url: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  created_at: string;
  updated_at: string;
  links: Link[];
  is_sold?: boolean;
  shop_id?: string | null;
}

export interface CardPagesContextType {
  cardPages: CardPage[];
  shops: Shop[];
  isLoading: boolean;
  error: string | null;
  fetchCardPages: () => Promise<void>;
  fetchCardPage: (slug: string) => Promise<CardPage | null>;
  updateCardPage: (id: string, updates: Partial<CardPage>) => Promise<void>;
  createCardPage: (cardPage: Partial<Omit<CardPage, 'id' | 'created_at' | 'updated_at' | 'links'>>) => Promise<CardPage | null>;
  deleteCardPage: (id: string) => Promise<void>;
  addLink: (cardPageId: string, link: Omit<Link, 'id'>) => Promise<void>;
  updateLink: (linkId: string, updates: Partial<Link>) => Promise<void>;
  deleteLink: (linkId: string) => Promise<void>;
  fetchShops: () => Promise<void>;
  createShop: (shop: Partial<Omit<Shop, 'id' | 'created_at' | 'updated_at'>>) => Promise<Shop | null>;
  updateShop: (id: string, updates: Partial<Shop>) => Promise<void>;
  deleteShop: (id: string) => Promise<void>;
  allocateCardToShop: (cardId: string, shopId: string | null) => Promise<void>;
  markCardAsSold: (cardId: string, isSold: boolean) => Promise<void>;
  isAdmin: boolean;
  setIsAdmin: (value: boolean) => void;
}
