
export interface Business {
  id: string;
  name: string;
  type: 'restaurant' | 'barbershop' | 'salon' | 'retail' | 'other';
  contactName: string;
  phoneNumber: string;
  email: string;
  address?: string;
  notes?: string;
  status: 'not_contacted' | 'contacted' | 'interested' | 'meeting_scheduled' | 'not_interested';
  lastContactDate?: Date;
}

export interface Conversation {
  id: string;
  businessId: string;
  date: Date;
  duration?: number;
  transcript: ConversationMessage[];
  outcome: 'no_answer' | 'left_message' | 'call_back' | 'interested' | 'meeting_scheduled' | 'not_interested';
  notes?: string;
  followUpDate?: Date;
}

export interface ConversationMessage {
  speaker: 'agent' | 'prospect';
  text: string;
  timestamp: Date;
}

export interface ColdCallScript {
  id: string;
  name: string;
  businessType: Business['type'];
  introduction: string;
  valueProposition: string;
  questions: string[];
  objectionHandling: {
    objection: string;
    response: string;
  }[];
  closingStatements: string[];
}
