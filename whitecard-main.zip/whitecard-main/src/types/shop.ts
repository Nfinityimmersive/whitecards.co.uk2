
// Custom shop types that extend the base Supabase types
export interface Shop {
  id: string;
  name: string;
  location: string;
  contact_email: string;
  contact_phone: string;
  created_at: string;
  updated_at: string;
}

import { CardPage } from './cardPages';

export interface CardPageWithShopId extends Omit<CardPage, 'shop_id'> {
  shop_id?: string | null;
  is_sold?: boolean;
}
